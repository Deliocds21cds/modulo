


odoo.define("proveedor_prices.proveedorPrices", function (require) 
{
    "use strict";
    
});


