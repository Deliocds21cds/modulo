from odoo import api, fields, models, _
from odoo.exceptions import Warning
from odoo.osv import osv
from odoo.http import request

class product_template(models.Model):
    _inherit = 'product.template'

    pp_utility = fields.Char(string="Utilidad", store=True)
    pp_margin  = fields.Char(string="Margen", store=True)

    @api.onchange("list_price","standard_price")
    def update_pp_utility_and_pp_margin(self):
        # list_price     = precio venta
        # standard_price = precio costo
        list_price = float(self.list_price)
        standard_price = float(self.standard_price)
        if(standard_price < list_price):
            self.pp_utility = list_price - standard_price            
            self.pp_margin = (float(self.pp_utility) / float(standard_price)) * 100
            self.pp_utility = str(self.currency_id.symbol) + str(" ") + str(format(float(self.pp_utility),",.0f")) + str(" ") + str(self.currency_id.name)
            self.pp_margin = str(format(float(self.pp_margin),".2f")) + str(" %")
    
    @api.onchange("default_code")
    def update_default_code(self):
        default_code = self.default_code
        product = request.env['product.template'].sudo().search([['default_code','=',default_code]], limit=1)
        if(product):
            raise Warning("La referencia "+str(default_code)+" del producto ya existe.")
        else:
            pass