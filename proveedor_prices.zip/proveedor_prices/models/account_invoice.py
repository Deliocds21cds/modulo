from odoo import api, fields, models, _
from odoo.exceptions import Warning, UserError
from odoo.osv import osv
from odoo.http import request
import sys
import json

class account_invoice(models.Model):
    _inherit = 'account.invoice'

    @api.model
    def _default_picking_receive(self):
        type_obj = self.env['stock.picking.type']
        company_id = self.env.context.get('company_id') or self.env.user.company_id.id
        types = type_obj.search([('code', '=', 'incoming'), ('warehouse_id.company_id', '=', company_id)], limit=1)
        if not types:
            types = type_obj.search([('code', '=', 'incoming'), ('warehouse_id', '=', False)])
        return types[:1]

    picking_count = fields.Integer(string="Count")
    invoice_picking_id = fields.Many2one('stock.picking', string="Picking Id")
    picking_type_id = fields.Many2one('stock.picking.type', 'Picking Type', required=True, default=_default_picking_receive, help="This will determine picking type of incoming shipment")
    state = fields.Selection([
        ('draft', 'Draft'),
        ('proforma', 'Pro-forma'),
        ('proforma2', 'Pro-forma'),
        ('open', 'Open'),
        ('paid', 'Paid'),
        ('cancel', 'Cancelled'),
        ('done', 'Received'),
    ], string='Status', index=True, readonly=True, default='draft',
        track_visibility='onchange', copy=False)
    
   
               
    @api.multi
    def invoice_validate(self):
        try:
            for order in self:
                if(str(order.type) == str('in_invoice')):
                    if not order.invoice_line_ids:
                        raise UserError(_('Please create some invoice lines.'))
                    if not self.number:
                        raise UserError(_('Please Validate invoice.'))
                    if not self.invoice_picking_id:
                        pick = {
                                    'picking_type_id': self.picking_type_id.id,
                                    'partner_id': self.partner_id.id,
                                    'origin': self.number,
                                    'location_dest_id': self.picking_type_id.default_location_dest_id.id,
                                    'location_id': self.partner_id.property_stock_supplier.id
                                }
                        picking = self.env['stock.picking'].create(pick)
                        self.invoice_picking_id = picking.id
                        self.picking_count = len(picking)
                        moves = order.invoice_line_ids.filtered(lambda r: r.product_id.type in ['product', 'consu'])._create_stock_moves(picking)
                        move_ids = moves._action_confirm()
                        move_ids._action_assign()
                        stock_picking = request.env['stock.picking'].sudo().search([['id','=',picking.id]])
                        stock_picking.sudo().action_confirm()
                        stock_picking.sudo().button_validate()                        
                        self.env['stock.immediate.transfer'].create({'pick_ids': [(4, stock_picking.id)]}).process()
                        



            return super(account_invoice, self).invoice_validate()
        except Exception as e:
            exc_traceback = sys.exc_info()
            #with open('/odoo_dian_v12/custom/addons/proveedor_prices/data.json', 'w') as outfile:
            #   json.dump(getattr(e, 'message', repr(e))+" ON LINE "+format(sys.exc_info()[-1].tb_lineno), outfile)