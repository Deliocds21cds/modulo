from odoo import api, fields, models, _
from odoo.exceptions import Warning
from odoo.osv import osv
from odoo.http import request
import sys
import json
import logging
_logger = logging.getLogger(__name__)
class account_invoice_line(models.Model):
    _inherit = 'account.invoice.line'

    pp_price_sale = fields.Float('Precio Venta', store=True)
    pp_margin = fields.Char('Margen %', store=True)

    _columns = {
                    'pp_price_sale': fields.Float('Precio Venta'), 
                    'pp_margin': fields.Char('Margen %')
                }
                
    @api.onchange('product_id', 'uom_id')
    def _onchange_product_id_account_invoice_margin(self):
        _logger.info('=====>ACA ESTOY2')
        if self.invoice_id.type in ['in_invoice']:
            list_price = self.product_id.list_price
            standard_price = float(self.price_unit)

            if self.uom_id != self.product_id.uom_id:
                list_price = self.product_id.uom_id._compute_price(list_price, self.uom_id)
            self.pp_price_sale = list_price

            if(float(standard_price) < float(list_price)):
                pp_utility = list_price - standard_price  
                self.pp_margin = (float(pp_utility) / float(standard_price)) * 100
                self.pp_margin = str(format(float(self.pp_margin),".2f")) + str(" %")
            
                if(float(self.pp_price_sale) > 0.00):
                    pp_utility = list_price - standard_price  
                    product = request.env['product.template'].sudo().search([['id','=',self.product_id.id]])                     
                    pp_utility = str(product.currency_id.symbol) + str(" ") + str(format(float(pp_utility),",.0f")) + str(" ") + str(product.currency_id.name)
                    product.sudo().write({
                                            "list_price": float(self.pp_price_sale),
                                            "pp_margin": str(self.pp_margin),
                                            "pp_utility": pp_utility,
                                        })
    
    @api.onchange("price_unit","pp_price_sale")
    def update_pp_utility_and_pp_margin(self):
        list_price = float(self.pp_price_sale)
        standard_price = float(self.price_unit)

        if(standard_price < list_price):
            pp_utility = list_price - standard_price            
            self.pp_margin = (float(pp_utility) / float(standard_price)) * 100
            self.pp_margin = str(format(float(self.pp_margin),".2f")) + str(" %")
        
            if(float(self.pp_price_sale) > 0.00):

                pp_utility = list_price - standard_price            
                product = request.env['product.template'].sudo().search([['id','=',self.product_id.product_tmpl_id.id]])           
                res_id = "product.product,"+str(self.product_id.id) 
                pp_utility = str(product.currency_id.symbol) + str(" ") + str(format(float(pp_utility),",.0f")) + str(" ") + str(product.currency_id.name)
                product.sudo().write({
                                        "list_price": float(self.pp_price_sale),
                                        "pp_margin": str(self.pp_margin),
                                        "pp_utility": pp_utility
                                        })                  
                self.env['ir.property'].sudo().search([('name', '=', 'standard_price'), ('res_id', '=', res_id)]).sudo().write({"value_float":float(standard_price)})
    

    @api.multi
    def _create_stock_moves(self, picking):
        try:
            moves = self.env['stock.move']
            done = self.env['stock.move'].browse()
            for line in self:
                price_unit = line.price_unit
                template = {
                    'name': line.name or '',
                    'product_id': line.product_id.id,
                    'product_uom': line.uom_id.id,
                    'location_id': line.invoice_id.partner_id.property_stock_supplier.id,
                    'location_dest_id': picking.picking_type_id.default_location_dest_id.id,
                    'picking_id': picking.id,
                    'move_dest_id': False,
                    'state': 'draft',
                    'company_id': line.invoice_id.company_id.id,
                    'price_unit': price_unit,
                    'picking_type_id': picking.picking_type_id.id,
                    'procurement_id': False,
                    'route_ids': 1 and [(6, 0, [x.id for x in self.env['stock.location.route'].search([('id', 'in', (2, 3))])])] or [],
                    'warehouse_id': picking.picking_type_id.warehouse_id.id,
                }
                diff_quantity = line.quantity
                tmp = template.copy()
                tmp.update({
                    'product_uom_qty': diff_quantity,
                })
                template['product_uom_qty'] = diff_quantity
                done += moves.create(template)
            return done
        except Exception as e:
            exc_traceback = sys.exc_info()
            #with open('/odoo_dian_v12/custom/addons/proveedor_prices/data.json', 'w') as outfile:
            #   json.dump(getattr(e, 'message', repr(e))+" ON LINE "+format(sys.exc_info()[-1].tb_lineno), outfile)