# -*- coding: utf-8 -*-
{
    'name': 'Proveedor precios',
    'description': "Precios & margenes proveedor",
    'author': "ROCKSCRIPTS",
    'website': "https://instagram.com/rockscripts",
    'summary': "Precios & margenes proveedor",
    'version': '0.1',
    "license": "OPL-1",
    'price':'40',
    'currency':'USD',
    'support': 'rockscripts@gmail.com',
    'category': 'module_category_account_voucher',
        # any module necessary for this one to work correctly
    'depends': ['base','account'],

    # always loaded
    'data': [
             'views/templates.xml',
             'views/views.xml',
            ],
    'qweb': [
               
            ],
    #"external_dependencies": {"python" : ["pytesseract"]},
    'installable': True,
}
