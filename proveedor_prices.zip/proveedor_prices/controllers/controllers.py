# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
import json

class edocs_print_format(http.Controller):

    @http.route('/dianefact/get_invoice_ordered/', methods=['POST'], type='json', auth="public", website=True)
    def get_invoice_ordered(self, **kw):
        orderReference = kw.get('orderReference')
        
        