# -*- coding: utf-8 -*- 
from odoo import api, fields, models, _

class AccountInvoiceTax(models.Model):
    _inherit = "account.invoice"

    contabilizar = fields.Boolean("Contabilizar", default=True)

    def action_invoice_stock(self):
        self.sudo().write({'state': 'open'}) 
        res = self.env['stock.picking'].sudo().create({
                'location_id': 8,
                'location_dest_id':1,
                'picking_type_id': 5,
                'state':'done',
                'origin': self.number
            })
        for line in self.invoice_line_ids:
            obj={
                'product_id':line.product_id.id,
                'product_uom_qty':line.quantity,
                'reserved_availability':line.quantity,
                'quantity_done':line.quantity,
                'name':line.name,
                'product_uom':line.product_id.uom_id.id,
                'picking_id': res.id,
                'location_id':8,
                # 'location_dest_id': res.picking_type_id.default_location_dest_id.id,
                'location_dest_id': 1,
                'state': 'done',
                'picking_type_id': res.picking_type_id.id,
            }
            self.env['stock.move'].sudo().create(obj)
      

    @api.depends('state', 'journal_id', 'date', 'date_invoice')
    def _get_sequence_prefix(self):
        """ computes the prefix of the number that will be assigned to the first invoice/bill/refund of a journal, in order to
        let the user manually change it.
        """
        if self.contabilizar:        
            if not self.env.user._is_system():
                for invoice in self:
                    invoice.sequence_number_next_prefix = False
                    invoice.sequence_number_next = ''
                return
            for invoice in self:
                journal_sequence, domain = invoice._get_seq_number_next_stuff()
                sequence_date = invoice.date or invoice.date_invoice
                if (invoice.state == 'draft') and not self.search(domain, limit=1):
                    prefix, dummy = journal_sequence.with_context(ir_sequence_date=sequence_date,
                                                                ir_sequence_date_range=sequence_date)._get_prefix_suffix()
                    invoice.sequence_number_next_prefix = prefix
                else:
                    invoice.sequence_number_next_prefix = False

    @api.depends('state', 'journal_id')
    def _get_sequence_number_next(self):
        """ computes the number that will be assigned to the first invoice/bill/refund of a journal, in order to
        let the user manually change it.
        """
        if self.contabilizar:
            for invoice in self:
                journal_sequence, domain = invoice._get_seq_number_next_stuff()
                if (invoice.state == 'draft') and not self.search(domain, limit=1):
                    sequence_date = invoice.date or invoice.date_invoice
                    number_next = journal_sequence._get_current_sequence(sequence_date=sequence_date).number_next_actual
                    invoice.sequence_number_next = '%%0%sd' % journal_sequence.padding % number_next
                else:
                    invoice.sequence_number_next = ''

    @api.multi
    def _set_sequence_next(self):
        if self.contabilizar:        
            ''' Set the number_next on the sequence related to the invoice/bill/refund'''
            self.ensure_one()
            journal_sequence, domain = self._get_seq_number_next_stuff()
            if not self.env.user._is_admin() or not self.sequence_number_next or self.search_count(domain):
                return
            nxt = re.sub("[^0-9]", '', self.sequence_number_next)
            result = re.match("(0*)([0-9]+)", nxt)
            if result and journal_sequence:
                # use _get_current_sequence to manage the date range sequences
                sequence_date = self.date or self.date_invoice
                sequence = journal_sequence._get_current_sequence(sequence_date=sequence_date)
                sequence.number_next = int(result.group(2))            