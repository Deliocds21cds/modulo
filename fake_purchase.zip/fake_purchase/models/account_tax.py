# -*- coding: utf-8 -*- 
from odoo import api, fields, models, _

class AccountInvoiceTax(models.Model):
    _inherit = "account.invoice.tax"

    fake_id = fields.Many2one(comodel_name='fake.account.invoice', string='factura')