# -*- coding: utf-8 -*- 
from odoo import api, fields, models, _

class FakePurchase(models.Model):
    _name = "fake.account.invoice"
    _rec_name="niu"

    niu = fields.Char('NIU', readonly=True, select=True, copy=False, default='New')
    number = fields.Char(string="Número", readonly=True)
    sequence_number_next = fields.Char(string="Próximo número")
    sequence_number_next_prefix = fields.Char(string="Prefijo del número siguiente", readonly=True)
    partner_id= fields.Many2one(comodel_name='res.partner', string='Cliente', required=True)
    payment_term_id = fields.Many2one(comodel_name='account.payment.term', string='Plazo de Pago')
    date_invoice = fields.Date(string="Fecha de Factura")
    date_due = fields.Date(string="Fecha de Vencimiento")
    user_id = fields.Many2one(comodel_name='res.users', string='Vendedor')
    invoice_line_ids = fields.One2many(comodel_name='fake.account.line', inverse_name='fake_id', string='Lineas de Factura')
    type = fields.Selection([
            ('out_invoice','Customer Invoice'),
            ('in_invoice','Vendor Bill'),
            ('out_refund','Customer Credit Note'),
            ('in_refund','Vendor Credit Note'),
        ], readonly=True, states={'draft': [('readonly', False)]}, index=True, change_default=True,
        default=lambda self: self._context.get('type', 'out_invoice'),
        track_visibility='always')    
    state = fields.Selection([
            ('draft','Borrador'),
            ('open', 'Abierta'),
            ('in_payment', 'In Payment'),
            ('stocked', 'Inventariada'),
            ('cancel', 'Cancelled'),
        ], string='Status', index=True, readonly=True, default='draft',
        track_visibility='onchange', copy=False,
        help=" * The 'Draft' status is used when a user is encoding a new and unconfirmed Invoice.\n"
             " * The 'Open' status is used when user creates invoice, an invoice number is generated. It stays in the open status till the user pays the invoice.\n"
             " * The 'In Payment' status is used when payments have been registered for the entirety of the invoice in a journal configured to post entries at bank reconciliation only, and some of them haven't been reconciled with a bank statement line yet.\n"
             " * The 'Paid' status is set automatically when the invoice is paid. Its related journal entries may or may not be reconciled.\n"
             " * The 'Cancelled' status is used when user cancel invoice.")    
    
     
    @api.model
    def create(self, vals):
        obj = super(FakePurchase,self).create(vals)
        if obj.niu == 'New':
            number = self.env['ir.sequence'].next_by_code('fake.account.invoice') or 'New'
            obj.write({'niu':number, 'state': 'open'})
        return obj    

    def action_invoice_stock(self):
        res = self.env['stock.picking'].sudo().create({
                'location_id': 8,
                'location_dest_id':1,
                'picking_type_id': 5,
                'state':'done',
                'origin': self.niu
            })
        for line in self.invoice_line_ids:
            obj={
                'product_id':line.product_id.id,
                'product_uom_qty':line.cantidad,
                'reserved_availability':line.cantidad,
                'quantity_done':line.cantidad,
                'name':line.name,
                'product_uom':line.product_id.uom_id.id,
                'picking_id': res.id,
                'location_id':8,
                # 'location_dest_id': res.picking_type_id.default_location_dest_id.id,
                'location_dest_id': 1,
                'state': 'done',
                'picking_type_id': res.picking_type_id.id,
            }
            self.env['stock.move'].sudo().create(obj)
            self.write({'state': 'stocked'})         