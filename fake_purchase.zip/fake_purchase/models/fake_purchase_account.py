# -*- coding: utf-8 -*- 
from odoo import api, fields, models, _
import logging
_logger = logging.getLogger(__name__)
TYPE2JOURNAL = {
    'out_invoice': 'sale',
    'in_invoice': 'purchase',
    'out_refund': 'sale',
    'in_refund': 'purchase',
}

class FakePurchase(models.Model):
    _name = "fake.account.invoice"
    _rec_name="niu"

    @api.model
    def _default_currency(self):
        journal = self._default_journal()
        return journal.currency_id or journal.company_id.currency_id or self.env.user.company_id.currency_id
    

    niu = fields.Char('NIU', readonly=True, select=True, copy=False, default='New')
    number = fields.Char(string="Número", readonly=True)
    sequence_number_next = fields.Char(string="Próximo número")
    sequence_number_next_prefix = fields.Char(string="Prefijo del número siguiente", readonly=True)
    partner_id= fields.Many2one(comodel_name='res.partner', string='Cliente', required=True)
    payment_term_id = fields.Many2one(comodel_name='account.payment.term', string='Plazo de Pago')
    date_invoice = fields.Date(string="Fecha de Factura")
    date_due = fields.Date(string="Fecha de Vencimiento")
    fake_payments_ids = fields.One2many(
        "fake.payments", "fake_id", string="Pagos", translate=True)
    user_id = fields.Many2one(comodel_name='res.users', string='Vendedor')
    invoice_line_ids = fields.One2many(comodel_name='fake.account.line', inverse_name='fake_id', string='Lineas de Factura')
    type = fields.Selection([
            ('out_invoice','Customer Invoice'),
            ('in_invoice','Vendor Bill'),
            ('out_refund','Customer Credit Note'),
            ('in_refund','Vendor Credit Note'),
        ], readonly=True, states={'draft': [('readonly', False)]}, index=True, change_default=True,
        default=lambda self: self._context.get('type', 'out_invoice'),
        track_visibility='always')    
    state = fields.Selection([
            ('draft','Borrador'),
            ('open', 'Abierta'),
            ('in_payment', 'In Payment'),
            ('stocked', 'Validada'),
            ('cancel', 'Cancelled'),
        ], string='Status', index=True, readonly=True, default='draft',
        track_visibility='onchange', copy=False,
        help=" * The 'Draft' status is used when a user is encoding a new and unconfirmed Invoice.\n"
             " * The 'Open' status is used when user creates invoice, an invoice number is generated. It stays in the open status till the user pays the invoice.\n"
             " * The 'In Payment' status is used when payments have been registered for the entirety of the invoice in a journal configured to post entries at bank reconciliation only, and some of them haven't been reconciled with a bank statement line yet.\n"
             " * The 'Paid' status is set automatically when the invoice is paid. Its related journal entries may or may not be reconciled.\n"
             " * The 'Cancelled' status is used when user cancel invoice.")    
    currency_id = fields.Many2one('res.currency', string='Currency',
        required=True, readonly=True, states={'draft': [('readonly', False)]},
        default=_default_currency, track_visibility='always')    
    amount_untaxed = fields.Monetary(string='Untaxed Amount', store=True, readonly=True, compute='_compute_amount', track_visibility='always')
    amount_tax = fields.Monetary(string='Tax',
        store=True, readonly=True, compute='_compute_amount')
    amount_total = fields.Monetary(string='Total',
        store=True, readonly=True, compute='_compute_amount')
    # residual = fields.Monetary(string='Amount Due',
    #     compute='_compute_residual', store=True, help="Remaining amount due.")
    outstanding_credits_debits_widget = fields.Text(groups="account.group_account_invoice")
    # tax_line_ids = fields.One2many('account.invoice.tax', 'fake_id', string='Tax Lines', oldname='tax_line',
    #     readonly=True, states={'draft': [('readonly', False)]}, copy=True)
    reconciled = fields.Boolean(string='Paid/Reconciled', store=True, readonly=True, compute='_compute_residual',
        help="It indicates that the invoice has been paid and the journal entry of the invoice has been reconciled with one or several journal entries of payment.")
    # mapping invoice type to journal type



    def action_invoice_pagos(self):
        view_id=self.env['fake.invoice.wizard']
       # new = view_id.create()
        return {
            'type': 'ir.actions.act_window',
            'context': {'circular': self.niu, 'fake_id':self.id},
            'name': 'Registrar Pagos',
            'res_model': 'fake.invoice.wizard',
            'view_type': 'form',
            'view_mode': 'form',
          #  'res_id'    : self.id,
            'view_id': self.env.ref('fake_purchase.fake_invoice_wizard').id,
            'target': 'new',
        }        

    @api.model
    def _default_journal(self):
        if self._context.get('default_journal_id', False):
            return self.env['account.journal'].browse(self._context.get('default_journal_id'))
        inv_type = self._context.get('type', 'out_invoice')
        inv_types = inv_type if isinstance(inv_type, list) else [inv_type]
        company_id = self._context.get('company_id', self.env.user.company_id.id)
        domain = [
            ('type', 'in', [TYPE2JOURNAL[ty] for ty in inv_types if ty in TYPE2JOURNAL]),
            ('company_id', '=', company_id),
        ]
        company_currency_id = self.env['res.company'].browse(company_id).currency_id.id
        currency_id = self._context.get('default_currency_id') or company_currency_id
        currency_clause = [('currency_id', '=', currency_id)]
        if currency_id == company_currency_id:
            currency_clause = ['|', ('currency_id', '=', False)] + currency_clause
        return (
            self.env['account.journal'].search(domain + currency_clause, limit=1)
            or self.env['account.journal'].search(domain, limit=1)
        )

    @api.one
    @api.depends('invoice_line_ids.price_subtotal')
    def _compute_amount(self):
        round_curr = self.currency_id.round
        self.amount_untaxed = sum(line.price_subtotal for line in self.invoice_line_ids)
        # self.amount_tax = sum(round_curr(line.amount_total) for line in self.tax_line_ids)
        self.amount_total = self.amount_untaxed + self.amount_tax

    @api.model
    def create(self, vals):
        obj = super(FakePurchase,self).create(vals)
        if obj.niu == 'New':
            number = self.env['ir.sequence'].next_by_code('fake.account.invoice') or 'New'
            obj.write({'niu':number, 'state': 'open'})
        return obj    

    def action_invoice_stock(self):
        res = self.env['stock.picking'].sudo().create({
                'location_id': 8,
                'location_dest_id':1,
                'picking_type_id': 5,
                'state':'done',
                'origin': self.niu
            })
        for line in self.invoice_line_ids:
            obj={
                'product_id':line.product_id.id,
                'product_uom_qty':line.cantidad,
                'reserved_availability':line.cantidad,
                'quantity_done':line.cantidad,
                'name':line.name,
                'product_uom':line.product_id.uom_id.id,
                'picking_id': res.id,
                'location_id':8,
                # 'location_dest_id': res.picking_type_id.default_location_dest_id.id,
                'location_dest_id': 1,
                'state': 'done',
                'picking_type_id': res.picking_type_id.id,
            }
            self.env['stock.move'].sudo().create(obj)
            self.write({'state': 'stocked'})         