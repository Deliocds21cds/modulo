# -*- coding: utf-8 -*- 
from odoo import api, fields, models, _

class FakePayments(models.Model):
    _name = "fake.payments"

    amount = fields.Float('Cantidad a Pagar', required=True)
    fake_id = fields.Many2one(comodel_name='fake.account.invoice', string='Factura', required=True)
