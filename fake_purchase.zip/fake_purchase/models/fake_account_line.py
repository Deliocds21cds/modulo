# -*- coding: utf-8 -*- 
from odoo import api, fields, models, _

class FakeAccountLine(models.Model):
    _name = "fake.account.line"
    
    fake_id = fields.Many2one(comodel_name='fake.account.invoice', string='factura')
    product_id = fields.Many2one(comodel_name='product.product', string='Producto')
    cantidad = fields.Float(string="Cantidad",default = 1)
    price_unit = fields.Float(string="Precio")
    name = fields.Text(string='Descripcion')
    discount = fields.Float(string='Descuento',default = 0)
    #invoice_line_tax_ids = fields.Many2many(comodel_name='account.tax', string='Impuestos')
    price_subtotal = fields.Float(string='Subtotal')

 
    @api.onchange('product_id')
    def set_price(self):
        self.price_unit = self.product_id.lst_price
        self.name = self.product_id.name

    @api.onchange('product_id','cantidad','price_unit','discount')
    def set_subtotal(self):
        self.price_subtotal = self.price_unit*self.cantidad

        if int(self.discount) > 0:
            self.price_subtotal = self.price_unit*self.cantidad*(self.discount/100)
        else:
            self.price_subtotal = self.price_unit*self.cantidad







 
    
