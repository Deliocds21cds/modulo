# -*- coding: utf-8 -*-
###############################################################################
# Odoo - Open Source Management Solution
# Copyright (C) 2021 - Today Digilab Peru (<https://www.digilab.pe>)
###############################################################################
{
    'name': "Falsa Factura",
    'version': '1.2',
    'depends': ['base'],
    'author': "Digilab Perú",
    'category': 'stock',
    'contributors': [
        'Darwin Barron',
        'Luis Alva'
    ],
    'description': """
     Modulo que Sirve para Hacer Facturas sin Contabilizarlas
     ----------------------
    """,
    'depends' : ['account'],
    # data files always loaded at installation
    'data': [
        "data/sequence.xml",
        "security/ir.model.access.csv",
        "views/fake_line_views.xml",
        "views/fake_purchase_views.xml",
        "views/menus.xml",
        "views/wizard.xml"
       # "views/account_invoice_views.xml"
    ],
    # data files containing optionally loaded demonstration data
    'demo': [
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
    "sequence": 1,    
}