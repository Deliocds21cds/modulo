# -*- coding: utf-8 -*-
from datetime import datetime
from odoo.exceptions import Warning, UserError
from odoo import models, fields, _, api
import logging
_logger = logging.getLogger(__name__)
class FakeInvoiceWizard(models.TransientModel):
    _name='fake.invoice.wizard'

    amount = fields.Float('Cantidad a Pagar', required=True)
    journal_id = fields.Many2one(comodel_name='account.journal', string='Diario de Pago', required=True)
    payment_date = fields.Datetime(string="Fecha de Pago",required=True, default=datetime.today())
    communication = fields.Char(string="Circular", default=lambda self: self._get_default_status())
    # journal_id = fields.One2Many('Cantidad a Pagar', required=True)

    @api.model 
    def _get_fake_id(self): 
        if self.env.context.get('fake_id'): 
            return self.env.context.get('fake_id')

    def validar_pago(self):
        self.env['fake.payments'].sudo().create({
            "amount":self.amount,
            "fake_id":self._get_fake_id()
        })
    
    @api.model 
    def _get_default_status(self): 
        if self.env.context.get('circular'): 
            return self.env.context.get('circular')