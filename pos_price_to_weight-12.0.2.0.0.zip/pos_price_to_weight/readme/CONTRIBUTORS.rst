* Sylvain LE GAL <https://twitter.com/legalsylvain>
* Druidoo <https://www.druidoo.io>
