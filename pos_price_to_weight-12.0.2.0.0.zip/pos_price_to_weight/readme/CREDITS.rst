Icon parts come from http://icons8.com
