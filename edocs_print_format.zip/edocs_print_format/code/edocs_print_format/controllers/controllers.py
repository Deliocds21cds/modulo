# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
import json

class edocs_print_format(http.Controller):

    @http.route('/dianefact/get_invoice_ordered/', methods=['POST'], type='json', auth="public", website=True)
    def get_invoice_ordered(self, **kw):
        orderReference = kw.get('orderReference')
        response = {}
        query = "select invoice_id from pos_order where pos_reference = '"+str(orderReference)+"'"
        
        request.cr.execute(query)    
        pos_sale = request.cr.dictfetchone()
        invoice_id = pos_sale['invoice_id']
        
        if(invoice_id):
            query = "select number, journal_id, qr_code, cufe from account_invoice where id = "+str(invoice_id)
            request.cr.execute(query)    
            account_invoice = request.cr.dictfetchone()

            query = "select name from account_journal where id = "+str(account_invoice['journal_id'])
            request.cr.execute(query)    
            account_journal = request.cr.dictfetchone()

            response = {"number":account_invoice['number'],"journal_name":account_journal['name'],"qr_code":account_invoice['qr_code'],"cufe":account_invoice['cufe']}
        
        return response
    

        