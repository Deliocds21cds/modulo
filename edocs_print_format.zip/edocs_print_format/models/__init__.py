# -*- coding: utf-8 -*-
from . import edocs_print_format