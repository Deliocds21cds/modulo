# -*- coding: utf-8 -*-
from odoo import models, fields, api

class report_consulta_saldos(models.AbstractModel): 
    _name = 'report.dev_loan_management.report_consulta_saldos'

      
    @api.model
    def _get_report_values(self, docids, data=None):
        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_id'))
        return {
            'doc_model': 'loan.consulta.saldos',
            'docs': docs,
            'doc_ids': docs.ids,
        }

 
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
