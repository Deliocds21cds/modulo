# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2015 DevIntelle Consulting Service Pvt.Ltd (<http://www.devintellecs.com>).
#
#    For Module Support : devintelle@gmail.com  or Skype : devintelle
#
##############################################################################

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class res_partner(models.Model):
    _inherit = "res.partner"
    
    is_allow_loan = fields.Boolean('Allow Loan')
    loan_request = fields.Integer('Loan Request Per Year', default=1)

    is_collector = fields.Boolean('Collector', default=False)
    company_type = fields.Selection(string='Company Type',
                                    selection=[('person', 'Natural Person'), ('company', 'Juridic Person')],
                                    compute='_compute_company_type', inverse='_write_company_type')
    code = fields.Char('Code')
    rute = fields.Many2one('loan.rute', string='Ruta', ondelete='restrict')
    no_pagare = fields.Float(string='Pagare No')

    document_type = fields.Many2one('loan.document.type', string='Document Type', ondelete='restrict')
    speciality = fields.Many2one('dev.loan.nom.especiality', string='Speciality', ondelete='restrict')
    expedicion_lugar = fields.Char(
        string='Lugar expedición documento',
    )
    company_work = fields.Char('Company Work')
    address_company = fields.Char('Company Address')
    oldest = fields.Date('Antiquity')
    phone_fix = fields.Char()
    salary = fields.Float('Salary')
    other_income = fields.Float('Other Incomes')
    by_concepts = fields.Text(string='By Concepts')
    own_house = fields.Boolean('Own House')
    has_conyuge = fields.Boolean('Has Conyuge')
    conyuge_name = fields.Char('Conyuge Name')
    conyuge_phone = fields.Char('Conyuge Phone/Celular')
    vat = fields.Char(string='NIT/CC')
    loan_ids = fields.One2many(
        comodel_name='dev.loan.loan',
        inverse_name='client_id',
        string="Loans",
    )

    @api.constrains('is_allow_loan','loan_request')
    def check_rate(self):
        if self.is_allow_loan and self.loan_request <= 0:
            raise ValidationError(_("Loan Request Per Year Must be Positive !!!"))
    
    
    loan_ids = fields.One2many('dev.loan.loan','client_id', string='Loans', domain=[('state','not in', ['draft','reject','cancel'])])
    count_loan = fields.Integer('View Loan', compute='_count_loan')
    
    @api.multi
    def _count_loan(self):
        for partner in self:
            partner.count_loan = len(partner.loan_ids)
            
    @api.multi
    def action_view_loan(self):
        loan_ids = self.env['dev.loan.loan'].search([('client_id','=',self.id)])
        if loan_ids:
            action = self.env.ref('dev_loan_management.action_dev_loan_loan').read()[0]
            action['domain'] = [('id', 'in', loan_ids.ids),('state','not in',['draft','reject','cancel'])]
            return action
        else:
            action = {'type': 'ir.actions.act_window_close'}
    
    @api.multi
    def action_view_installment(self):
        installment_ids = self.env['dev.loan.installment'].search([('client_id','=',self.id)])
        if installment_ids:
            action = self.env.ref('dev_loan_management.action_dev_loan_installment').read()[0]
            action['domain'] = [('id', 'in', installment_ids.ids),('loan_id.state','not in',['draft','reject','cancel'])]
            return action
        else:
            action = {'type': 'ir.actions.act_window_close'}

    @api.multi
    def action_view_cartas(self):
        action = self.env.ref('dev_loan_management.loan_morosos_action').read()[0]
        action['context'] = {'partner_id':self.id}
        return action
        

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

