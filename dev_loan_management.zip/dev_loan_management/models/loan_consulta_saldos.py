# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from datetime import datetime
import time


class loan_consulta_saldos(models.TransientModel):
    _name = "loan.consulta.saldos"
    _rec_name = 'prestatario_id'

    prestatario_id = fields.Many2one('res.partner',string='Buscar Prestatario')
    ruta_id = fields.Many2one('loan.rute',string='Ruta')
    modalidad = fields.Selection([
        ('diario', 'Diario'),
        ('semanal', 'Semanal'),
        ('quincenal', 'Quincenal'),
        ('mensual', 'Mensual'),
        ], string='Modalidad', track_visibility='onchange')

    estado = fields.Selection([
        ('todos', 'Todos'),
        ('abierto', 'Abierto'),
        ('cerrado', 'Cerrado'),
        ('vencida', 'Cuotas Vencidas'),
        ], string='Prestamos', default='todos')

    plazo_dias = fields.Selection([
        ('todos', 'Todos'),
        ('30', '30 días'),
        ('60', '60 días'),
        ('90', '90 días'),
        ], string='Plazo vencimiento')
    
    fecha_desde = fields.Date(string='Fecha Desde')
    fecha_hasta = fields.Date(string='Fecha Hasta')


    #tabla = fields.Html(string='Resultado:')
    #prestamos_ids = fields.One2many('dev.loan.loan','id',string='Prestamos')
    prestamos_ids = fields.Many2many('dev.loan.loan',domain="[('state', '!=','draft')]",string='Prestamos')


    #modificar a que el pago este en estado pagado

    @api.multi
    #@api.onchange('modalidad','estado','prestatario_id','fecha_desde','fecha_hasta')
    def buscar_loan(self):
        rec = None
        rec_list=[]
        dominio=[]
        con_datos = True
        
        if self.prestatario_id:
            dominio.append(('client_id','=',self.prestatario_id.id))

        if self.estado == 'todos':
            self.plazo_dias = False
            pass

        if self.estado == 'abierto':
            self.plazo_dias = False
            dominio.append(('state','=','open'))

        if self.estado == 'cerrado':
            self.plazo_dias = False
            dominio.append(('state','=','close'))

        if self.plazo_dias == 'todos':
            
            sql=''' SELECT loan_id from dev_loan_installment where vencida = True and state = 'unpaid' '''
            self.env.cr.execute(sql)
            result = self.env.cr.fetchall()
            loan_ids=[]
            if result:
                loan_ids=[i[0] for i in result]
                dominio.append(('id','in',loan_ids))
            else:
                con_datos = False


        if self.plazo_dias == '30':
            
            sql=''' SELECT loan_id from dev_loan_installment di where vencida = True and state = 'unpaid' and (select current_date - di.date)>=30 and (select current_date - di.date)<60 '''
            self.env.cr.execute(sql)
            result = self.env.cr.fetchall()
            loan_ids=[]
            if result:
                loan_ids=[i[0] for i in result]
                dominio.append(('id','in',loan_ids))
            else:
                con_datos = False

        if self.plazo_dias == '60':
            
            sql=''' SELECT loan_id from dev_loan_installment di where vencida = True and state = 'unpaid' and (select current_date - di.date)>=60 and (select current_date - di.date)<90 '''
            self.env.cr.execute(sql)
            result = self.env.cr.fetchall()
            loan_ids=[]
            
            if result:
                loan_ids=[i[0] for i in result]
                dominio.append(('id','in',loan_ids))
            else:
                con_datos = False

        if self.plazo_dias == '90':
            
            sql=''' SELECT loan_id from dev_loan_installment di where vencida = True and state = 'unpaid' and (select current_date - di.date)>=90 '''
            self.env.cr.execute(sql)
            result = self.env.cr.fetchall()
            loan_ids=[]
            if result:
                loan_ids=[i[0] for i in result]
                dominio.append(('id','in',loan_ids))
            else:
                con_datos = False

        if self.modalidad == 'mensual':
            dominio.append(('installment_type','=','month'))

        if self.modalidad == 'semanal':
            dominio.append(('installment_type','=','sem'))

        if self.modalidad == 'quincenal':
            dominio.append(('installment_type','=','quinc'))

        if self.modalidad == 'diario':
            dominio.append(('installment_type','=','day'))

        if self.fecha_desde:
            dominio.append(('request_date','>=',self.fecha_desde))

        if self.fecha_hasta:
            dominio.append(('request_date','<=',self.fecha_hasta))

        if self.ruta_id:
            dominio.append(('client_id.rute','=',self.ruta_id.id))

        prestamos = self.env['dev.loan.loan'].sudo().search(dominio)
            
        if prestamos and con_datos:
            self.prestamos_ids=[(6, 0, prestamos.ids)]

        else:
            self.prestamos_ids=[(5,0,0)]
        
            


    @api.multi
    def get_report(self):
        f_desde = f_hasta = None
        
        if self.fecha_desde:
            f_desde=datetime.strftime(self.fecha_desde,"%Y-%m-%d")
        if self.fecha_hasta:
            f_hasta=datetime.strftime(self.fecha_hasta,"%Y-%m-%d")

        hoy = datetime.now()
        hoy = hoy.strftime("%d/%m/%Y - %H:%M:%S")
        lista=[]
        for i in self.prestamos_ids:
            ff=datetime.strftime(i.request_date,"%d-%m-%Y")
            aux = (i.name, i.client_id.name,i.client_id.vat, i.loan_type_id.name,ff,i.loan_amount,i.interest_rate,i.state,i.client_id.rute.name)
            lista.append(aux)
        
        
        data = {
            'model': self._name,
            'ids': self.ids,
            'f_desde':f_desde,
            'f_hasta':f_hasta,
            'hoy':hoy,
            'tupla_datos':lista
            
            }

     
        
        return self.env.ref('dev_loan_management.report_consulta_saldos').report_action(self, data=data)














        # reporte  = '<h2>Consulta de saldos por Cliente</h2>'
        # reporte += '<table style="width:100%;">'
        # reporte += '   <thead style="border: thin solid gray;">'
        # reporte += '        <tr style="border: thin solid gray;">'
        # reporte += '            <th colspan="4" style="border: thin solid gray; text-align: center">Producto</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Meses</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Capital</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Intereses</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Total a pagar</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Saldo</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">C. Fija Mensual</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Quincenal</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Semanal</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Diaria</th>'
        # reporte += '        </tr style="border: thin solid gray;">'
        # reporte += '    </thead>'
        # reporte += '    <tbody>'



        # if rec:

        #     reporte += '        <tr style="border-bottom: thin solid gray;">'
        #     reporte += '            <td colspan="4" style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
            

        #     reporte += '        </tr>'
        #     reporte += '    </tbody></table >'

        #     self.tabla =reporte

    