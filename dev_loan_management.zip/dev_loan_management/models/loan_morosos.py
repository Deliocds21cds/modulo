# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from datetime import datetime, timedelta, date
#import cPickle as pickle
import _pickle as pickle
import json

class loan_morosos(models.TransientModel):
    _name = "loan.morosos"
    _rec_name = 'prestatario_id'


    def get_prestatario_id(self):
        try:
            return self._context['partner_id']
        except Exception as e:
            return True
         

    prestatario_id = fields.Many2one('res.partner',required=True,string='Buscar Prestatario',default=get_prestatario_id)
    fecha = fields.Date(required=True, default=fields.Date.context_today, string='Fecha')
    loan_id = fields.Many2one('dev.loan.loan', string='Préstamo',required=True)
    meses_atraso = fields.Integer(string='Meses de atraso',required=True)
    cartas = fields.Selection([
        ('carta1', 'Carta de Cobro 1'),
        ('carta2', 'Carta de Cobro 2'),
        ('carta3', 'Carta de Cobro 3'),
        ('compromiso', 'Compromiso de Pago'),
        ], string='Cartas', default='carta1')

    deuda = fields.Char(string='Importe deuda')
    # presta_context = fields.Integer(default=get_prestatario_id)
    
    def action_export(self):
    	print('test')


    def diff_month(self,d1, d2):
        return (d1.year - d2.year) * 12 + d1.month - d2.month

    @api.onchange('prestatario_id',)
    def _on_change_partner(self):
        self.loan_id = False
        if self.prestatario_id:
            loan = self.env['dev.loan.loan'].search([('client_id', '=', self.prestatario_id.id)])    
            ll=[]
            if loan:
                ll=[i.id for i in loan]

                return {
                    "domain": {
                        "loan_id": [("id", "in", ll)],
                    }
                }

    @api.onchange('prestatario_id', 'loan_id')
    def _onchange_prestatario_id(self):
        self.meses_atraso = 0
        if self.prestatario_id.id and self.loan_id:

            cuota = self.env['dev.loan.installment'].search([('client_id', '=', self.prestatario_id.id),('vencida', '=', True),('state', '=', 'unpaid'),('loan_id', '=', self.loan_id.id)], order='date desc')
            #cuotas_pagas= self.env['dev.loan.installment'].search([('client_id', '=', self.prestatario_id.id),('loan_id', '=', self.loan_id.id),('state', '=', 'paid')])
            #monto_total = self.loan_id.remaing_amount
            
            if cuota:
                for i in cuota:
                    hoy = datetime.now()
                    atraso=self.diff_month(hoy, cuota[0].date )
                    self.meses_atraso = atraso
            
            # para_json={'deuda':str(monto_total)}
            # self.deuda=json.dumps(para_json)
            # print(self.deuda,'onchange')
            
        
    @api.multi
    def get_report(self):
        meses ={'0':'cero',
        '1':'un','2':'dos','3':'tres','4':'cuatro','5':'cinco','6':'seis','7':'siete','8':'ocho',
        '9':'nueve','10':'diez','11':'once','12':'doce','13':'trece','14':'catorce','15':'quince','16':'dieciseis'
        ,'17':'diecisiete','18':'dieciocho','19':'diecinueve','20':'veinte','21':'veintiuno','22':'venitidos','23':'veintitres','24':'veinticuatro'}
        f_fecha= self.fecha.strftime("%d %B %Y")
        name = self.prestatario_id.name
        dia_siguiente = self.fecha + timedelta(days=1)

        while date.weekday(dia_siguiente) not in range(0,5):
            dia_siguiente = dia_siguiente + timedelta(days=1)

        dia_siguiente = dia_siguiente.strftime("%A %d de %B %Y")
        # print(self.deuda,'deuda?')
        # deuda=json.loads(self.deuda)

        cuotas_pagas= self.env['dev.loan.installment'].search([('client_id', '=', self.prestatario_id.id),('loan_id', '=', self.loan_id.id),('state', '=', 'paid')])
        monto_total = self.loan_id.remaing_amount
        if cuotas_pagas:
                for i in cuotas_pagas:
                    monto_total = monto_total - i.total_amount

        codeudores = self.env['res.partner'].search([('parent_id', '=', self.prestatario_id.id)])
        documento = self.prestatario_id.vat
        cod = name
        codydocs = 'y '
        firma = []
        firma.append((self.prestatario_id.name, self.prestatario_id.vat, '____________________________'))
        
        if codeudores:

            for i in codeudores:
                firma.append((i.name, i.vat, '____________________________'))
                codydocs += i.name + u' con cédula número '+i.vat+' de '+i.expedicion_lugar+', '
    
  

        data = {
            'model': self._name,
            'ids': self.ids,
            'fecha':f_fecha,
            'mes':meses[str(self.meses_atraso)] if meses[str(self.meses_atraso)] else '',
            'mes_num':self.meses_atraso,
            'name':name,
            'dia_siguiente': dia_siguiente,
            'deuda':round(monto_total,2),
            'codeudores':cod,
            'documento':documento,
            'codydocs':codydocs,
            'firma':firma,
            
            }
                
        if self.cartas == 'carta1':
            return self.env.ref('dev_loan_management.report_carta_1').report_action(self, data=data)
        if self.cartas == 'carta2':
            return self.env.ref('dev_loan_management.report_carta_2').report_action(self, data=data)
        if self.cartas == 'carta3':
            return self.env.ref('dev_loan_management.report_carta_3').report_action(self, data=data)
        if self.cartas == 'compromiso':
            return self.env.ref('dev_loan_management.report_compromiso').report_action(self, data=data)

    # @api.model
    # def _get_report_values(self, docids, data=None):
    #     report_obj = self.env['ir.actions.report']
    #     report = report_obj._get_report_from_name('dev_loan_management.report_carta_1')
    #     docargs = {
    #         'doc_ids': docids,
    #         'doc_model': report.model,
    #         'docs': self
    #     }
    #     return docargs
        
        # docargs = {
        # 'docs': self,
        # 'doc_ids': self._ids,
        #'doc_model': loan.morosos,
        # 'razon_social':razon_social,
        # 'rut':rut,
        # 'meses_en_reporte':self.meses_en_reporte,
        # 'doc_employee':self.doc_employee,
        # 'name_employee':self.name_employee,
        #'imponible': search_employee()

        #'importes_para_reporte':self.importes_para_reporte( data),
        
        # }
        #return self.env.ref('dev_loan_management.report_carta_1').report_action(self, data=docargs, config=False)
        #return report_obj.render('dev_loan_management.carta_1_template', docargs)
