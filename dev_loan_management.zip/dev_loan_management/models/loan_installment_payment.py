from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_compare



class loan_installment_payment(models.Model):
    _inherit = "account.payment"
    _description = "Loan Payment"
    _order = "payment_date desc, name desc"

    loan_id = fields.Many2one('dev.loan.loan', string='Préstamo', domain="[('sate', 'not in', ('draft','close','reject'))]")
    code = fields.Char('Código')
    saldo_actual = fields.Float('Saldo Actual')
    capital = fields.Float('Capital Actual')
    intereses_a_fecha = fields.Float('Intereses a la Fecha')
    saldo_nuevo = fields.Float('Nuevo saldo después de este pago')
    efectivo = fields.Boolean('Efectivo')
    consignacion = fields.Boolean('Consignación')
    banco = fields.Char(string='Banco')
    cheque = fields.Boolean('Cheque')
    número_cheque = fields.Char('Número de Cheque')
    notes = fields.Text('Observaciones')
    #payment_type = fields.Selection([('desembolso', 'Desembolso'), ('cuota_abonos', 'Pago de Cuotas o Abonos'), ('interna', 'Transferencia Interna')], string='Tipo de Pago',
    #                                required=True)
    payment_type = fields.Selection([('outbound', 'Desembolso'), ('inbound', 'Pago de Cuotas o Abonos'), ('transfer', 'Transferencia Interna')], string='Tipo de Pago',
                                    required=True)

    a_pagar = fields.Selection([('todo','Total'),('intereses','Solo Intereses'),('capital','Solo Capital')],string='Paga',
                                    required=True, default='todo')



    @api.onchange('code','partner_id','loan_id')
    def _on_change_code(self):
        
        if self.code and not self.partner_id:
            partner = self.env['res.partner'].search([('code', '=', self.code)])
            
            if self.code and partner:
                self.partner_id=(partner[0].id)
            #sa=sn=cap=inter=lo=0
        
        if not self.code and self.partner_id:
            if self.partner_id.code:
                self.code = self.partner_id.code

        if self.code and self.partner_id:
            if self.partner_id.code:
                if self.partner_id.code != self.code:
                    self.code = self.partner_id.code
            else:
                self.code = ''
                
        for record in self:
            for l in self.loan_id:
                record.saldo_actual = l.loan_amount
                record.saldo_nuevo = record.saldo_actual
                record.capital = 0
                record.intereses_a_fecha = 0
                record.loan_id = l.id

                for installment in l.installment_ids:
                    if installment.loan_state in ('paid'):
                        record.saldo_actual = record.saldo_actual - installment.amount
                        record.capital = record.capital + installment.amount
                        record.intereses_a_fecha = record.intereses_a_fecha + installment.interest
                        record.saldo_nuevo = record.saldo_actual - installment.amount


    @api.onchange('partner_id',)
    def _on_change_partner(self):
        if self.partner_id:
            loan = self.env['dev.loan.loan'].search([('client_id', '=', self.partner_id.id)])    
            ll=[]
            if loan:
                ll=[i.id for i in loan]

                return {
                    "domain": {
                        "loan_id": [("id", "in", ll)],
                    }
                }


    @api.multi
    def _compute_installment(self):
        if self.code:
            loan = self.env['dev.loan.loan'].search([('client_id.code', '=', self.code)])
            for record in self:
                for l in loan:
                    record.saldo_actual = loan.loan_amount
                    record.saldo_nuevo = record.saldo_actual
                    record.capital = 0
                    record.intereses_a_fecha = 0
                    record.loan_id = l.id

                    for installment in l.installment_ids:
                        if installment.loan_state in ('paid'):
                            record.saldo_actual = record.saldo_actual - installment.amount
                            record.capital = record.capital + installment.amount
                            record.intereses_a_fecha = record.intereses_a_fecha + installment.interest
                            record.saldo_nuevo = record.saldo_actual - installment.amount

