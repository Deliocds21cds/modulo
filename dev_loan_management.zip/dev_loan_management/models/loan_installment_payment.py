from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_compare
import logging
_logger = logging.getLogger(__name__)

class loan_installment_payment(models.Model):
    _inherit = "account.payment"
    _description = "Loan Payment"
    _order = "payment_date desc, name desc"


    def get_partner_id(self):
        try:
            return self._context['partner_id']
        except Exception as e:
            return True
    
    # def get_loan_id(self):
    #     try:
    #         print(self._context['loan_id'],'llega???')
    #         return self._context['loan_id']

    #     except Exception as e:
    #         return True   
     
    partner_id = fields.Many2one('res.partner',required=True, default=get_partner_id)
    loan_id = fields.Many2one('dev.loan.loan', string='Préstamo', domain="[('state', 'not in', ('draft','close','reject'))]")
    code = fields.Char('Código')
    saldo_actual = fields.Float('Saldo Actual')
    capital = fields.Float('Capital Actual')
    intereses_a_fecha = fields.Float('Intereses a la Fecha')
    saldo_nuevo = fields.Float('Nuevo saldo después de este pago')
    efectivo = fields.Boolean('Efectivo')
    consignacion = fields.Boolean('Consignación')
    banco = fields.Char(string='Banco')
    cheque = fields.Boolean('Cheque')
    número_cheque = fields.Char('Número de Cheque')
    notes = fields.Text('Observaciones')
    #payment_type = fields.Selection([('desembolso', 'Desembolso'), ('cuota_abonos', 'Pago de Cuotas o Abonos'), ('interna', 'Transferencia Interna')], string='Tipo de Pago',
    #                                required=True)
    payment_type = fields.Selection([('outbound', 'Desembolso'), ('inbound', 'Pago de Cuotas o Abonos'), ('transfer', 'Transferencia Interna')], string='Tipo de Pago',
                                    required=True, default='inbound')

    a_pagar = fields.Selection([('todo','Total'),('intereses','Solo Intereses'),('capital','Solo Capital')],string='Paga',
                                    required=True, default='todo')

    reporta = fields.Selection([('oficina','Oficina / El Cliente'),('cobrador','Cobrador')],string='Reporta el Pago',
                                    required=True, default='oficina')
    cobrador_id = fields.Many2one('res.partner', string='Cobrador', domain="[('is_collector', '=', True)]")
    
    # @api.multi
    # @api.onchange('code','partner_id')
    # def onchange_ppartner_id_loan(self):
    #     variant_ids_list = []
    #     print ('llega_??,',self._context.get('loan_id'))
    #     if self._context.get('loan_id'):
    #         variant_ids_list.append(self._context.get('loan_id'))
    #         return {
    #                     "domain": {
    #                         "loan_id": [("id", "in", variant_ids_list)],
    #                     }
    #                 }



    @api.onchange('code','partner_id','loan_id','a_pagar')
    def _on_change_code(self):
        
        if self._context.get('total_amount') and self.a_pagar == 'todo':
            self.amount = self._context.get('total_amount')
        if self._context.get('amount') and self.a_pagar == 'capital':
            self.amount = self._context.get('amount')
        if self._context.get('interest') and self.a_pagar == 'intereses':
            self.amount = self._context.get('interest')

        
        if self.code and not self.partner_id:
            partner = self.env['res.partner'].search([('code', '=', self.code)])
            
            if self.code and partner:
                self.partner_id=(partner[0].id)
            #sa=sn=cap=inter=lo=0
        
        if not self.code and self.partner_id:
            if self.partner_id.code:
                self.code = self.partner_id.code

        if self.code and self.partner_id:
            if self.partner_id.code:
                if self.partner_id.code != self.code:
                    self.code = self.partner_id.code
            else:
                self.code = ''
                
        for record in self:
            for l in self.loan_id:
                record.saldo_actual = l.loan_amount
                record.saldo_nuevo = record.saldo_actual
                record.capital = 0
                record.intereses_a_fecha = 0
                record.loan_id = l.id

                for installment in l.installment_ids:
                    if installment.loan_state in ('paid'):
                        record.saldo_actual = record.saldo_actual - installment.amount
                        record.capital = record.capital + installment.amount
                        record.intereses_a_fecha = record.intereses_a_fecha + installment.interest
                        record.saldo_nuevo = record.saldo_actual - installment.amount


    @api.onchange('partner_id',)
    def _on_change_partner(self):
        if self.partner_id:
            loan = self.env['dev.loan.loan'].search([('client_id', '=', self.partner_id.id)])    
            ll=[]
            if loan:
                ll=[i.id for i in loan]

                return {
                    "domain": {
                        "loan_id": [("id", "in", ll)],
                    }
                }


    @api.multi
    def _compute_installment(self):
        if self.code:
            loan = self.env['dev.loan.loan'].search([('client_id.code', '=', self.code)])
            for record in self:
                for l in loan:
                    record.saldo_actual = loan.loan_amount
                    record.saldo_nuevo = record.saldo_actual
                    record.capital = 0
                    record.intereses_a_fecha = 0
                    record.loan_id = l.id

                    for installment in l.installment_ids:
                        if installment.loan_state in ('paid'):
                            record.saldo_actual = record.saldo_actual - installment.amount
                            record.capital = record.capital + installment.amount
                            record.intereses_a_fecha = record.intereses_a_fecha + installment.interest
                            record.saldo_nuevo = record.saldo_actual - installment.amount



    @api.multi
    def post(self):
        res = super(loan_installment_payment,self).post()
        cuota_id = self._context.get('cuota_id')
        if cuota_id:
            cuota = self.env['dev.loan.installment'].search([('id', '=', cuota_id)])
            paga = self.amount
            if self.a_pagar == 'todo':
                saldo_capital = cuota.saldo_capital
                saldo_interes = cuota.saldo_interes
                le_queda = ( saldo_capital +  saldo_interes) - paga
                if le_queda > 0:
                    cuota.saldo_capital = le_queda

                if le_queda < 0:
                    cuotas_sin_pagar = self.env['dev.loan.installment'].search([('loan_id', '=', cuota.loan_id.id),('state', '=', 'unpaid'),('id', 'not in', [cuota.id])],order='id asc', limit=1)
                    #aqui le resto al capital lo que me sobro de la cuota pasada.
                    print(cuotas_sin_pagar.name,'test')
                    #cuota.saldo_capital = le_queda
                
                cuota.state = 'paid'
                #Puede pagar menos, mas o igual
                #Si cubre la cuota entonces cambio el estado a pago

            if self.a_pagar == 'capital':
                pass    
            if self.a_pagar == 'intereses':
                pass
            
            #cuota.state = "paid"
        return res