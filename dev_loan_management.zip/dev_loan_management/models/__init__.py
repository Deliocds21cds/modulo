# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2015 DevIntelle Consulting Service Pvt.Ltd (<http://www.devintellecs.com>).
#
#    For Module Support : devintelle@gmail.com  or Skype : devintelle
#
##############################################################################

from . import loan_proof
from . import loan_type
from . import res_partner
from . import dev_loan_loan
from . import dev_loan_installment
from . import res_company
from . import res_config_setting
from . import loan_rute
from . import loan_document_type
from . import loan_article_category
from . import loan_garment_material
from . import loan_garment_type
from . import loan_sales_equipment
from . import loan_vehicle_capacity
from . import loan_vehicle_class
from . import loan_vehicle_model
from . import contract
from . import loan_article_state
from . import loan_interval_payment
from . import loan_installment_payment
from . import loan_morosos
from . import loan_consulta_saldos
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
