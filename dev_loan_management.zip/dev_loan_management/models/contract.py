# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2015 DevIntelle Consulting Service Pvt.Ltd (<http://www.devintellecs.com>).
#
#    For Module Support : devintelle@gmail.com  or Skype : devintelle
#
##############################################################################

from odoo import models, fields, api, _
from datetime import datetime, date, timedelta
from dateutil.relativedelta import relativedelta


class account_invoice(models.Model):
    _inherit = ['contract.contract']

    #contract_number = fields.Char('Número de Contrato')
    #client_name = fields.Char('Cliente')
    #client_address = fields.Text(string='Dirección')
    #client_phone = fields.Char('Teléfono')

    #interval_payment = fields.Many2one('loan.interval.payment', string='Plazos de Pago', ondelete='restrict')

    article_category = fields.Selection(string='Categoría del Artículo', default='garment',
                                    selection=[('garment', 'Joya'), ('elec', 'Electrodoméstico'),
                                               ('vehicle', 'Vehículo')])
    tipo_articulo = fields.Selection(string='Tipo del Artículo',default='articulo',
                                    selection=[('prenda', 'Prenda'), ('articulo', 'Artículo'),
                                               ('carro', 'Carro'),('moto', 'Moto'),('bicicleta', 'Bicicleta')])
    article_state = fields.Many2one('loan.article.state', string='Estado del Artículo', ondelete='restrict')
    notes = fields.Text(string='Observaciones')
    borrowed_money = fields.Float('Dinero Prestado')
    facture_date = fields.Date('Fecha de Factura')
    venc_date = fields.Date('Fecha de Vencimiento')

    sales_equipment = fields.Many2one('loan.sales.equipment', string='Equipo de Ventas', ondelete='restrict')

    garment_type = fields.Many2one('loan.garment.type', string='Tipo de Prenda', ondelete='restrict')
    garment_material = fields.Many2one('loan.garment.material', string='Material', ondelete='restrict')
    weight = fields.Float('Peso (Gramos)')
    garment_notes = fields.Text(string='Observaciones a la Prenda')

    elec_brand = fields.Char('Marca')
    elec_model = fields.Char('Modelo')
    elec_serial = fields.Char('No. de Serie')
    elec_color = fields.Char('Color')
    elec_notes = fields.Text(string='Observaciones')

    vehicle_plate = fields.Char('Placa No')
    vehicle_class = fields.Many2one('loan.vehicle.class', string='Clase', ondelete='restrict')
    vehicle_brand = fields.Char('Marca')
    vehicle_model = fields.Many2one('loan.vehicle.model', string='Modelo', ondelete='restrict')
    vehicle_color = fields.Char('Color')
    vehicle_motor = fields.Char('No. Motor')
    vehicle_chasis = fields.Char('Número de Chasis')
    vehicle_capacity = fields.Many2one('loan.vehicle.capacity', string='Capacidad Pasajeros', ondelete='restrict')

    @api.onchange('tipo_articulo', 'article_category')
    def _onchange_tipo_articulo(self):
        code_name = ''
        if self.tipo_articulo == 'prenda':
            code_name = 'contract.prenda'
        if self.tipo_articulo == 'articulo':
            code_name = 'contract.articulo'
        if self.tipo_articulo == 'carro':
            code_name = 'contract.carro'
        if self.tipo_articulo == 'moto':
            code_name = 'contract.moto'
        if self.tipo_articulo == 'bicicleta':
            code_name = 'contract.bicicleta'

        find_name=self.env['ir.sequence'].next_by_code(code_name)
        if find_name:
            self.name = find_name
        else:
            self.name= '/'

    def last_day_of_month(self,date):
        if date.month == 12:
            return date.replace(day=31)
        return date.replace(month=date.month+1, day=1) - timedelta(days=1)


    @api.onchange('payment_term_id')
    def _onchange_venc_date(self):
        hoy = datetime.now()

        if self.payment_term_id.name == 'Pago inmediato':
            hoy = hoy.strftime("%Y-%m-%d")
            self.venc_date = hoy
        
        if self.payment_term_id.name == '15 Días':
            date = hoy + relativedelta(days = 15)
            self.venc_date = date.strftime("%Y-%m-%d")
        
        if self.payment_term_id.name == '30 Días':
            date = hoy + relativedelta(days = 30)
            self.venc_date = date.strftime("%Y-%m-%d")

        if self.payment_term_id.name == '45 Días':
            date = hoy + relativedelta(days = 45)
            self.venc_date = date.strftime("%Y-%m-%d")

        if self.payment_term_id.name == '2 Meses':
            date = hoy + relativedelta(months=1)
            self.venc_date = date.strftime("%Y-%m-%d")

        if self.payment_term_id.name == 'Fin de Mes Siguiente':
            date = hoy + relativedelta(months=1)
            date = self.last_day_of_month(date)
            self.venc_date = date.strftime("%Y-%m-%d")   





