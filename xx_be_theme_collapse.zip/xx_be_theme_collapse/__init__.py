# -*- coding: utf-8 -*-
# Part of Xao Xao Digital CO.,LTD. See LICENSE file for full copyright and licensing details.
