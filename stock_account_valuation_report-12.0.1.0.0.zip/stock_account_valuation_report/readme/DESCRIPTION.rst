When you trigger a report of inventory valuation, and you use
perpetual inventory, you should be able to reconcile the valuation
from an inventory perspective with the valuation
from an accounting perspective.

This module changes the report in *Inventory / Reporting / Inventory Valuation*
to display separately the Quantity and Value of each product for the
Inventory and the Accounting systems .
