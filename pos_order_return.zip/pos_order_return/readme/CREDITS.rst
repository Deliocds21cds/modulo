Funders
~~~~~~~

The development of this module has been financially supported by:

* La Louve (www.lalouve.net)
* GRAP, Groupement Régional Alimentaire de Proximité (www.grap.coop)
