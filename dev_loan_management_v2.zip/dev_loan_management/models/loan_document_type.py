from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from datetime import datetime, date
from dateutil.relativedelta import relativedelta

class loan_document_type(models.Model):
    _name = 'loan.document.type'
    _order = 'name'


    name = fields.Char('Name')
    code = fields.Char('Code')