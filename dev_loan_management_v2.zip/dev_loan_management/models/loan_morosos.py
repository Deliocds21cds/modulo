# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class loan_morosos(models.TransientModel):
    _name = "loan.morosos"
    prestatario_id = fields.Many2one('res.partner',string='Buscar Prestatario')
    fecha = fields.Date(required=True, default=fields.Date.context_today, string='Fecha')
    meses_atraso = fields.Integer(string='Meses de atraso', default=3, required=True)
    cartas = fields.Selection([
        ('carta1', 'Carta de Cobro 1'),
        ('carta2', 'Carta de Cobro 2'),
        ('carta3', 'Carta de Cobro 3'),
        ('compromiso', 'Compromiso de Pago'),
        ], string='Cartas', default='carta1')

    def action_export(self):
    	print('test')


    @api.multi
    def get_report(self):
        data = {
            'model': self._name,
            'ids': self.ids,
            'form': {
                'date_start': self.fecha, 'date_end': self.meses_atraso,
            },
        }

        if self.cartas == 'carta1':
            return self.env.ref('dev_loan_management.report_carta_1').report_action(self, data=data)
        if self.cartas == 'carta2':
            return self.env.ref('dev_loan_management.report_carta_2').report_action(self, data=data)
        if self.cartas == 'carta3':
            return self.env.ref('dev_loan_management.report_carta_3').report_action(self, data=data)
        if self.cartas == 'compromiso':
            return self.env.ref('dev_loan_management.report_compromiso').report_action(self, data=data)

    # @api.model
    # def _get_report_values(self, docids, data=None):
    #     report_obj = self.env['ir.actions.report']
    #     report = report_obj._get_report_from_name('dev_loan_management.report_carta_1')
    #     docargs = {
    #         'doc_ids': docids,
    #         'doc_model': report.model,
    #         'docs': self,
    #     }
    #     return docargs
        
        # docargs = {
        # 'docs': self,
        # 'doc_ids': self._ids,
        #'doc_model': loan.morosos,
        # 'razon_social':razon_social,
        # 'rut':rut,
        # 'meses_en_reporte':self.meses_en_reporte,
        # 'doc_employee':self.doc_employee,
        # 'name_employee':self.name_employee,
        #'imponible': search_employee()

        #'importes_para_reporte':self.importes_para_reporte( data),
        
        # }
        #return self.env.ref('dev_loan_management.report_carta_1').report_action(self, data=docargs, config=False)
        #return report_obj.render('dev_loan_management.carta_1_template', docargs)
