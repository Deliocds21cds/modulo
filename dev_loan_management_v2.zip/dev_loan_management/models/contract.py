# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2015 DevIntelle Consulting Service Pvt.Ltd (<http://www.devintellecs.com>).
#
#    For Module Support : devintelle@gmail.com  or Skype : devintelle
#
##############################################################################

from odoo import models, fields, api, _


class account_invoice(models.Model):
    _inherit = ['contract.contract']

    #contract_number = fields.Char('Número de Contrato')
    #client_name = fields.Char('Cliente')
    #client_address = fields.Text(string='Dirección')
    #client_phone = fields.Char('Teléfono')

    #interval_payment = fields.Many2one('loan.interval.payment', string='Plazos de Pago', ondelete='restrict')

    article_category = fields.Selection(string='Categoría del Artículo', default='garment',
                                    selection=[('garment', 'Joya'), ('elec', 'Electrodoméstico'),
                                               ('vehicle', 'Vehículo')])
    article_state = fields.Many2one('loan.article.state', string='Estado del Artículo', ondelete='restrict')
    notes = fields.Text(string='Observaciones')
    borrowed_money = fields.Float('Dinero Prestado')
    facture_date = fields.Date('Fecha de Factura')
    venc_date = fields.Date('Fecha de Vencimiento')

    sales_equipment = fields.Many2one('loan.sales.equipment', string='Equipo de Ventas', ondelete='restrict')

    garment_type = fields.Many2one('loan.garment.type', string='Tipo de Prenda', ondelete='restrict')
    garment_material = fields.Many2one('loan.garment.material', string='Material', ondelete='restrict')
    weight = fields.Float('Peso (Gramos)')
    garment_notes = fields.Text(string='Observaciones a la Prenda')

    elec_brand = fields.Char('Marca')
    elec_model = fields.Char('Modelo')
    elec_serial = fields.Char('No. de Serie')
    elec_color = fields.Char('Color')
    elec_notes = fields.Text(string='Observaciones')

    vehicle_plate = fields.Char('Placa No')
    vehicle_class = fields.Many2one('loan.vehicle.class', string='Clase', ondelete='restrict')
    vehicle_brand = fields.Char('Marca')
    vehicle_model = fields.Many2one('loan.vehicle.model', string='Modelo', ondelete='restrict')
    vehicle_color = fields.Char('Color')
    vehicle_motor = fields.Char('No. Motor')
    vehicle_chasis = fields.Char('Número de Chasis')
    vehicle_capacity = fields.Many2one('loan.vehicle.capacity', string='Capacidad Pasajeros', ondelete='restrict')

