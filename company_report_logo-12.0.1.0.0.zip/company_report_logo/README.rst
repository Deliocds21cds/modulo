.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
   :target: https://www.gnu.org/licenses/agpl-3.0-standalone.html
   :alt: License: AGPL-3

Company Report Logo
===================

Agrega un campo binary para agregarlo a nivel de compañia y usarlo en los
informes
