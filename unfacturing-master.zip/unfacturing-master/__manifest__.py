# -*- coding: utf-8 -*-
{
   'name': "Desfacturación",

    'description': """
        Este modulo sirve para hacer facturas sin que sean contabilizadas
    """,

    'author': "Digilab Peru",
    'category': 'stock',
    'contributors': [
        'Omar Barron<omar.barron@digilab.pe>',
        'Luis Alva<luis.alva@digilab.pe>',
        'Jorge Escobar<jorge.escobar@digilab.pe>'
    ],
    'version': '1.0',

    # any module necessary for this one to work correctly
    'depends': ['base','account','stock'],

    # always loaded
    'data': [
        'security/ir.model.access.xml',
        'views/views.xml',
        'views/wizard.xml',
        'data/sequence.xml'
    ],
    # only loaded in demonstration mode
    'demo': [
    ],
}