# -*- coding: utf-8 -*-
from datetime import datetime
from odoo.exceptions import Warning, UserError
from odoo import models, fields, _, api
import logging
_logger = logging.getLogger(__name__)
class UnfacturingWizard(models.TransientModel):
    _name='unfacturing.wizard'

    amount = fields.Float('Cantidad a Pagar', required=True)
    journal_id = fields.Many2one(comodel_name='account.journal', string='Diario de Pago', required=True)
    payment_date = fields.Datetime(string="Fecha de Pago",required=True, default=datetime.today())
    communication = fields.Char(string="Circular", default=lambda self: self._get_default_status())

    @api.model 
    def _get_unfacturing_id(self): 
        if self.env.context.get('unfacturing_id'): 
            return self.env.context.get('unfacturing_id')

    def validar_pago(self):
        self.env['unfacturing.payments'].sudo().create({
            "amount":self.amount,
            "unfacturing_id":self._get_unfacturing_id(),
            "journal_id":self.journal_id.id,
            "communication":self.communication,
            "payment_date":self.payment_date
        })
    
    @api.model 
    def _get_default_status(self): 
        if self.env.context.get('circular'): 
            return self.env.context.get('circular')