# -*- coding: utf-8 -*-
import logging
from odoo import models, fields, api
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)


class HistoryMaintenance(models.Model):
    _name = 'l10n_co_cei.history'

    company_id = fields.Many2one(
        'res.company',
        string='Compañia',
        default=lambda self: self.env.user.company_id.id,
    )
    fecha_hora = fields.Datetime(
        string='Fecha y hora'
    )
    actividad = fields.Char(
        string='Descripcion'
    )
    factura = fields.Many2one(
        'account.invoice',
        string='Factura'
    )
    estado = fields.Selection(
        (
            ('draft','Draft'),
            ('open', 'Open'),
            ('in_payment', 'In Payment'),
            ('paid', 'Paid'),
            ('cancel', 'Cancelled')
        ),
        'Estado',
        default='',
        copy=False
    )
    estado_validacion = fields.Selection(
        (
            ('sin-calificacion', 'Sin calificar'),
            ('aprobada', 'Aprobada'),
            ('aprobada_sistema', 'Aprobada por el Sistema'),
            ('rechazada', 'Rechazada')
        ),
        'Respuesta Cliente',
        default='',
        copy=False
    )
    estado_dian = fields.Char(
        string='Respuesta DIAN'
    )
    type = fields.Char(
        string='Tipo de Documento'
    )