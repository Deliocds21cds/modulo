#-*- coding:utf-8 -*-
from odoo import models, api, _, fields
from odoo.exceptions import ValidationError
import logging


class currency(models.Model):
    _inherit = ['res.currency']

    long_name = fields.Char(string='Nombre largo')
