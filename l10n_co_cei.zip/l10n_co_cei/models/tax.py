# -*- coding: utf-8 -*-

from odoo import models, api, fields
from odoo.exceptions import ValidationError
import logging

_logger = logging.getLogger(__name__)

class Tax(models.Model):
    _inherit = 'account.tax'

    codigo_fe_dian = fields.Char(
        string='Código DIAN',
        compute='compute_codigos_dian'
    )

    nombre_tecnico_dian = fields.Char(
        string='Nombre técnico DIAN',
        compute='compute_codigos_dian'
    )

    tipo_impuesto = fields.Many2one(
        'l10n_co_cei.tax_type',
        string='Tipo De Impuesto'
    )

    fe_habilitada_compania = fields.Boolean(
        string='FE Compañía',
        compute='compute_fe_habilitada_compania',
        store=False,
        copy=False
    )

    @api.multi
    @api.depends('codigo_fe_dian')
    def compute_fe_habilitada_compania(self):
        for record in self:
            if record.company_id:
                record.fe_habilitada_compania = record.company_id.fe_habilitar_facturacion
            else:
                record.fe_habilitada_compania = self.env.user.company_id.fe_habilitar_facturacion

    @api.depends('tipo_impuesto')
    def compute_codigos_dian(self):
        for tax in self:
            if tax.tipo_impuesto:
                tax.codigo_fe_dian = tax.tipo_impuesto.code
                tax.nombre_tecnico_dian = tax.tipo_impuesto.description