{
    'name': 'Change point key numpad by comma',
    'version': '1.0',
    'category': 'Accounting Management',
    'description': """Change point key numpad by comma.
""",
    'author': 'PROSBOL',
    'website': 'https://www.prosbol.com/',
    'images': [],
    'license': 'AGPL-3',
    'depends': ['account'],
    'data': [
        'views/res_user_config_views.xml',
    ],
    'demo': [],
    'test': [],
    'qweb': [],
    'active': True,
    'installable': True,
    'auto_install': False,
}