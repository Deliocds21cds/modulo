# -*- coding: utf-8 -*-
###############################################################################
# Odoo - Open Source Management Solution
# Copyright (C) 2021 - Today Digilab Peru (<https://www.digilab.pe>)
###############################################################################
{
    'name': "Pos Not Counting",
    'version': '1.1',
    'depends': ['base'],
    'author': "Digilab Perú",
    'category': 'stock',
    'contributors': [
        'Omar Barron',
        'Luis Alva'
    ],
    'description': """
     Modulo que Sirve para Crear un Punto de Venta pero Que no lo Contabilice
     ----------------------
    """,
    'depends' : [
        "point_of_sale"
    ],
    # data files always loaded at installation
    'data': [
        "data/PosConfig.xml",
        "views/PosConfigInherit_views.xml"
    ],
    # data files containing optionally loaded demonstration data
    'demo': [
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
    "sequence": 1,    
}