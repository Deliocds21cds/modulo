# -*- coding: utf-8 -*-
###############################################################################
# Odoo - Open Source Management Solution
###############################################################################
{
    'name': "Pos Not Counting",
    'version': '1.2',
    'depends': ['base'],
    'category': 'stock',
    'description': """
     Modulo que Sirve para Crear un Punto de Venta pero Que no lo Contabilice
     Se agrego una secuencia diferente para el Pos Sin Contabilizar
     ----------------------
    """,
    'depends' : [
        "point_of_sale"
    ],
    # data files always loaded at installation
    'data': [
        "data/sequence.xml",        
        "data/PosConfig.xml",
        "views/PosConfigInherit_views.xml"
    ],
    # data files containing optionally loaded demonstration data
    'demo': [
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
    "sequence": 1,    
}