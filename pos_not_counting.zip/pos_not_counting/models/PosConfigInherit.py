# -*- coding: utf-8 -*- 
from odoo import api, fields, models, _

class PosConfigInherit(models.Model):
    _inherit = "pos.config"

    contabilizar = fields.Boolean(string="Contabilizar",default = True)


