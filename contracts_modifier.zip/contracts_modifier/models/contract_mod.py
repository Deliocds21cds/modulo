# -*- coding: utf-8 -*-

from odoo import models, fields, api
import logging
_logger = logging.getLogger(__name__)
    
class ContractMod(models.Model):
    _inherit = ['contract.contract']
    
    
    name = fields.Char('name', readonly=True, select=True, copy=False, default='New')
    interest1 = fields.Float('Interés', required=True)
    tipo_articulo2 = fields.Selection([
            ('bicicleta','Bicicleta'),
            ('articulo','Artículo'),
            ('prenda','Prenda'),
            ('moto','Moto'),
            ('carro','Carro')
        ], required=True, string="Tipo de Artículo", store=True)
    estado_articulo = fields.Selection([
            ('empenhado','Empenhado'),
            ('vencido','Vencido'),
            ('retired','Retirado')
        ], required=True, string="Estado de Artículo")
    thing_type = fields.Many2many(comodel_name='loan.garment.type',string='Tipo de prenda')
    material_done = fields.Many2many(comodel_name='loan.garment.material', string='Material')
    state = fields.Selection([
            ('draft','Borrador'),
            ('open', 'Abierta'),
            ('finished', 'Finalizado'),
        ], string='Estado', index=True, readonly=True, default='draft',
        track_visibility='onchange', copy=False)
    
    @api.depends('tipo_articulo2')
    @api.model
    def create(self, vals):
        obj = super(ContractMod,self).create(vals)
        if obj.name == 'New':
            code_name = ''
            _logger.info("==========================%s",vals['tipo_articulo2'])
            if vals['tipo_articulo2'] == 'prenda':
                code_name = 'contract.prenda'
            if vals['tipo_articulo2'] == 'articulo':
                code_name = 'contract.articulo'
            if vals['tipo_articulo2'] == 'carro':
                code_name = 'contract.carro'
            if vals['tipo_articulo2'] == 'moto':
                code_name = 'contract.moto'
            if vals['tipo_articulo2'] == 'bicicleta':
                code_name = 'contract.bicicleta'
            _logger.info("Heyyy%s",code_name)
            number = self.env['ir.sequence'].next_by_code(code_name) or 'New'
            obj.write({'name':number,'state':'open'})
        return obj
    
    @api.onchange('tipo_articulo2')
    def onchange_diario(self):
        journal_id = 1
        if self.tipo_articulo2 == 'prenda':
            journal_id = self.env['account.journal'].search([('name','=','Prendas')]).id
        if self.tipo_articulo2 == 'articulo':
            journal_id = self.env['account.journal'].search([('name','=','Articulos')]).id
        if self.tipo_articulo2 == 'moto':
            journal_id = self.env['account.journal'].search([('name','=','Motos')]).id
        if self.tipo_articulo2 == 'carro':
            journal_id = self.env['account.journal'].search([('name','=','Carros')]).id
        if self.tipo_articulo2 == 'bicicleta':
            journal_id = self.env['account.journal'].search([('name','=','Bicicletas')]).id
        self.journal_id = journal_id

    @api.model
    def get_empenhadas(self,item):
        contratos=self.env['contract.contract'].search([('tipo_articulo2','=',item),('estado_articulo','=','empenhado')])
        return len(contratos)

    @api.model
    def get_vencidos(self,item):
        contratos=self.env['contract.contract'].search([('tipo_articulo2','=',item),('estado_articulo','=','vencido')])
        return len(contratos)

    @api.model
    def get_retiradas(self,item):
        contratos=self.env['contract.contract'].search([('tipo_articulo2','=',item),('estado_articulo','=','retired')])
        return len(contratos)

    @api.model
    def get_total(self,item):
        return self.get_empenhadas(item) + self.get_vencidos(item) + self.get_retiradas(item)

    @api.model
    def get_contracs(self):             
        informes=self.env['contract.contract'].search([])
        return informes

    @api.model
    def get_capital(self,item):
        contratos=self.env['contract.contract'].search([('tipo_articulo2','=',item)])
        capital=0
        for contrato in contratos:
            pagos= self.env['contract.payments'].search([('contract_id','=',contrato.id)])
            for pago in pagos:
                capital+=pago.capital
        return capital

    @api.model
    def get_interest(self,item):
        contratos=self.env['contract.contract'].search([('tipo_articulo2','=',item)])
        interest=0
        for contrato in contratos:
            pagos= self.env['contract.payments'].search([('contract_id','=',contrato.id)])
            for pago in pagos:
                interest+=pago.interest
        return interest

    @api.model
    def get_total_money(self,item):
        return self.get_capital(item) + self.get_interest(item)


    @api.multi
    def contract_payments(self):
        self.ensure_one()
        return {
            'name':("Pagos"),
            'view_mode':'tree,form',
            #'view_id': False,
            'view_type': 'form',
            'res_model': 'contract.payments',
            #'res_id': req_id,
            'type': 'ir.actions.act_window',
            #'nodestroy': True,
            'target': 'main',
            'clear_bredcrumb':True,
            'domain': [('contract_id','=',self.id)],
            'context': {'contract_id': self.id},
            'flags': {'mode': 'edit'}
        }
    
    def finish_contract(self):
        #view_id=self.env['fake.invoice.wizard']
       # new = view_id.create()
        return {
            'type': 'ir.actions.act_window',
            'context': {'saldo_restante': self.borrowed_money,'contract_id': self.id},
            'name': 'Finalizar Contrato',
            'res_model': 'contract.wizard',
            'view_type': 'form',
            'view_mode': 'form',
          #  'res_id'    : self.id,
            'view_id': self.env.ref('contracts_modifier.contract_wizard_form_view').id,
            'target': 'new',
        } 

    def print_pdf(self):
        return {
            'type':'ir.actions.act_window',
            'name':'Fecha de Contrato',
            'res_model':'payment.wizard',
            'view_type':'form',
            'view_mode':'form',
            'view_id':self.env.ref('contracts_modifier.payment_wizard_form_view').id,
            'target':'new'
        }
         

    

        
    