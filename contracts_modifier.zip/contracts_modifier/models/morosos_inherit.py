# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
import logging
_logger = logging.getLogger(__name__)
from datetime import datetime, timedelta, date
#import cPickle as pickle
import _pickle as pickle
import json

class LoanMorososInherit(models.TransientModel):
    _inherit = ['loan.morosos']

    prestatario_id = fields.Many2one('res.partner',required=True,string='Buscar Prestatario',domain="[('is_allow_loan','=',True)]")
    loan_id = fields.Many2one('dev.loan.loan', string='Préstamo',required=True,domain="[('name', '=','prestatario_id')]")
    Carts = fields.Selection([
        ('carta1', 'Carta de cobro 1'),
        ('carta2', 'carta de cobro 2'),
        ('carta3', 'Carta de cobro 3'),
        ('Compromiso', 'Carta de Compromiso'),
    ], string='Cartas')


    @api.multi
    def get_report(self):
        meses ={'0':'cero',
        '1':'un','2':'dos','3':'tres','4':'cuatro','5':'cinco','6':'seis','7':'siete','8':'ocho',
        '9':'nueve','10':'diez','11':'once','12':'doce','13':'trece','14':'catorce','15':'quince','16':'dieciseis'
        ,'17':'diecisiete','18':'dieciocho','19':'diecinueve','20':'veinte','21':'veintiuno','22':'venitidos','23':'veintitres','24':'veinticuatro'}
        f_fecha= self.fecha.strftime("%d %B %Y")
        name = self.prestatario_id.name
        dia_siguiente = self.fecha + timedelta(days=1)

        while date.weekday(dia_siguiente) not in range(0,5):
            dia_siguiente = dia_siguiente + timedelta(days=1)

        dia_siguiente = dia_siguiente.strftime("%A %d de %B %Y")
        # print(self.deuda,'deuda?')
        # deuda=json.loads(self.deuda)

        cuotas_pagas= self.env['dev.loan.installment'].search([('client_id', '=', self.prestatario_id.id),('loan_id', '=', self.loan_id.id),('state', '=', 'paid')])
        monto_total = self.loan_id.remaing_amount
        monto_interes = self.loan_id.total_interest
        if cuotas_pagas:
                for i in cuotas_pagas:
                    monto_total = monto_total - i.total_amount
                    monto_interes = monto_interes - i.interest

        codeudores = self.env['res.partner'].search([('parent_id', '=', self.prestatario_id.id)])
        documento = self.prestatario_id.vat
        cod = name
        cod_solo = 'Codeudores: '
        codydocs = 'y '
        firma = []
        firma.append((self.prestatario_id.name, self.prestatario_id.vat, '____________________________'))
        
        if codeudores:

            for i in codeudores:
                firma.append((i.name, i.vat, '____________________________'))
                codydocs += i.name + u' con cédula número '+i.vat+' de '+i.expedicion_lugar+', '
                cod_solo += i.name +', '
    
  

        data = {
            'model': self._name,
            'ids': self.ids,
            'fecha':f_fecha,
            'mes':meses[str(self.meses_atraso)] if meses[str(self.meses_atraso)] else '',
            'mes_num':self.meses_atraso,
            'name':name,
            'dia_siguiente': dia_siguiente,
            'deuda':round(monto_total,2),
            'deuda_intereses':round(monto_interes,2),
            'codeudores':cod,
            'cod_solo':cod_solo,
            'documento':documento,
            'codydocs':codydocs,
            'firma':firma,
            
            }
                
        if self.Carts == 'carta1':
            _logger.info("¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¿¿¿¿")
            return self.env.ref('contracts_modifier.report_ContractMora').report_action(self, data=data)
        if self.Carts == 'carta2':
            return self.env.ref('contracts_modifier.report_ContractMora2').report_action(self, data=data)
        if self.Carts == 'carta3':
            return self.env.ref('contracts_modifier.report_ContractMora3').report_action(self, data=data)
        if self.Carts == 'Compromiso':
            return self.env.ref('contracts_modifier.report_Compromiso').report_action(self, data=data)
