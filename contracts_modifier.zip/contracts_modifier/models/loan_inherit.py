# -*- coding: utf-8 -*-

from odoo import models, fields, api

class LoanInherit(models.Model):
    _inherit = "dev.loan.loan"

    cobrador_id = fields.Many2one(comodel_name='res.partner', string='Cobrador', domain="[('is_collector', '=', True)]")
    
    