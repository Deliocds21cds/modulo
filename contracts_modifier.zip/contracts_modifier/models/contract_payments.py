# -*- coding: utf-8 -*-

from odoo import models, fields, api

class ContractPayments(models.Model):
    _name = "contract.payments"
    
    
    interest = fields.Float(string='Interés')
    contract_id = fields.Many2one(string='Nro de Contrato',comodel_name='contract.contract',readonly=True,default=lambda self: self._get_default_status())
    capital = fields.Float(string='Capital')
    contract_payments1 = fields.Float(string='Pago')
    date = fields.Date(string='Fecha', required=True)
    payment_type = fields.Selection([
        ('contract_payments1','Cuota'),
        ('interest','Interés'),
        ('capital','Capital'),
        ('cancellation','Cancelación')
    ], string='Tipo de Pago', default='contract_payments1')
    
    @api.model 
    def _get_default_status(self): 
        if self.env.context.get('contract_id'): 
            return self.env.context.get('contract_id')
        
    @api.constrains('contract_id')
    def borrowed_money(self):
        contrato=self.env['contract.contract'].search([('id','=',self.contract_id.id)])
        contrato.sudo().write({
            'borrowed_money':contrato.borrowed_money-self.capital
        })
    
    @api.onchange('contract_payments1')
    def _onchange_contract_payments1(self):
        contrato=self.env['contract.contract'].search([('id','=',self.contract_id.id)])
        interes=contrato.interest1
        self.interest=self.contract_payments1*interes/100
        self.capital=self.contract_payments1-self.interest
