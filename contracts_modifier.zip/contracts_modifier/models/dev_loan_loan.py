# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from datetime import datetime, date
from dateutil.relativedelta import relativedelta
import logging
_logger = logging.getLogger(__name__)
    
class DevLoanLoanInherit(models.Model):
    _inherit = "dev.loan.loan"
    
    @api.multi
    def compute_installment(self,date= False):
        if self.installment_ids:
            for installment in self.installment_ids:
                installment.with_context({'force_delete':True}).unlink()
                
        inc_month = 1

        # NOTAS
        # self.loan_amount     es el capital
        # total_interest     total de intereses
        # paid_amount        total pagado
        # remaing_amount     Cantidad Restante
        # interest_rate      Porcentaje de interes
        
        loan_amount = self.loan_amount
        
        if self.state == 'draft':
            date = self.request_date
        else:
            date = date
        vals = []
        saldo = loan_amount
        
        interest_account_id,installment_account_id,loan_payment_journal_id = self.get_loan_account_journal()
        rango = 0
        
        if self.installment_type == 'day':
            rango = self.loan_term * 30
            installment_amount = self.loan_amount / (self.loan_term*30)

        if self.installment_type == 'sem':
            rango = self.loan_term * 4
            installment_amount = self.loan_amount / (self.loan_term*4)

        if self.installment_type == 'quinc':
            rango = self.loan_term * 2
            installment_amount = self.loan_amount / (self.loan_term*2)

        if self.installment_type == 'month':
            rango = self.loan_term * 1
            installment_amount = self.loan_amount / self.loan_term

        #self.total_interest = self.calculo_interes(self.loan_amount,self.interest_rate,self.loan_term,self.installment_type)



        for i in range(1,rango+1):
            interest = 0
            if self.loan_type_id.is_interest_apply:
                
                if self.loan_pay_type in ('amortization'):
                    if self.interest_mode == 'flat':
                        interest = saldo * (self.interest_rate / 100)
                        
                    else:
                        interest = self.get_monthly_interest(saldo)
                    saldo = saldo - installment_amount
                   
                else:
                    if self.interest_mode == 'flat':
                        interest = self.calculo_interes_cuota(self.loan_amount,self.interest_rate,self.loan_term,self.installment_type)
                        #interest = (( installment_amount * self.interest_rate ) / 100 ) / 12
                    else:
                        interest = self.get_monthly_interest(saldo)

            if self.installment_type == 'day':
                date = date + relativedelta(days = 1)
            if self.installment_type == 'sem':
                date = date + relativedelta(days= 7)
            if self.installment_type == 'quinc':
                date = date + relativedelta(days = 15)
            if self.installment_type == 'month':
                date = date + relativedelta(months=1)
            # if self.installment_type == 'quater':
            #     date = date + relativedelta(months=inc_month)

            
            vals.append((0, 0,{
                'name':'INS - '+self.name+ ' - '+str(i),
                'client_id':self.client_id and self.client_id.id or False,
                'date':date,
                'amount':installment_amount,
                'interest':interest,
                'state':'unpaid',
                'saldo':None,
                'interest_account_id':interest_account_id or False,
                'installment_account_id':installment_account_id or False,
                'loan_payment_journal_id':loan_payment_journal_id or False,
                'currency_id':self.currency_id and self.currency_id.id or False,
                'saldo_capital':installment_amount,
                'saldo_interes':interest
            }))
        
        self.installment_ids = vals
    
    def reliquidar_deuda(self):
        return {
            'type':'ir.actions.act_window',
            'name':'Reliquidar Deuda',
            'res_model':'reliquidate.wizard',
            'view_type':'form',
            'view_mode':'form',
            'view_id':self.env.ref('contracts_modifier.reliquidate_wizard_form_view').id,
            'target':'new',
            'context': {'default_loan_amount': self.loan_amount,'default_loan_id':self.id}  
        }
    
    @api.multi
    def action_disburse_loan(self):
        self.disbursement_date = date.today()
        if self.disbursement_date:
            account_move_val = self.get_account_move_vals()
            account_move_id = self.env['account.move'].create(account_move_val)
            vals=[]
            if account_move_id:
                val = self.get_debit_lines()
                vals.append((0,0,val))
                val = self.get_credit_lines()
                vals.append((0,0,val))
                account_move_id.line_ids = vals
                self.disburse_journal_entry_id = account_move_id and account_move_id.id or False
        if self.disburse_journal_entry_id:
            self.state = 'disburse'
        self.compute_installment(self.disbursement_date)
        return {
            'name': _('Desembolso'),
            'type':'ir.actions.act_window',
            'res_model':'account.payment',
            'view_type':'form',
            'view_mode':'form',
            'view_id':self.env.ref('account.view_account_payment_form').id,
            'target':'current',
            'nodestroy': True,
            'context': {'default_payment_type': 'outbound','default_code':self.client_id.code,'default_partner_id':self.client_id.id,'default_amount': self.loan_amount}  
        }