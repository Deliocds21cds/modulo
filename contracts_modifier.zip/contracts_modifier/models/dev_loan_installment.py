# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
import logging
_logger = logging.getLogger(__name__)
    
class DevLoanInstallmentInherit(models.Model):
    _inherit = "dev.loan.installment"
    
    saldo = fields.Float(string='Saldo')

    @api.multi
    def action_view_pagos(self):

       
        return {
        'name': _('Pagos'),
        'view_type': 'form',
        'view_mode': 'form',
        'res_model': 'account.payment',
        'view_id': False,
        'type': 'ir.actions.act_window',
        'target': 'current',
        'nodestroy': True,
        'context': {'cuota_id':self.id,'default_code':self.client_id.code,'default_loan_id':self.loan_id.id, 'partner_id':self.client_id.id, 'total_amount':self.total_amount,'amount':self.amount,'interest':self.interest}
    }