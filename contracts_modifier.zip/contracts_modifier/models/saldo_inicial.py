# -*- coding: utf-8 -*-

from odoo import models, fields, api

class InitialSaldo(models.Model):
    _name= "initial.saldo"
    _rec_name = "niu"

    saldo = fields.Float(string='Saldo Inicial')
    state = fields.Boolean(string='Estado', default=True, readonly=True)
    niu = fields.Char('NIU', readonly=True, select=True, copy=False, default='New')
    

    @api.model
    def create(self,values):
        res = super(InitialSaldo, self).create(values)
        if res.niu == 'New':
            number = self.env['ir.sequence'].next_by_code('saldo.sequence') or 'New'
            res.write({'niu':number})
        saldos=self.env["initial.saldo"].search([("id","!=",res.id)])
        for saldo in saldos:
            if saldo.state == True:
                saldo.write({
                    "state": False
                })
        return res
            


    
    
