# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
    
class AccountPaymentInherit(models.Model):
    _inherit = "account.payment"

    dscto_interes = fields.Float(string='Dscto Interés')

    @api.onchange('code','partner_id','loan_id','a_pagar')
    def _on_change_code(self):
        
        if self._context.get('total_amount') and self.a_pagar == 'todo':
            self.amount = self._context.get('total_amount')
        if self._context.get('amount') and self.a_pagar == 'capital':
            self.amount = self._context.get('amount')
        if self._context.get('interest') and self.a_pagar == 'intereses':
            self.amount = self._context.get('interest')

        
        if self.code and not self.partner_id:
            partner = self.env['res.partner'].search([('code', '=', self.code)])
            
            if self.code and partner:
                self.partner_id=(partner[0].id)
            #sa=sn=cap=inter=lo=0
        
        if not self.code and self.partner_id:
            if self.partner_id.code:
                self.code = self.partner_id.code

        if self.code and self.partner_id:
            if self.partner_id.code:
                if self.partner_id.code != self.code:
                    self.code = self.partner_id.code
            else:
                self.code = ''
                
        for record in self:
            for l in self.loan_id:
                record.saldo_actual = l.loan_amount
                record.saldo_nuevo = record.saldo_actual
                record.capital = 0
                record.intereses_a_fecha = 0
                record.loan_id = l.id

                for installment in l.installment_ids:
                    if installment.loan_state in ('paid'):
                        record.saldo_actual = record.saldo_actual - installment.amount
                        record.capital = record.capital + installment.amount
                        record.intereses_a_fecha = record.intereses_a_fecha + installment.interest
                        record.saldo_nuevo = record.saldo_actual - installment.amount

    @api.multi
    def post(self):
        res = super(AccountPaymentInherit,self).post()
        cuota_id = self._context.get('cuota_id')
        if cuota_id:
            loan_id = self._context.get('default_loan_id')
            cuota = self.env['dev.loan.installment'].search([('id', '=', cuota_id)])
            paga = self.amount
            loan = self.env['dev.loan.loan'].search([('id', '=', loan_id)])
            if self.a_pagar == 'todo':
                saldo_capital = cuota.saldo_capital
                saldo_interes = cuota.saldo_interes
                le_queda = ( saldo_capital +  saldo_interes) - paga
                if le_queda > 0:
                    cuota.saldo_capital = le_queda

                if le_queda < 0:
                    cuotas_sin_pagar = self.env['dev.loan.installment'].search([('loan_id', '=', cuota.loan_id.id),('state', '=', 'unpaid'),('id', 'not in', [cuota.id])],order='id asc', limit=1)
                    #aqui le resto al capital lo que me sobro de la cuota pasada.
                    print(cuotas_sin_pagar.name,'test')
                    #cuota.saldo_capital = le_queda
                loan.write({
                    'loan_amount':loan.loan_amount - saldo_capital,
                    'total_interest':loan.total_interest - saldo_interes,
                    'paid_amount':loan.paid_amount + paga,
                    'remaing_amount':loan.remaing_amount - paga
                })
                cuota.saldo = loan.remaing_amount
                cuota.state = 'paid'
                #Puede pagar menos, mas o igual
                #Si cubre la cuota entonces cambio el estado a pago

            if self.a_pagar == 'capital':
                saldo_capital = cuota.saldo_capital
                loan.write({
                    'loan_amount':loan.loan_amount - saldo_capital,
                    'paid_amount':loan.paid_amount + paga,
                    'remaing_amount':loan.remaing_amount - paga
                })  
            if self.a_pagar == 'intereses':
                saldo_interes = cuota.saldo_interes
                loan.write({
                    'total_interest':loan.total_interest - saldo_interes,
                    'paid_amount':loan.paid_amount + paga,
                    'remaing_amount':loan.remaing_amount - paga
                })
            
        #cuota.state = "paid"
        return res

    def obtener_datos(self):
        loan_id = self._context.get('default_loan_id')
        loan = self.env['dev.loan.loan'].search([('id', '=', loan_id)])
        self.amount = self.env.context.get('default_amount')
        self.partner_type = 'customer'
