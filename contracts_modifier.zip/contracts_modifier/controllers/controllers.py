# -*- coding: utf-8 -*-
from odoo import http

# class ContractsModifier2(http.Controller):
#     @http.route('/contracts_modifier2/contracts_modifier2/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/contracts_modifier2/contracts_modifier2/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('contracts_modifier2.listing', {
#             'root': '/contracts_modifier2/contracts_modifier2',
#             'objects': http.request.env['contracts_modifier2.contracts_modifier2'].search([]),
#         })

#     @http.route('/contracts_modifier2/contracts_modifier2/objects/<model("contracts_modifier2.contracts_modifier2"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('contracts_modifier2.object', {
#             'object': obj
#         })