# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import datetime, timedelta, date

class ReportWizard(models.TransientModel):
    _name = 'report.wizard'
    From_date = fields.Date(string='De')
    To_date = fields.Date(string='Hasta')
    Report_type = fields.Selection([
        ('Report_daily', 'Daily'),
        ('Report_model','Reporte de Modalidad'),
        ('Report_vencido','Reporte de Pagos Vencidos'),
        ('Report_monetary','Reporte de Monetario'),
        ('report_Credits','Reporte de Creditos Cancelados')
    ], string='Tipo de Reporte')
    

    #REPORTE DAILY!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    @api.multi
    def get_payment_type(self,type):
        if type == "inbound":
            return "Pago de Cuotas o Abonos"
        elif type == "outbound":
            return "desembolso"
        else:
            return "Transferencia Interna"

    @api.multi
    def get_initial_balance(self):
        lineas = []
        pagos_ids=self.env["account.payment"].search([("payment_date","<",date.today())])
        total_ingresos = 0.0
        for pago in pagos_ids:
            total_ingresos += pago.amount
        egresos_ids=self.env["account.payment"].search([("payment_date","<",date.today()),("payment_type","=","outbound")])
        total_egresos = 0.0
        for egreso in egresos_ids:
            total_egresos += egreso.amount
        return  total_ingresos - total_egresos 

    @api.multi
    def get_initial(self):
        lineas = []
        ingreso = self.get_initial_balance()
        obj={
            "codigo":"",
            "detalle":"Ingresamos Saldo Anterior",
            "debe":ingreso,
            "haber":"",
            "saldo":ingreso
        }
        lineas.append(obj)
        return lineas

    
    @api.multi
    def get_office_payments(self):
        lineas = []
        restante = self.get_initial_balance()
        pagos_ids=self.env["account.payment"].search([("payment_date","=",date.today()),("reporta","=","oficina"),("payment_type","!=","outbound")])
        for pago in pagos_ids:
            restante += pago.amount
            obj={
                "codigo":pago.name,
                "detalle":str(pago.partner_id.name) +" "+ self.get_payment_type(str(pago.payment_type)),
                "debe":pago.amount,
                "haber":"",
                "saldo":restante
            }
            lineas.append(obj)
        return lineas

    @api.multi
    def get_office_total(self):
        lineas = []
        pagos_ids=self.env["account.payment"].search([("payment_date","=",date.today()),("reporta","=","oficina"),("payment_type","!=","outbound")])
        total_oficina = 0.0
        for pago in pagos_ids:
            total_oficina += pago.amount
        obj={
            "codigo":"",
            "detalle":"Total de Pagos de Oficina",
            "debe":total_oficina,
            "haber":"",
            "saldo":total_oficina + self.get_initial_balance()
        }
        lineas.append(obj)
        return lineas

    @api.multi
    def get_earnings_oficina(self):
        total_ingresos = 0.0
        total_oficina = 0.0
        oficina_ids=self.env["account.payment"].search([("payment_date","=",date.today()),("reporta","=","oficina"),("payment_type","!=","outbound")])
        for oficina in oficina_ids:
            total_oficina += oficina.amount
        total_ingresos += total_oficina 
        return total_ingresos




    
    @api.multi
    def get_collector_payments(self):
        lineas = []
        restante = self.get_initial_balance() + self.get_earnings_oficina()
        pagos_ids=self.env["account.payment"].search([("payment_date","=",date.today()),("reporta","=","cobrador"),("payment_type","!=","outbound")])
        for pago in pagos_ids:
            restante += pago.amount
            obj={
                "codigo":pago.name,
                "detalle":str(pago.cobrador_id.name),
                "debe":pago.amount,
                "haber":"",
                "saldo":restante
            }
            lineas.append(obj)
        return lineas

    @api.multi
    def get_collector_total(self):
        lineas = []
        pagos_ids=self.env["account.payment"].search([("payment_date","=",date.today()),("reporta","=","cobrador"),("payment_type","!=","outbound")])
        total_collector = 0.0
        for pago in pagos_ids:
            total_collector += pago.amount
        obj={
            "codigo":"",
            "detalle":"Total de Ingresos de Auxiliares",
            "debe":total_collector,
            "haber":"",
            "saldo":total_collector + self.get_initial_balance() + self.get_earnings_oficina()
        }
        lineas.append(obj)
        return lineas

    @api.multi
    def get_earnings_collector(self):
        total_ingresos = 0.0
        total_collector = 0.0
        collector_ids=self.env["account.payment"].search([("payment_date","=",date.today()),("reporta","=","cobrador"),("payment_type","!=","outbound")])
        for collector in collector_ids:
            total_collector += collector.amount
        total_ingresos = self.get_earnings_oficina() + total_collector
        return total_ingresos

    @api.multi
    def get_disbourse(self):
        lineas = []
        restante = self.get_initial_balance() + self.get_earnings_collector()
        egresos_ids=self.env["account.payment"].search([("payment_date","=",date.today()),("payment_type","=","outbound")])
        for egreso in egresos_ids:
            restante -= egreso.amount
            obj={
                "codigo":egreso.name,
                "detalle":str(egreso.partner_id.name),
                "debe":"",
                "haber":egreso.amount,
                "saldo":restante
            }
            lineas.append(obj)
        return lineas

    @api.multi
    def get_total_disbourse(self):
        lineas = []
        egresos_ids=self.env["account.payment"].search([("payment_date","=",date.today()),("payment_type","=","outbound")])
        total_disbourse = 0.0
        for egreso in egresos_ids:
            total_disbourse += egreso.amount
        obj={
            "codigo":"",
            "detalle":"Total de Egresos",
            "debe":"",
            "haber":total_disbourse,
            "saldo":self.get_initial_balance() + self.get_earnings_collector() - total_disbourse  
        }
        lineas.append(obj)
        return lineas



    @api.multi
    def get_lines(self):
        # borrowers_ids = self.env["res.partner"].search([])
        # total_restante = 0.0
        lineas = []
        # for borrower in borrowers_ids:
        #     for loan in borrower.loan_ids:
        #         total_restante+=loan.remaing_amount
        # obj={
        #     "codigo":"",
        #     "detalle":"Registramos saldo anterior",
        #     "debe":total_restante,
        #     "haber":"",
        #     "saldo":total_restante
        # }
        # obj2={
        #     "codigo":"",
        #     "detalle":"Registramos Ingresos en Efectivo",
        #     "debe":"",
        #     "haber":"",
        #     "saldo":""
        # }
        # lineas.append(obj)
        # lineas.append(obj2)
        pagos_ids=self.env["account.payment"].search([("payment_date","=",date.today()),("reporta","=","oficina")])
        total_oficina=0.0
        for pago in pagos_ids:
            #total_restante+=pago.amount
            total_oficina+=pago.amount
            obj3={
                "codigo":pago.name,
                "detalle":str(pago.partner_id.name) +" "+ self.get_payment_type(str(pago.payment_type)),
                "debe":pago.amount,
                "haber":"",
                "saldo":""
            }
            obj4={
            "codigo":"",
            "detalle":"Total Ingreso de Oficina",
            "debe":total_oficina,
            "haber":"",
            "saldo":""
        }
            lineas.append(obj3)
        lineas.append(obj4)
        obj5={
            "codigo":"",
            "detalle":"",
            "debe":"",
            "haber":"",
            "saldo":""  
        }
        lineas.append(obj5) 
        obj6={
            "codigo":"",
            "detalle":"Registramos Ingresos de Auxiliares",
            "debe":"",
            "haber":"",
            "saldo":""
        }
        lineas.append(obj6)

        prestamos_ids=self.env["dev.loan.loan"].search([("request_date","=",date.today()),("reporta","=","cobrador")])
        for prestamo in prestamos_ids:
            obj6={
                "codigo":prestamo.name,
                "detalle":prestamo.cobrador_id.name,
                "debe":"",
                "haber":"",
                "saldo":""
            }

        return lineas

    #REPORTE MODEL!!!!!!!!!!!!!!!!!
    @api.multi
    def get_installment_type(self,type):
        if type == "month":
            return "Meses"
        elif type == "day":
            return "Dia"
        elif type == "sem":
            return "Semanal"
        else:
            return "Quincenal"

    @api.multi
    def get_model_lines(self):
        lineas = []
        models_ids=self.env["dev.loan.loan"].search([])
        for model in models_ids:
            obj={
                "prestatario": model.client_id.name,
                "modalidad": self.get_installment_type(model.installment_type)
            }
            lineas.append(obj)

        return lineas

    #REPORTE VENCIDO!!!!!!!!!!!!!!!!!!!!

    @api.multi
    def get_vencido_lines(self): 
        lineas = []
        loan_ids=self.env["dev.loan.loan"].search([])
        for loan in loan_ids:
            num_vencidas=0
            for installment in loan.installment_ids:
                if installment.vencida == True:
                    num_vencidas += 1
            if num_vencidas != 0:
                lineas.append({
                    "prestatario":loan.client_id.name,
                    "cuotas_vencidas":num_vencidas
                })
        return lineas


    #REPORTE MONETARIO !!!!!!!!!!!!!!!!!!!

    @api.multi
    def get_monetary_lines(self):
        lineas = []
        loan_ids=self.env["dev.loan.loan"].search([])
        suma_capital=0.0
        suma_intereses=0.0
        suma_total=0.0
        for loan in loan_ids:
            suma_capital += loan.loan_amount
            suma_intereses += loan.total_interest
            suma_total += suma_capital + suma_intereses
        obj={
            "capital": suma_capital,
            "intereses": suma_intereses,
            "total": suma_total
        }
        lineas.append(obj)
        return lineas

    #REPORTE CREDITOS !!!!!!!!!!!!!
    @api.multi
    def action_print_pdf(self):
        data={}
        data['form'] = self.read()[0]
        if self.Report_type == "report_Credits":
            return self.env.ref('contracts_modifier.report_Credits').report_action(self, data=None)
        elif self.Report_type == "Report_daily":
            return self.env.ref('contracts_modifier.report_Daily').report_action(self, data=None)
        elif self.Report_type == "Report_model":
            return self.env.ref('contracts_modifier.report_Model').report_action(self, data=None)
        elif self.Report_type == "Report_vencido":
            return self.env.ref('contracts_modifier.report_Vencido').report_action(self, data=None)
        else:
            return self.env.ref('contracts_modifier.report_Monetary').report_action(self, data=None)

    @api.multi
    def get_credit_lines(self):
        lineas = []
        loan_ids=self.env["dev.loan.loan"].search([])
        for loan in loan_ids:
            if loan.remaing_amount == 0.0:
                obj={
                    "Credito_cancelado":loan.name
                }
                lineas.append(obj)
        return lineas








