# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import datetime, timedelta, date

class ReportWizard(models.TransientModel):
    _name = 'report.wizard'
    From_date = fields.Date(string='De')
    To_date = fields.Date(string='Hasta')
    update_balance = fields.Boolean(string='Cerrar y actualizar saldo inicial', default = False)
    Report_type = fields.Selection([
        ('Report_daily', 'Reporte Diario'),
        ('Report_model','Reporte de Modalidad'),
        ('Report_vencido','Reporte de Pagos Vencidos'),
        ('Report_monetary','Reporte de Monetario'),
        ('report_Credits','Reporte de Creditos Cancelados')
    ], string='Tipo de Reporte', required=True)
    

    #REPORTE DAILY!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    @api.multi
    def get_today(self):
        return date.today()
        


    @api.multi
    def get_payment_type(self,type):
        if type == "inbound":
            return "Pago de Cuotas o Abonos"
        elif type == "outbound":
            return "desembolso"
        else:
            return "Transferencia Interna"
    
    @api.multi
    def get_sequence(self):
        number=self.env["ir.sequence"].next_by_code('daily.sequence')
        return number

    @api.multi
    def get_initial_balance(self):
        saldo = self.env["initial.saldo"].search([("state","=",True)])
        return saldo.saldo

    @api.multi
    def get_initial(self):
        lineas = []
        ingreso = self.get_initial_balance()
        obj={
            "codigo":"",
            "detalle":"Ingresamos Saldo Inicial",
            "debe":ingreso,
            "haber":"",
            "saldo":ingreso
        }
        lineas.append(obj)
        return lineas

    
    @api.multi
    def get_office_payments(self):
        lineas = []
        restante = self.get_initial_balance()
        pagos_ids=self.env["account.payment"].search([("payment_date","=",date.today()),("reporta","=","oficina"),("payment_type","!=","outbound")])
        for pago in pagos_ids:
            restante += pago.amount
            obj={
                "codigo":pago.name,
                "detalle":str(pago.a_pagar) +" "+ str(pago.partner_id.name),
                "debe":pago.amount,
                "haber":"",
                "saldo":restante
            }
            lineas.append(obj)
        return lineas

    @api.multi
    def get_office_total(self):
        lineas = []
        pagos_ids=self.env["account.payment"].search([("payment_date","=",date.today()),("reporta","=","oficina"),("payment_type","!=","outbound")])
        total_oficina = 0.0
        for pago in pagos_ids:
            total_oficina += pago.amount
        obj={
            "codigo":"",
            "detalle":"Total de Pagos de Oficina",
            "debe":total_oficina,
            "haber":"",
            "saldo":total_oficina + self.get_initial_balance()
        }

        lineas.append(obj)
        return lineas

    @api.multi
    def get_earnings_oficina(self):
        total_ingresos = 0.0
        total_oficina = 0.0
        oficina_ids=self.env["account.payment"].search([("payment_date","=",date.today()),("reporta","=","oficina"),("payment_type","!=","outbound")])
        for oficina in oficina_ids:
            total_oficina += oficina.amount
        total_ingresos += total_oficina 
        return total_ingresos




    
    @api.multi
    def get_collector_payments(self):
        lineas = []
        restante = self.get_initial_balance() + self.get_earnings_oficina()
        pagos_ids=self.env["account.payment"].search([("payment_date","=",date.today()),("reporta","=","cobrador"),("payment_type","!=","outbound")])
        for pago in pagos_ids:
            restante += pago.amount
            obj={
                "codigo":pago.name,
                "detalle":str(pago.cobrador_id.name),
                "debe":pago.amount,
                "haber":"",
                "saldo":restante
            }
            lineas.append(obj)
        return lineas

    @api.multi
    def get_collector_total(self):
        lineas = []
        pagos_ids=self.env["account.payment"].search([("payment_date","=",date.today()),("reporta","=","cobrador"),("payment_type","!=","outbound")])
        total_collector = 0.0
        for pago in pagos_ids:
            total_collector += pago.amount
        obj={
            "codigo":"",
            "detalle":"Total de Ingresos de Auxiliares",
            "debe":total_collector,
            "haber":"",
            "saldo":total_collector + self.get_initial_balance() + self.get_earnings_oficina()
        }
        lineas.append(obj)
        return lineas

    @api.multi
    def get_earnings_collector(self):
        total_ingresos = 0.0
        total_collector = 0.0
        collector_ids=self.env["account.payment"].search([("payment_date","=",date.today()),("reporta","=","cobrador"),("payment_type","!=","outbound")])
        for collector in collector_ids:
            total_collector += collector.amount
        total_ingresos = self.get_earnings_oficina() + total_collector
        return total_ingresos

    @api.multi
    def get_disbourse(self):
        lineas = []
        restante = self.get_initial_balance() + self.get_earnings_collector()
        egresos_ids=self.env["account.payment"].search([("payment_date","=",date.today()),("payment_type","=","outbound")])
        for egreso in egresos_ids:
            restante -= egreso.amount
            obj={
                "codigo":egreso.name,
                "detalle":str(egreso.partner_id.name),
                "debe":"",
                "haber":egreso.amount,
                "saldo":restante
            }
            lineas.append(obj)
        return lineas

    @api.multi
    def get_total_disbourse(self):
        lineas = []
        egresos_ids=self.env["account.payment"].search([("payment_date","=",date.today()),("payment_type","=","outbound")])
        total_disbourse = 0.0
        for egreso in egresos_ids:
            total_disbourse += egreso.amount
        obj={
            "codigo":"",
            "detalle":"Total de Creditos Realizados",
            "debe":"",
            "haber":total_disbourse,
            "saldo":self.get_initial_balance() + self.get_earnings_collector() - total_disbourse  
        }
        if self.update_balance:
            self.env["initial.saldo"].search([("state","=",True)]).sudo().write({
                "saldo": self.get_initial_balance() + self.get_earnings_collector() - total_disbourse 
            })
        lineas.append(obj)
        return lineas


    #REPORTE MODEL!!!!!!!!!!!!!!!!!
    @api.multi
    def get_installment_type(self,type):
        if type == "month":
            return "Meses"
        elif type == "day":
            return "Dia"
        elif type == "sem":
            return "Semanal"
        else:
            return "Quincenal"

    @api.multi
    def get_model_lines(self):
        lineas = []
        models_ids=self.env["dev.loan.loan"].search([("request_date",">=",self.From_date),("request_date","<=",self.To_date)])
        for model in models_ids:
            obj={
                "prestatario": model.client_id.name,
                "modalidad": self.get_installment_type(model.installment_type)
            }
            lineas.append(obj)

        return lineas

    #REPORTE VENCIDO!!!!!!!!!!!!!!!!!!!!

    @api.multi
    def get_vencido_lines(self): 
        lineas = []
        loan_ids=self.env["dev.loan.loan"].search([("request_date",">=",self.From_date),("request_date","<=",self.To_date)])
        for loan in loan_ids:
            num_vencidas=0
            for installment in loan.installment_ids:
                if installment.vencida == True:
                    num_vencidas += 1
            if num_vencidas != 0:
                lineas.append({
                    "prestatario":loan.client_id.name,
                    "cuotas_vencidas":num_vencidas
                })
        return lineas


    #REPORTE MONETARIO !!!!!!!!!!!!!!!!!!!

    @api.multi
    def get_monetary_lines(self):
        lineas = []
        loan_ids=self.env["dev.loan.loan"].search([("request_date",">=",self.From_date),("request_date","<=",self.To_date)])
        suma_capital=0.0
        suma_intereses=0.0
        suma_total=0.0
        for loan in loan_ids:
            suma_capital += loan.loan_amount
            suma_intereses += loan.total_interest
            suma_total += suma_capital + suma_intereses
        obj={
            "capital": suma_capital,
            "intereses": suma_intereses,
            "total": suma_total
        }
        lineas.append(obj)
        return lineas

    #REPORTE CREDITOS !!!!!!!!!!!!!
    @api.multi
    def action_print_pdf(self):
        data={}
        data['form'] = self.read()[0]
        if self.Report_type == "report_Credits":
            return self.env.ref('contracts_modifier.report_Credits').report_action(self, data=None)
        elif self.Report_type == "Report_monetary":
            return self.env.ref('contracts_modifier.report_Monetary').report_action(self, data=None)
        elif self.Report_type == "Report_model":
            return self.env.ref('contracts_modifier.report_Model').report_action(self, data=None)
        elif self.Report_type == "Report_vencido":
            return self.env.ref('contracts_modifier.report_Vencido').report_action(self, data=None)
        else:
            return self.env.ref('contracts_modifier.report_Daily').report_action(self, data=None)
            
    @api.multi
    def get_credit_lines(self):
        lineas = []
        loan_ids=self.env["dev.loan.loan"].search([("request_date",">=",self.From_date),("request_date","<=",self.To_date)])
        for loan in loan_ids:
            if loan.remaing_amount == 0.0:
                obj={
                    "Credito_cancelado":loan.name
                }
                lineas.append(obj)
        return lineas








