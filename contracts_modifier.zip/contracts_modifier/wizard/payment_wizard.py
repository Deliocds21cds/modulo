# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import datetime, timedelta

class PaymentWizard(models.TransientModel):
    _name = 'payment.wizard'
    day_date = fields.Date(string='DE')
    after_date= fields.Date(string='HASTA')


    def print_button(self):
        return self.env.ref('contracts_modifier.report_RaisedMoney').report_action(self)

    @api.model
    def get_capital(self,item):
        contratos=self.env['contract.contract'].search([('tipo_articulo2','=',item)])
        capital=0
        for contrato in contratos:
            pagos= self.env['contract.payments'].search([('contract_id','=',contrato.id)])
            for pago in pagos:
                if pago.date:
                    if pago.date > self.day_date and pago.date < self.after_date:
                        capital+=pago.capital
        return capital

    @api.model
    def get_interest(self,item):
        contratos=self.env['contract.contract'].search([('tipo_articulo2','=',item)])
        interest=0
        for contrato in contratos:
            pagos= self.env['contract.payments'].search([('contract_id','=',contrato.id)])
            for pago in pagos:
                if pago.date:
                    if pago.date > self.day_date and pago.date < self.after_date:
                        interest+=pago.interest
        return interest

    @api.model
    def get_total_money(self,item):
        return self.get_capital(item) + self.get_interest(item)
    

    


