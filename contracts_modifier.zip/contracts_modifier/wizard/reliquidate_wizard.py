# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import datetime, date
from dateutil.relativedelta import relativedelta
import logging
_logger = logging.getLogger(__name__)

class ReliquidateWizard(models.TransientModel):
    _name = 'reliquidate.wizard'

    loan_pay_type = fields.Selection([('direct_line','Crédito Directo'),('amortization','Amortización')], string='Tipo de Pago', default='direct_line')
    installment_type = fields.Selection([('month','Mensual'),('day','Diario'), ('sem','Semanal'), ('quinc','Quincenal')], string='Modalidad', default='month')
    interest = fields.Float(string='Interés')
    loan_term = fields.Integer('Plazo en Meses')
    loan_amount = fields.Float('Capital',readonly=True)

    def confirm_reliquidate(self):
        loan_id = self._context.get('default_loan_id')
        loan = self.env['dev.loan.loan'].search([('id', '=', loan_id)])

        if loan.installment_ids:
            loan_pagados = 0
            for installment in loan.installment_ids:
                    installment.with_context({'force_delete':True}).unlink()
        
        loan_amount = self.loan_amount
        
        date = loan.request_date
        vals = []
        saldo = loan_amount
        
        interest_account_id,installment_account_id,loan_payment_journal_id = loan.get_loan_account_journal()
        rango = 0
        
        if self.installment_type == 'day':
            rango = self.loan_term * 30
            installment_amount = self.loan_amount / (self.loan_term*30)

        if self.installment_type == 'sem':
            rango = self.loan_term * 4
            installment_amount = self.loan_amount / (self.loan_term*4)

        if self.installment_type == 'quinc':
            rango = self.loan_term * 2
            installment_amount = self.loan_amount / (self.loan_term*2)

        if self.installment_type == 'month':
            rango = self.loan_term * 1
            installment_amount = self.loan_amount / self.loan_term

        #self.total_interest = self.calculo_interes(self.loan_amount,self.interest_rate,self.loan_term,self.installment_type)



        for i in range(1,rango+1):
            interest = 0
            if loan.loan_type_id.is_interest_apply:
                
                if loan.loan_pay_type in ('amortization'):
                    if loan.interest_mode == 'flat':
                        interest = saldo * (loan.interest_rate / 100)
                        
                    else:
                        interest = loan.get_monthly_interest(saldo)
                    saldo = saldo - installment_amount
                   
                else:
                    if loan.interest_mode == 'flat':
                        interest = loan.calculo_interes_cuota(self.loan_amount,loan.interest_rate,self.loan_term,self.installment_type)
                        #interest = (( installment_amount * self.interest_rate ) / 100 ) / 12
                    else:
                        interest = loan.get_monthly_interest(saldo)

            if self.installment_type == 'day':
                date = date + relativedelta(days = 1)
            if self.installment_type == 'sem':
                date = date + relativedelta(days= 7)
            if self.installment_type == 'quinc':
                date = date + relativedelta(days = 15)
            if self.installment_type == 'month':
                date = date + relativedelta(months=1)
            # if self.installment_type == 'quater':
            #     date = date + relativedelta(months=inc_month)

            
            vals.append((0, 0,{
                'name':'INS - '+loan.name+ ' - '+str(i),
                'client_id':loan.client_id and loan.client_id.id or False,
                'date':date,
                'amount':installment_amount,
                'interest':interest,
                'state':'unpaid',
                'saldo':0.00,
                'interest_account_id':interest_account_id or False,
                'installment_account_id':installment_account_id or False,
                'loan_payment_journal_id':loan_payment_journal_id or False,
                'currency_id':loan.currency_id and loan.currency_id.id or False,
                'saldo_capital':installment_amount,
                'saldo_interes':interest
            }))
        
        loan.installment_ids = vals
