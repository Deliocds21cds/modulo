# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import date

class ContractWizard(models.TransientModel):
    _name = 'contract.wizard'
    
    contract_id = fields.Many2one(string='Nro de Contrato',comodel_name='contract.contract',readonly=True,default=lambda self: self._get_default_status())
    saldo = fields.Float(string='Saldo', readonly=True, default=lambda self: self._get_default_saldo())
    interest_amount = fields.Float(string='Interés')
    total = fields.Float(string='Total a Pagar', readonly=True)
    
    
    @api.model 
    def _get_default_status(self): 
        if self.env.context.get('contract_id'): 
            return self.env.context.get('contract_id')
        
    @api.model 
    def _get_default_saldo(self): 
        if self.env.context.get('saldo_restante'): 
            return self.env.context.get('saldo_restante')
        
    @api.onchange('interest_amount')
    def total_change(self):
        self.total=self.saldo*(1+(self.interest_amount/100))
        
    def confirm_button(self):
        pago=self.env['contract.payments']
        pago.sudo().create({
            'contract_payments1':self.total,
            'date':date.today(),
            'capital':self.saldo,
            'interest':self.interest_amount,
            'payment_type':'cancellation'
        })
        contrato=self.env['contract.contract'].search([('id','=',self.contract_id.id)])
        contrato.sudo().write({
            'state':'finished',
            'estado_articulo':'retired'
        })