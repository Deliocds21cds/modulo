# -*- coding: utf-8 -*-
{
    'name': "Modificador de Compraventa",

    'description': """
        Este módulo nos permite modificar el módulo de compraventa
    """,

    'author': "Digilab Perú",
    'website': "https://www.digilab.pe",
    'contributors': [
        'Omar Barron<omar.barron@digilab.pe>',
        'Luis Alva<luis.alva@digilab.pe>',
        'Jorge Escobar<jorge.escobar@digilab.pe>'
    ],

    'category': 'Uncategorized',
    'version': '1.0',

    # any module necessary for this one to work correctly
    'depends': ['base','dev_loan_management','crm','account','contract'],

    # always loaded
    'data': [
        #'data/sequence.xml',
        "report/raised_money.xml",
        'report/inventary.xml',
        'security/ir.model.access.xml',
        'report/contract_shop.xml',
        'views/contract_mod.xml',
        'views/contract_tree_inherit.xml',
        'views/contract_tree_payments.xml',
        'wizard/payment_wizard.xml',
        'wizard/contract_wizard_form.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        
    ],
}