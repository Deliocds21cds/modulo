odoo.define('pos_order_line.screens', function (require) {
    "use strict";

    var models = require('point_of_sale.models');
    var screens = require('point_of_sale.screens');
    var core = require('web.core');
    var _t = core._t;

    screens.OrderWidget.include({
        set_value: function (val) {
            var self = this;
            var mode = this.numpad_state.get('mode');
            if (mode === 'discount') {
                var order = this.pos.get_order();
                if (order.get_discount_total() > 0) {
                    this.gui.show_popup('confirm', {
                        'title': _t('Can\'t apply bill discount and product discount at same time ?'),
                        'body': _t('Remove total discount'),
                        confirm: function () {
                            _.each(order.orderlines.models, function (model, index) {
                                model.set_discount(0);
                            });
                            order.set_discount_total(0);
                            self.renderElement();
                            self.numpad_state.resetValue();
                        },
                    });
                } else {
                    this._super(val);
                }
            } else {
                this._super(val);
            }
        },

        renderElement: function (scrollbottom) {
            this._super(scrollbottom);
            var order = this.pos.get_order();
            if (order.get_discount_total()) {
                this.el.querySelector('.order').classList.add("discount-total");
            }
        }
    });

});

