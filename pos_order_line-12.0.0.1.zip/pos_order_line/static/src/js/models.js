odoo.define('pos_order_line.order_line', function (require) {
    "use strict";

    var models = require('point_of_sale.models');
    var _super_order = models.Order.prototype;
    var _super_orderline = models.Orderline.prototype;

    models.Product = models.Product.extend({
        isAddon: function () {
            if (this.pos_categ_id && this.pos_categ_id[1].endsWith("Addon")) {
                return true;
            }
            return false;
        }
    });

    models.Order = models.Order.extend({
        initialize: function (attributes, options) {
            _super_order.initialize.call(this, attributes, options);
            this.printNumber = 0;
            this.discount_total = 0;
        },

        set_discount_total: function(value) {
            this.discount_total = value;
        },

        get_discount_total: function(){
            return this.discount_total;
        },

        isDiscountOrderline: function () {
            var orderlines = this.orderlines.models;
            if (this.discount_total > 0) {
                return false;
            } else {
                for (var i = 0; i < orderlines.length; ++i) {
                    if (orderlines[i].discount !== 0) {
                        return true;
                    }
                }
                return false;
            }
        },

        getProductNumber: function () {

            var orderlines = this.orderlines.models;
            var totalProd = 0;
            for (var i = 0; i < orderlines.length; i++){
                if (!orderlines[i].get_product().isAddon()) {
                    totalProd = totalProd + orderlines[i].get_quantity();
                }
            }
            return totalProd;
        },

        getProdAddon: function (index) {

            var orderlines = this.orderlines.models;
            var addonList = [];
            for (var i = index+1; i < orderlines.length; i++){
                if (orderlines[i].get_product().isAddon()) {
                    addonList.push(orderlines[i])
                }
                else {
                    break;
                }
            }
            return addonList;
        },

        resetPrintNumber : function () {
            this.printNumber = 0;
        },

        getPrintNumber : function () {
            this.printNumber += 1;
            return this.printNumber;
            
        },

        appendOrderLineAfter(selected_orderline, orderline) {
            var newOrderline = this.orderlines.clone();
            var selected_index = 0;
            for (var i = 0; i < this.orderlines.length; i++) {
                newOrderline.push(newOrderline.at(i));
                if (selected_orderline === this.orderlines.at(i)) {
                    selected_index = i;
                }
            }
            this.orderlines.reset();


            for (i = 0; i < newOrderline.length; i++) {
                this.orderlines.push(newOrderline.at(i));
                if (selected_index === i) {
                    this.orderlines.push(orderline);
                }

            }

            this.select_orderline(this.orderlines.at(selected_index))
        },

        // getTotalDiscounted: function () {
        //     return this.discount_total;
        // },

        remove_orderline: function (line) {
            this.assert_editable();
            if (!line.get_product().isAddon()) {
                for (var i = 0; i < this.orderlines.length; i++) {
                    if (this.orderlines.at(i) === line) {
                        for (var j = i + 1; j < this.orderlines.length; i++) {
                            if (this.orderlines.at(j).get_product().isAddon()) {
                                this.orderlines.remove(this.orderlines.at(j));
                            } else {
                                break;
                            }
                        }
                        break;
                    }
                }
            }

            _super_order.remove_orderline.call(this, line);
        },

        add_product: function (product, options) {
            if (this._printed) {
                this.destroy();
                return this.pos.get_order().add_product(product, options);
            }
            this.assert_editable();
            options = options || {};
            var attr = JSON.parse(JSON.stringify(product));
            attr.pos = this.pos;
            attr.order = this;
            var line = new models.Orderline({}, {pos: this.pos, order: this, product: product});

            if (options.quantity !== undefined) {
                line.set_quantity(options.quantity);
            }

            if (options.price !== undefined) {
                line.set_unit_price(options.price);
            }

            //To substract from the unit price the included taxes mapped by the fiscal position
            this.fix_tax_included_price(line);

            if (options.discount !== undefined) {
                line.set_discount(options.discount);
            }

            if (options.extras !== undefined) {
                for (var prop in options.extras) {
                    line[prop] = options.extras[prop];
                }
            }

            var to_merge_orderline;
            if (!line.product.isAddon()) {
                for (var i = 0; i < this.orderlines.length; i++) {
                    var temp_orderline = this.orderlines.at(i + 1);
                    if (temp_orderline && temp_orderline.get_product().isAddon()) {
                        continue;
                    }
                    if (this.orderlines.at(i).can_be_merged_with(line) && options.merge !== false) {
                        to_merge_orderline = this.orderlines.at(i);
                    }
                }
            } else {
                // if (this.orderlines.length === 0) {
                //     return 0;
                // }

                if (this.selected_orderline) {
                    this.appendOrderLineAfter(this.selected_orderline, line);
                    return 0;
                }

            }

            if (to_merge_orderline) {
                to_merge_orderline.merge(line);
            } else {
                this.orderlines.add(line);
            }
            this.select_orderline(this.get_last_orderline());

            if (line.has_product_lot) {
                this.display_lot_popup();
            }
        },

    });

});

