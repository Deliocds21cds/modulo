To use this module, you need to go to Purchase Orders and select the new filters in the search.
