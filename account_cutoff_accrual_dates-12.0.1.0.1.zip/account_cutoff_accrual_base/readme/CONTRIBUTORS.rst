* Alexis de Lattre <alexis.delattre@akretion.com>
* Alexandre Fayolle <alexandre.fayolle@camptocamp.com>
* Adrien Peiffer (ACSONE) <adrien.peiffer@acsone.eu>
* Cédric Pigeon (ACSONE) <cedric.pigeon@acsone.eu>
