This module contains objets, fields and menu entries that are used by other
accrual modules. So you need to install other accrual modules to get the
additionnal functionalities:

* the module *account_cutoff_accrual_picking* manages accrued expenses and
  revenues based on pickings.
* the module *account_cutoff_accrual_dates* manages accrued expenses and revenues
  based on the start and end dates of invoice lines.
* a not-developped-yet module would manage accrued expenses and revenues based
  on timesheets.
