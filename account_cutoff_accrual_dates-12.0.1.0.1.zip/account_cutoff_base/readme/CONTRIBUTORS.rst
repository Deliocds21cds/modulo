* Alexis de Lattre <alexis.delattre@akretion.com>
* Alexandre Fayolle <alexandre.fayolle@camptocamp.com>
* Stéphane Bidoul (ACSONE)
* Adrien Peiffer (ACSONE)
* Pedro M. Baeza <pedro.baeza@gmail.com>
* Jeroen Evens <jeroen.evenss@dynapps.be>
