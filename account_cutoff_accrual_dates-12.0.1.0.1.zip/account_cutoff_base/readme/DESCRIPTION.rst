This module contains models, fields and menu entries that are used by
other cut-off modules ; it doesn't provide useful features by itself. You
need to install other cut-off modules to get the useful features:

* the module *account_cutoff_prepaid* will manage prepaid cut-offs based on
  start date and end date,

* the module *account_cutoff_accrual_picking* will manage the accruals based
  on the status of the pickings.
