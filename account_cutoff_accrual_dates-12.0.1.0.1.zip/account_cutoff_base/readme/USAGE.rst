This module is used as a base for other account_cutoff modules.
