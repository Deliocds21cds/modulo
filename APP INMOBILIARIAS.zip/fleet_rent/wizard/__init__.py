# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from . import renew_tenancy
from . import rent_close_reason
from . import fleet_rental_vehicle_history
