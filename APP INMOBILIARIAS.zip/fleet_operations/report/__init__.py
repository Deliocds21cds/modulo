# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from . import witten_off_parser
from . import contact_team_trip_ticket
from . import workorder_monthly_summary_report
from . import parts_received
from . import general_parts_listing
from . import need_to_order_parts
from . import daily_Parts_issuance_wizard_report
from . import fleet_history
from . import fleet_listing
from . import fleet_pending_repairs
from . import fleet_pending
from . import fleet_waiting_collection
from . import next_services_by_odometer
from . import next_services_date
from . import stock_adjustment_report
from . import wo_over_10_days
from . import vehicle_change_history
from . import fleet_outstanding_wo
from . import fleet_workorder
from . import most_used_parts
from . import repair_line_summary
from . import fleet_history_work_order
from . import work_order_reports
