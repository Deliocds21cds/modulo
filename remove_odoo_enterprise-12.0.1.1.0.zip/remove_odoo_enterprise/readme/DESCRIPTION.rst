This module removes enterprise-only apps and features from all settings views.
