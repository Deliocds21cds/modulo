To use this module, you need to go to:

* Invoicing > Accounting > Payments and due list
