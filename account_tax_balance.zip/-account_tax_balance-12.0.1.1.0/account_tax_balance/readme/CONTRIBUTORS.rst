* Lorenzo Battistini <lorenzo.battistini@agilebg.com>
* Giovanni Capalbo <giovanni@therp.nl>
* Tecnativa - Antonio Espinosa
* Tecnativa - Pedro M. Baeza
* ACSONE SA/NV - Stéphane Bidoul
* Andrea Stirpe <a.stirpe@onestein.nl>
