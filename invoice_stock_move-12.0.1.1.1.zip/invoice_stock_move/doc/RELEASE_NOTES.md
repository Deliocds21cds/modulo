## Module <invoice_stock_move>

#### 19.02.2019
#### Version 12.0.1.0.0
#### Module Migrated

#### 20.01.2020
#### Version 12.0.1.1.1
#### FIX
- Bug Fixed.
