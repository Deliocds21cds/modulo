odoo.define('web_xls.XlsController', function (require) {
	"use strict";


	var BasicController = require('web.BasicController');
	

	var XlsController = BasicController.extend({
		
		renderPager: function ($node, options) {
		       
	    },

	});
	return XlsController;
});


	