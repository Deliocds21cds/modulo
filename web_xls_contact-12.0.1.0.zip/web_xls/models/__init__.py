# -*- coding: utf-8 -*-

from . import ir_action
from . import ir_ui_view
