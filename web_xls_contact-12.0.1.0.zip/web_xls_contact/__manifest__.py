# -*- coding: utf-8 -*-

{
    'name': 'Web XLS contacts',
    'category': 'Tools',
    'version': '1.0',
    "author" : 'Helmi Dhaoui',
    'website' : 'http://tunisofts.com',
    'description':
        """
Odoo Web XLS view contacts.
========================

This module provides a Web XLS view for contacts.
        """,
    'depends': ['contacts','web_xls'],
    'data': [
        'views/contract_view.xml',
    ],
    'qweb': [
    ],
    'images': ['static/description/icon.png'],
    'bootstrap': True,  
    'licence':'OEEL-1',
    'installable': True,
}
