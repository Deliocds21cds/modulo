Stock Move With Invoice v12
===========================
This module is developed  to  manage the stock picking from invoice .It helps to transfer/receive products from
customer/supplier invoice.

Installation
============
Just select it from available modules to install it, there is no need to extra installations.

Configuration
=============

Nothing to configure.

Credits
=======
Developer: Saritha Sahadevan @ cybrosys, odoo@cybrosys.com
