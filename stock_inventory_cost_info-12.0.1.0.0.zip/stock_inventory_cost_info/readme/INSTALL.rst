A pre_init_hook process is initiated in order to set the *Adjustment cost* to
zero in all existing *inventory adjustment* before installation.
