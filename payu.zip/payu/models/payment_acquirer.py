# -*- coding: utf-8 -*-
from odoo import api, fields, models, _

class payment_acquirer_payu(models.Model):
    _inherit = 'payment.acquirer'    

    provider = fields.Selection(selection_add=[('payu', 'Payu')])
    payu_merchant_id = fields.Char(string='ID Mercantil', required_if_provider='payu')
    payu_account_id = fields.Char(string='ID Cuenta', required_if_provider='payu')
    payu_api_key = fields.Char(string='Clave API', required_if_provider='payu')    
    payu_login = fields.Char(string='Login API', required_if_provider='payu')