# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import Warning
from odoo.addons.payu.models.payu import PayU
import os, hashlib, decimal, datetime, re, json, sys
from odoo.http import request

class payment_transaction(models.Model):
    _inherit = 'payment.transaction'

    payu_response = fields.Html( string="PayuLatam")
    payu_trans_id = fields.Char( string="Trans ID")
    payu_trans_order_ref = fields.Integer( string="Order Ref")

    def payu_confirm(self):
        try:
            payment_acquirer = self.env['payment.acquirer'].search([('provider','=','payu')], limit=1)
            payment_acquirer = self.env['payment.acquirer'].browse(payment_acquirer.id)

            _test = False
            if(str(payment_acquirer.environment)=="test"):
                _test = True

            payment_transactions = self.env['payment.transaction'].search([('payu_response','!=','')])

            client = PayU(payment_acquirer.payu_login, payment_acquirer.payu_api_key, payment_acquirer.payu_merchant_id)
            #client = Client(payment_acquirer.payu_login, payment_acquirer.payu_api_key, payment_acquirer.payu_merchant_id, payment_acquirer.payu_account_id, test=_test, language='en', debug=True)
        
            payment_transactions = self.env['payment.transaction'].search([('payu_response','!=','')])
            for payment_transaction in payment_transactions:
                
                #payu_transaction = client.queries.get_transaction_response(payment_transaction.payu_trans_id)

                transaction = client.order_detail(int(payment_transaction.payu_trans_order_ref))
                if(str(transaction['code']) == "SUCCESS"):
                    payu_transactions = transaction['result']['payload']['transactions']
                    for payu_transaction in payu_transactions:
                        odoo_transaction = self.env['payment.transaction'].browse(payment_transaction.id)
                        if(payment_transaction.payu_trans_id == payu_transaction['id']):
                            payu_trans_state = payu_transaction['transactionResponse']['state']
                            
                            if(payu_trans_state == "APPROVED"):
                                
                                order_ref = str(odoo_transaction.reference).split("/")[0]
                                sale_order = self.env['sale.order'].search([('name','!=',order_ref)],limit=1)
                                o_order = self.env['sale.order'].browse(sale_order.id)

                                if(len(str(o_order.confirmation_date))>0 or len(str(o_order.confirmation_date))==False): 
                                #    pass
                                #else:                            
                                    if(str(o_order.payu_response).find('Aprovada')>0):
                                        pass
                                    else:
                                        html_trans_info = str('<div class="payu-response-row"><label>Estado: </label><span>Transacción Aprovada!</span></div>')
                                        payu_response = str(html_trans_info) + str(o_order.payu_response)
                                        o_order.sudo().update({'state':'sale','confirmation_date':str(datetime.datetime.now()),'payu_response':payu_response})
                                        o_order.sudo().write({'payu_response':payu_response})

                                    if(str(odoo_transaction.payu_response).find('Aprovada')>0):
                                        pass
                                    else:
                                        html_trans_info = str('<div class="payu-response-row"><label>Estado: </label><span>Transacción Aprovada!</span></div>')
                                        payu_response = str(html_trans_info) + str(odoo_transaction.payu_response)
                                        
                                        odoo_transaction.sudo().update({'payu_response':payu_response})
                                        odoo_transaction.sudo().write({'state':'sale'})                                                                 
        except Exception as e:
           exc_traceback = sys.exc_info() 
           raise Warning(getattr(e, 'message', repr(e))+" ON LINE "+format(sys.exc_info()[-1].tb_lineno))
           # with open('/odoo_12/custom/addons/payu/log.json', 'w') as outfile:
           #     json.dump(getattr(e, 'message', repr(e))+" ON LINE "+format(sys.exc_info()[-1].tb_lineno), outfile)





            