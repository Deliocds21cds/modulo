# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
from werkzeug import urls
import os, hashlib, decimal, datetime, re, json
import werkzeug

# 5406 2545 8871 3208
class payu_controller(http.Controller):
    formsPath = str(os.path.dirname(os.path.abspath(__file__))).replace("controllers","")

    @http.route('/payu/get_payu_acquirer/', methods=['POST'], type='json', auth="public", website=True)
    def get_payu_acquirer(self, **kw):       
        response = {"acquirer":None,"form_bill":None}                
        query = "select name, website_id,company_id, environment, website_published, payu_merchant_id, payu_account_id, payu_api_key from payment_acquirer where provider = 'payu' limit 1"
        request.cr.execute(query)    
        acquirer = request.cr.dictfetchone()
        form_bill = self.file_get_contents(str(self.formsPath)+str("/static/src/form/bill.html"))        
        response = {"acquirer":acquirer,"form_bill":form_bill}
        return response
    
    def generate_signature(self, values):
        data = '~'.join([
            values['payu_api_key'],
            values['payu_merchant_id'],
            values['order_name'],
            values['amount'],
            values['currency']])
        m = hashlib.md5()
        m.update(data.encode("utf8"))
        return m.hexdigest()
    
    @http.route('/payu/get_sale_order/', methods=['POST'], type='json', auth="public", website=True)
    def get_sale_order(self, **kw): 
        params = {}
        params['acquirer_id'] = kw.get('acquirer_id')            
        params['partner_id'] = kw.get('partner_id')
                       
        query = "select name, website_id,company_id, environment, website_published, payu_merchant_id, payu_account_id, payu_api_key from payment_acquirer where provider = 'payu' limit 1"
        request.cr.execute(query)    
        acquirer = request.cr.dictfetchone()   
         
        if(acquirer['environment']=="test"):
            environment = str('1')
        else:
            environment = str('0')

        query = "select id, name, amount_total, amount_tax, date_order, partner_shipping_id from sale_order where partner_id = '"+str(params['partner_id'])+"' and state = '"+str('draft')+"' order by date_order desc limit 1"
        request.cr.execute(query)    
        draft_order = request.cr.dictfetchone()

        query = "select name from sale_order_line where order_id = "+str(draft_order["id"])
        request.cr.execute(query)    
        draft_order_lines = request.cr.dictfetchall()
        index = 1
        order_description = str("")
        for order_line in draft_order_lines:
            order_description = str(order_description) + str("          ") + str(index) + str(". ") + str(order_line['name'])
            index = index + 1
       
        query = "select res_partner.id, res_partner.name, res_partner.vat, res_partner.phone, res_partner.email, res_partner.street, res_partner.city, res_partner.zip, res_partner.lang, res_country.name as country_name, res_country.code as country_code, res_country_state.name as state_name, res_currency.name as currency_name, res_currency.symbol as currency_symbol from res_partner left join res_country on res_country.id = res_partner.country_id left join res_country_state on res_country_state.id = res_partner.state_id left join res_currency on res_country.currency_id = res_currency.id   where res_partner.id = '"+str(draft_order['partner_shipping_id'])+"' limit 1"
        request.cr.execute(query)    
        res_partner_shipping = request.cr.dictfetchone()
  
        if(draft_order):
            cents = decimal.Decimal('.01')
            parts_amount = str(draft_order['amount_total']).split(".")
            if(int(parts_amount[1])==0):
                parts_amount[1] = str("00")
            if(len(parts_amount[1])<2):
                parts_amount[1] = parts_amount[1]+'0'
                
            amount = str(int(decimal.Decimal(draft_order['amount_total']).quantize(cents, decimal.ROUND_HALF_UP)))            
            amount = parts_amount[0]+str(parts_amount[1])
            if(int(parts_amount[0])==0):
                amount = str(parts_amount[1])
            
            order_name = str(datetime.datetime.now())
            order_name = re.sub('[^0-9]','', order_name)
            order_name = order_name[-9:]
            
            values = {
                        "payu_api_key":acquirer['payu_api_key'],
                        "payu_merchant_id":acquirer['payu_merchant_id'],
                        "order_name":str(draft_order['name']) + str(' -- ') + str(order_name),
                        "amount":format(float(draft_order['amount_total']), '.2f'), 
                        "currency":res_partner_shipping['currency_name']
                     }
            
            signature_digested = self.generate_signature(values)

            # base url
            query = "select value from ir_config_parameter where key = 'web.base.url' limit 1"
            request.cr.execute(query)
            ir_config_parameter = request.cr.dictfetchone()
            base_url = ir_config_parameter['value']
            
            return {
                        'status' :  "OK",
                        'environment':environment,
                        'name' : res_partner_shipping['name'],
                        'phone' : res_partner_shipping['phone'],
                        'email' : res_partner_shipping['email'],
                        'address' : res_partner_shipping['street'],
                        'city' : res_partner_shipping['city'],
                        'state' : res_partner_shipping['state_name'],
                        'country_code':res_partner_shipping['country_code'],
                        'country_name':res_partner_shipping['country_name'],
                        'zip':res_partner_shipping['zip'],
                        'acquirer':acquirer['name'],  
                        'payu_merchant_id':acquirer['payu_merchant_id'],
                        'payu_account_id':acquirer['payu_account_id'],
                        'order_id':draft_order['id'],
                        'order_name':order_name,
                        'order_name_odoo':draft_order['name'],
                        'order_description':order_description,
                        'date_order':draft_order['date_order'],
                        'amount':format(float(draft_order['amount_total']), '.2f'),
                        'tax':str('0.00'),#draft_order['amount_tax'],
                        'tax_return_base':str('0'),
                        'currency_name':res_partner_shipping['currency_name'],
                        'currency_symbol':res_partner_shipping['currency_symbol'],
                        'signature':signature_digested,
                        'parts_amount':parts_amount,
                        'extra1':order_description,
                        'payer_document':res_partner_shipping['vat'],
                        'response_url':urls.url_join(base_url, '/shop/process_payu_payment'),
                        'end_point_url':self._get_end_point(environment),
                    }
    
    @http.route('/shop/process_payu_payment', csrf=False, auth="public", website=True)    
    def process_payu_payment(self, **kw):
        _response = {}
        #transaction
        _response['lapTransactionState'] = kw.get('lapTransactionState')
        _response['message'] = kw.get('message')
        _response['reference_pol'] = kw.get('reference_pol')
        _response['transactionId'] = kw.get('transactionId')
        _response['description'] = kw.get('description')
        # cards
        _response['lapResponseCode'] = kw.get('lapResponseCode')
        _response['description'] = kw.get('description')
        _response['lapPaymentMethod'] = kw.get('lapPaymentMethod')
        _response['lapPaymentMethodType'] = kw.get('lapPaymentMethodType')
        # pse banks
        _response['pseBank'] = kw.get('pseBank')
        _response['pseReference1'] = kw.get('pseReference1')
        _response['pseReference2'] = kw.get('pseReference2')
        _response['pseReference3'] = kw.get('pseReference3')
        _response['pseCus'] = kw.get('cus')
        _response_html = self._payu_reponse_formatter(_response)

        #with open('/odoo_diancol/custom/addons/payu/log.json', 'w') as outfile:
        #    json.dump(_response, outfile)        

        authorizationResult = _response['lapTransactionState']
        errorMessage = kw.get('lapResponseCode')
        
        if(authorizationResult==str("APPROVED") or authorizationResult==str("PENDING")):
            if('sale_order_id' in request.session):
                current_sale_order_id = request.session.sale_order_id                                
                sale_order = http.request.env['sale.order'].sudo().search([['id','=',current_sale_order_id]])

                if(authorizationResult==str("APPROVED")):
                    sale_order.action_done()   
                else:
                     sale_order.action_confirm()

                query = "select id from payment_acquirer where provider = 'payu' limit 1"
                request.cr.execute(query)
                acquirer = request.cr.dictfetchone()
                acquirer_id = False
                if(acquirer['id']):
                    acquirer_id = acquirer['id']
                    payment_transaction = request.env['payment.transaction'].sudo().create({'partner_id':sale_order.partner_id.id,'partner_name':sale_order.partner_id.name,'date':datetime.datetime.now(),'acquirer_id':int(acquirer_id),'type':'form','state':'done','amount':sale_order.amount_total,'reference':sale_order.name+str("/1"),'currency_id':sale_order.partner_id.currency_id.id})
                    payment_transaction.sudo().write({'payu_response':_response_html,'payu_trans_id':_response['transactionId'], 'payu_trans_order_ref':_response['reference_pol']}) 
                    
                    if(authorizationResult==str("PENDING")):
                        payment_transaction.sudo().update({'state':'pending'})
                    
                    if(authorizationResult==str("REJECTED")):
                        payment_transaction.sudo().update({'state':'pending'})

                    query = "insert into sale_order_transaction_rel (sale_order_id,transaction_id) values("+str(current_sale_order_id)+","+str(payment_transaction.id)+")"
                    request.cr.execute(query) 
                    if(request.session.uid == None):
                        query = "update sale_order set require_payment = TRUE, reference='"+sale_order.name+str("-1")+"', confirmation_date='"+str(datetime.datetime.now())+"' where id = "+str(current_sale_order_id)
                        sale_order.sudo().write({'payu_response':_response_html})
                    else:
                        query = "update sale_order set require_payment = TRUE, reference='"+sale_order.name+str("-1")+"', confirmation_date='"+str(datetime.datetime.now())+"', user_id='"+str(request.session.uid)+"' where id = "+str(current_sale_order_id)
                        request.cr.execute(query)   
                        sale_order.sudo().write({'payu_response':_response_html}) 
                        sale_order.sudo().write({'reference':sale_order.name+str("-1")})  
                        
                    if(authorizationResult==str("REJECTED")):
                        sale_order.sudo().update({'state':'sale','confirmation_date':None}) 
                    
                    if(authorizationResult==str("PENDING")):
                        sale_order.sudo().update({'state':'sale','confirmation_date':None})

                    # get journal payu
                    payu_journal = http.request.env['account.journal'].sudo().search([['code','=','BPAYU']], order='id desc', limit=1)
                    move_name = "BPAYU/"+str(payu_journal.sequence_number_next)
                    
                    # get last statement
                    last_account_bank_statement = http.request.env['account.bank.statement'].sudo().search([('company_id', '=', sale_order.company_id.id),('journal_id','=',payu_journal.id)], order='id desc', limit=1)

                    # adds statement       
                    balance_end = float(last_account_bank_statement.balance_end) +  float(sale_order.amount_total)
                    difference = balance_end * -1

                    if(authorizationResult==str("APPROVED")):

                        new_account_bank_statement = request.env['account.bank.statement'].sudo().create(
                                                                                                            {
                                                                                                            'name':str(sale_order.name)+str("-1"),
                                                                                                            'date':sale_order.date_order,
                                                                                                            'balance_start':last_account_bank_statement.balance_end,
                                                                                                            'balance_end_real':format(balance_end, '.2f'),
                                                                                                            'state':str('open'),
                                                                                                            'journal_id':int(payu_journal.id),
                                                                                                            'company_id':int(sale_order.company_id.id),
                                                                                                            'total_entry_encoding':format(float(last_account_bank_statement.balance_end), '.2f'),
                                                                                                            'balance_end':format(balance_end, '.2f'),
                                                                                                            'difference':format(difference, '.2f'),
                                                                                                            'user_id':int(sale_order.user_id),
                                                                                                            'create_uid':int(sale_order.user_id),
                                                                                                            'create_date':str(sale_order.date_order),
                                                                                                            'write_uid':int(sale_order.user_id),
                                                                                                            'write_date':str(sale_order.date_order),
                                                                                                            }
                        
                                                                                                    )

                        
                        

                            # adds statement line
                        new_account_bank_statement_line = request.env['account.bank.statement.line'].sudo().create (
                                                                                                                        {
                                                                                                                        'name':'PayuLatam - '+str(sale_order.reference),
                                                                                                                        'move_name':move_name, 
                                                                                                                        'ref':sale_order.reference, 
                                                                                                                        'date':sale_order.date_order, 
                                                                                                                        'journal_id':int(payu_journal.id),
                                                                                                                        'partner_id':int(sale_order.partner_id.id),
                                                                                                                        'company_id':int(sale_order.company_id.id),  
                                                                                                                        'create_uid':int(sale_order.user_id),
                                                                                                                        'create_date':str(sale_order.date_order),
                                                                                                                        'write_uid':int(sale_order.user_id),
                                                                                                                        'write_date':str(sale_order.date_order),
                                                                                                                        'statement_id':int(new_account_bank_statement.id),
                                                                                                                        'sequence':int(1),
                                                                                                                        'amount_currency':float(0.00),
                                                                                                                        'amount':format(float(sale_order['amount_total']), '.2f'),
                                                                                                                        }
                                                                                                                    )                          
                    return werkzeug.utils.redirect("/shop/confirmation") 
                else:
                    return werkzeug.utils.redirect("/shop/payment")
            else:
                return werkzeug.utils.redirect("/shop/payment")                          
        else:
            return werkzeug.utils.redirect("/shop/payment?authorizationResult="+str(authorizationResult)+"&errorMessage="+str(errorMessage))       
    
    def file_get_contents(self, filename):
        with open(filename) as f:
            return f.read()

    def file_put_contents(self, filename,data):
        with open(filename) as f:
            return f.write(data)
    
    def _get_end_point(self, environment):
        if environment == '0':
            return str('https://checkout.payulatam.com/ppp-web-gateway-payu')
        else:
            return str('https://sandbox.checkout.payulatam.com/ppp-web-gateway-payu')
    
    def _payu_reponse_formatter(self, _response):

        _statusText = {
                        "APPROVED":"Transacción aprobada",
                        "DECLINED":"Transacción rechazada",
                        "ERROR":"Error procesando la transacción",
                        "EXPIRED":"Transacción expirada",
                        "PENDING":"Transacción pendiente o en validación",
                        "SUBMITTED":"Transacción enviada a la entidad financiera y por algún motivo no terminó su procesamiento. Sólo aplica para la API de reportes"
                      } 

        if(_response['lapPaymentMethodType']=="CREDIT_CARD"):
            _payment_method_icon = str("<span>Tarjeta de Crédito <i class='fa fa-credit-card'/></span>")
            _entity = str("<span>"+str(_response['lapPaymentMethod'])+"</span>")
        elif(_response['lapPaymentMethodType']=="CASH"):
            _payment_method_icon = str("<span>Efectivo <i class='fa fa-money'/></span>")
            _entity = str("<span>"+str(_response['lapPaymentMethod'])+"</span>")
        elif(_response['lapPaymentMethodType']=="REFERENCED"):
            _payment_method_icon = str("<span>Referenciado</span>")
            _entity = str("<span>"+str(_response['lapPaymentMethod'])+"</span>")
        elif(_response['lapPaymentMethodType']=="PSE"):
            _payment_method_icon = str("<span>PSE <i class='fa fa-bank'/></span>")
            _entity = str("<div><span>"+str(_response['pseBank'])+"</span></div>")
            if(_response['pseCus']!=''):
                _entity = _entity + str("<div><label>CUS: <label><span>"+str(_response['pseCus'])+"</span></div>")
            if(_response['pseReference1']!=''):
                _entity = _entity + str("<div><label>Ref 1: <label><span>"+str(_response['pseReference1'])+"</span></div>")
            if(_response['pseReference2']!=''):
                _entity = _entity + str("<div><label>Ref 2: <label><span>"+str(_response['pseReference2'])+"</span></div>")
            if(_response['pseReference3']!=''):
                _entity = _entity + str("<div><label>Ref 3: <label><span>"+str(_response['pseReference3'])+"</span></div>")
        else:
            _payment_method_icon = str("<span>") + str(_response['lapPaymentMethod']) +  str("</span>")

        _response_html = str("<div>")
        
        # row state
        _response_html = _response_html + str("<div class='payu-response-row state-payu-trans'>")
        _response_html = _response_html + str("<label>")
        _response_html = _response_html + str("Estado: ")
        _response_html = _response_html + str("</label>")
        _response_html = _response_html + str("<span>")
        _response_html = _response_html + str(_statusText[""+str(_response['lapTransactionState'])+""])
        _response_html = _response_html + str("</span>")

        if(_response['lapResponseCode']!=''):
            _response_html = _response_html + str("<div><span>"+str(str(_response['lapResponseCode']).replace('_',' ')).capitalize()+"</span></div>")
        _response_html = _response_html + str("</div>")

        #row state code
        _response_html = _response_html + str("<div class='payu-response-row'>")
        _response_html = _response_html + str("<label>")
        _response_html = _response_html + str("Método: ")
        _response_html = _response_html + str("</label>")
        _response_html = _response_html + str("<span>")
        _response_html = _response_html + str(_payment_method_icon)
        _response_html = _response_html + str("</span>")
        _response_html = _response_html + str("</div>")

        _response_html = _response_html + str("<div class='payu-response-row'>")
        _response_html = _response_html + str("<label>")
        _response_html = _response_html + str("Transacción: ")
        _response_html = _response_html + str("</label>")
        _response_html = _response_html + str("<div><span>")
        _response_html = _response_html + str("ID: ")+str(_response['transactionId'])
        _response_html = _response_html + str("</span></div>")
        _response_html = _response_html + str("<div><span>"+ str("REF: ")+str(_response['reference_pol'])+"</span></div>")
        _response_html = _response_html + str("</div>")

        # entity
        _response_html = _response_html + str("<div class='payu-response-row'>")
        _response_html = _response_html + str("<label>")
        _response_html = _response_html + str("Entidad: ")
        _response_html = _response_html + str("</label>")
        _response_html = _response_html + str("<span>")
        _response_html = _response_html + str(_entity)
        _response_html = _response_html + str("</span>")
        _response_html = _response_html + str("</div>")

        _response_html = _response_html + str("</div>")

        return _response_html