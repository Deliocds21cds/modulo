The report is available at Inventory > Reporting > Inventory Turnover.
