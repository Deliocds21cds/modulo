Report to compute the inventory turnover cycles in the last 6 and 12 months.
