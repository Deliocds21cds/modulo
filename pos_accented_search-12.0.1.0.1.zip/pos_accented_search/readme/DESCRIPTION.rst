This add-on makes pos product search insensitive to accented characters in the product
name. For instance, café will match both cafe and café. 
