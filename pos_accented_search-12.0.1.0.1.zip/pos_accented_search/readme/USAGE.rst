Simply install the addon and enjoy product search working regardless of the accented characters in the product name.
