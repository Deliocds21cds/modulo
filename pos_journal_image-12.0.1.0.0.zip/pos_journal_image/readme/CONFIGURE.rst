To configure this module, you need to:

* Go to 'Point Of Sale' / 'Configuration' / 'Payment Methods'

* Select journals available in the PoS

* In the 'Point of Sale' tab, set an image

.. figure:: ../static/description/account_journal_form.png
