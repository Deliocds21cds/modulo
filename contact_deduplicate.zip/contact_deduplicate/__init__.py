# -*- coding: utf-8 -*-

from . import models
from .hooks import _initial_setup