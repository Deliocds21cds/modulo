# -*- coding: utf-8 -*-

from . import daily_purchase_report
