==============
TO-DO
==============

Before installing this app, 
make sure the package poppler-utils is installed

Write this command line on your Linux Server :

> ulimit -n 1000000

> sudo apt-get update --yes

> sudo apt-get upgrade --yes

> sudo apt-get install poppler-utils --yes

==============
fix_wkhtmltopdf
==============

When you print very big pdfs, you can get an buffer-overflow bug,
or the printing report process can be very long, at least 10 minutes for just a pdf with 100 pages.

When installing this module, you will remove the bug of overflow and make your print process faster.
You will printing pdf with 2000 pages in 2 minutes, with an output of the progression in the Linux console.

Be careful because the header and the footer of each PDF will deseapper.
Only the body of the pdf will remain.

Usage
=====
Go to "Settings" - Apps without any filters. Type "fix_wkhtmltopdf" into the search box.

Odoo version 12

Credits
=======

Authors
~~~~~~~

* Yvan Dotet

Maintainers
~~~~~~~~~~~

* This module is maintained by Yvan Dotet.

Contact
~~~~~~~

* Mail address of Yvan Dotet : Yvandotet@yahoo.fr
* website : 
	1) https://github.com/YvanDotet
	2) https://be.linkedin.com/in/yvan-dotet-19ba67135
