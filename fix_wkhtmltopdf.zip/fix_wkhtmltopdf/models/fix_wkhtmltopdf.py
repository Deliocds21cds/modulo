from odoo import api,fields,models,_
from odoo.exceptions import Warning,ValidationError,UserError

from odoo.tools.misc import find_in_path
import os
import tempfile
import subprocess
from contextlib import closing
import logging

_logger = logging.getLogger(__name__)

###########
import time
import datetime
import math
###########

#Etendre l'impression des PDFs pour ne plus avoir de ralentissements
#et de bug de type buffer-overflow

def _get_wkhtmltopdf_bin():
    return find_in_path('wkhtmltopdf')

class Extend_IrActionsReport(models.Model):
    _inherit='ir.actions.report'
    
    @api.model
    def _run_wkhtmltopdf(
            self,
            bodies,
            header=None,
            footer=None,
            landscape=False,
            specific_paperformat_args=None,
            set_viewport_size=False):
                                               
        '''
        Il est recommandé d'écrire la ligne de commande :
        > ulimit -n 1000000
        
        Il est nécessaire d'importer poppler-utils pour utiliser pdfunite.
        
        Donc en root   
        > sudo apt-get update
        > sudo apt-get install poppler-utils
        
        Ensuite
        
        > pdfunite pdf1.pdf   pdf2.pdf   resultat.pdf
        '''
        
        _logger.warning(f"""
                            It's first recommanded to set 
                            > ulimit -n 1000000

                            poppler-utils need to be installed for efficient printing report
                            As a root user :
                            > sudo apt-get update --yes
                            > sudo apt-get install poppler-utils --yes
                            """)

        isPopplerInstall=os.system('dpkg -s poppler-utils | grep Status')
        print('\n')
        
        if isPopplerInstall!=0:
            _logger.error('poppler-utils is not installed')
            
            print(f"""
            
/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/
Package 'poppler-utils' is not installed.

Please do it as a root user :
> ulimit -n 1000000

> sudo apt-get update --yes
> sudo apt-get install poppler-utils --yes

normal wkhtmltopdf process will print this report (slow and with bugs if big PDF)
/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/

""")

            return super()._run_wkhtmltopdf(bodies,header=header,footer=footer,landscape=landscape,specific_paperformat_args=specific_paperformat_args,set_viewport_size=set_viewport_size)

        '''Execute wkhtmltopdf as a subprocess in order to convert html given in input into a pdf
        document.

        :param bodies: The html bodies of the report, one per page.
        :param header: The html header of the report containing all headers.
        :param footer: The html footer of the report containing all footers.
        :param landscape: Force the pdf to be rendered under a landscape format.
        :param specific_paperformat_args: dict of prioritized paperformat arguments.
        :param set_viewport_size: Enable a viewport sized '1024x1280' or '1280x1024' depending of landscape arg.
        :return: Content of the pdf as a string
        '''
        paperformat_id = self.get_paperformat()

        # Build the base command args for wkhtmltopdf bin
        command_args = self._build_wkhtmltopdf_args(
            paperformat_id,
            landscape,
            specific_paperformat_args=specific_paperformat_args,
            set_viewport_size=set_viewport_size)

        files_command_args = []
        temporary_files = []
        if header:
            
            head_file_fd, head_file_path = tempfile.mkstemp(suffix='.html', prefix='report.header.tmp.')
            with closing(os.fdopen(head_file_fd, 'wb')) as head_file:
                head_file.write(header)
            temporary_files.append(head_file_path)
            files_command_args.extend(['--header-html', head_file_path])
        if footer:
        
            foot_file_fd, foot_file_path = tempfile.mkstemp(suffix='.html', prefix='report.footer.tmp.')
            with closing(os.fdopen(foot_file_fd, 'wb')) as foot_file:
                foot_file.write(footer)
            temporary_files.append(foot_file_path)
            files_command_args.extend(['--footer-html', foot_file_path])

        paths = []
        
        for i, body in enumerate(bodies):
        
            prefix = '%s%d.' % ('report.body.tmp.', i)
            body_file_fd, body_file_path = tempfile.mkstemp(suffix='.html', prefix=prefix)
            with closing(os.fdopen(body_file_fd, 'wb')) as body_file:
                body_file.write(body)
            paths.append(body_file_path)
            temporary_files.append(body_file_path)

        pdf_report_fd, pdf_report_path = tempfile.mkstemp(suffix='.pdf', prefix='report.tmp.')
        os.close(pdf_report_fd)
        temporary_files.append(pdf_report_path)

        try:
            #Pour enlever le header et le footer de la recherche pdf
            files_command_args=[]
            
            '''
            paths_modif=list(map(lambda url: "../.."+url,paths))            
            htmls=' '.join(paths_modif)
            
            os.system('cat '+htmls+' > total.html')
            os.system('wkhtmltopdf total.html test.pdf')
            '''
                       
            # Je partitionne les bodies d'html en parties de 200.
            # Et ainsi appliquer un certain nombre de fois wkhtmltopdf par paquets de 200 pdfs.
            lgr=len(paths)
            
            taille=200
            num=lgr/taille
              
            print(f"""
            
            {lgr} HTMLs à convertir en PDFs, par paquets de pdfs de {taille} pages.
            
            """)
            
            begin=time.clock()
            deltas=[]
            
            pdf_report_path_all=[]
            
            i=0            
            while taille*i<lgr:
                tic=time.time()
                
                paths_i=paths[taille*i:taille*(1+i)]
                i=1+i
                
                print(f"""
                
                {str(i)} pdf sur {str(num)}

                """)
            
                pdf_report_i, pdf_report_path_i=tempfile.mkstemp(suffix='.pdf', prefix='pdf_'+str(i)+'_')
                pdf_report_path_all.append(pdf_report_path_i)
                                                
                wkhtmltopdf = [_get_wkhtmltopdf_bin()] + command_args + files_command_args + paths_i + [pdf_report_path_i]            

                process = subprocess.Popen(wkhtmltopdf, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                out, err = process.communicate()               
                                  
                if process.returncode not in [0, 1]:
                    if process.returncode == -11:
                        message = _(
                            'Wkhtmltopdf failed (error code: %s). Memory limit too low or maximum file number of subprocess reached. Message : %s')
                    else:
                        message = _('Wkhtmltopdf failed (error code: %s). Message: %s')
                    raise UserError(message % (str(process.returncode), err[-1000:]))
                else:
                    if err:
                        _logger.warning('wkhtmltopdf: %s' % err)
               
                
                toc=time.time()
                
                delta=toc-tic
                deltas.append(delta)
                                
                meanTime=0 if len(deltas)==0 else (sum(deltas))/len(deltas) 
                
                timeRemain=((num-i) if i<num else (math.fabs(num-math.floor(num))))*meanTime
                
                print(f"""
                Approximate time remaining : {datetime.timedelta(seconds=int(timeRemain))} (Hour : minute : second).
                """)
                
            all_paths=' '.join(pdf_report_path_all)
            
            pdf_report_final, pdf_report_path_final=tempfile.mkstemp(suffix='.pdf', prefix='pdf_final_')                        
            
            print(f"""
            Fusion des pdfs par pdfunite.
            """)
            
            os.system('pdfunite '+all_paths+' '+pdf_report_path_final)
            
            pdf_report_path=pdf_report_path_final
            
        except:
            raise

        with open(pdf_report_path, 'rb') as pdf_document:
            pdf_content = pdf_document.read()

        # Manual cleanup of the temporary files
        for temporary_file in temporary_files:
            try:
                os.unlink(temporary_file)
            except (OSError, IOError):
                _logger.error('Error when trying to remove file %s' % temporary_file)

        return pdf_content

    

