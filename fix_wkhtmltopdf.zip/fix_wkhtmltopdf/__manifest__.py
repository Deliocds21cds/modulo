{
        'name':'fix_wkhtmltopdf',
        'description':'Buffer-overflow and slow printing report are fixed',
        'summary':'Print pdf with 2000 pages in 2 minutes without bug and fast',
        'author':'Yvan Dotet',
        'depends':['base'],
        'data':[
            ],
        'application':False,
        'version':'1.1',
        'license': 'GPL-3',
        'support': 'yvandotet@yahoo.fr',
        'website':'https://github.com/YvanDotet',
        'price': 0.99,
        'currency': 'EUR',

        'images': ['images/thumbnail.png'],       
}
