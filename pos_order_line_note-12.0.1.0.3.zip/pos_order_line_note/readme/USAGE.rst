* Open your Point of Sale

* Set a note on an order line

  .. figure:: ../static/description/point_of_sale.png

* Save the order

* In the back office, open the order, and click on the order line.

  .. figure:: ../static/description/pos_order_form.png
