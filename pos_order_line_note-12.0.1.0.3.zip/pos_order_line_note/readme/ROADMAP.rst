* Make a glue module between ``pos_order_line_note`` and
  ``pos_order_mgmt`` to have the possibility to load the ``note``
  field, and keep the values, when duplicating orders.
