# -*- coding: utf-8 -*-
###############################################################################
# Odoo - Open Source Management Solution
# Copyright (C) 2021 - Today Digilab Peru (<https://www.digilab.pe>)
###############################################################################
{
    'name': "Control de Inventario desde factura",
    'version': '1.2',
    'depends': ['base'],
    'author': "Digilab Perú",
    'category': 'stock',
    'contributors': [
        'Darwin Barron',
        'Luis Alva'
    ],
    'description': """
     Creación de transferencias de Stock por Bodegas
     ----------------------
    """,
    'depends' : ['account', 'stock', 'sale', 'sale_management'],
    # data files always loaded at installation
    'data': [
        "views/account_views_inherit.xml"
    ],
    # data files containing optionally loaded demonstration data
    'demo': [
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
    "sequence": 1,    
}