# -*- coding: utf-8 -*-
###############################################################################
# Odoo - Open Source Management Solution
# Copyright (C) 2021 - Today Digilab Peru (<https://www.digilab.pe>)
###############################################################################
{
    'name': "Control de Inventario desde factura",
    'version': '1.0',
    'depends': ['base'],
    'author': "Digilab Perú",
    'category': 'Localisation/America',
    'contributors': [
        'Darwin Barron',
        'Jorge Escobar'
    ],
    'description': """
     Localización del Perú
     ----------------------
     12/02/2021 Se agrega todos los Departamentos, provincias y distritos del Perú
    """,
    'depends' : ['account', 'stock', 'sale', 'sale_management'],
    # data files always loaded at installation
    'data': [
        "views/account_views_inherit.xml"
    ],
    # data files containing optionally loaded demonstration data
    'demo': [
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
    "sequence": 1,    
}