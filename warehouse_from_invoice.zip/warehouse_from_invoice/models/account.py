# -*- coding: utf-8 -*- 
from odoo import api, fields, models, _
import logging

_logger = logging.getLogger(__name__)

class AccountInherit(models.Model):
    _inherit = "account.invoice"

    location_id = fields.Many2one(comodel_name='stock.location', string='Bodega')
    
    @api.multi
    def action_invoice_open(self):
        values = super(AccountInherit, self).action_invoice_open()
        #va tu code
        res = self.env['stock.picking'].sudo().create({
                'location_id': self.location_id.id,
                'location_dest_id':2,
                'picking_type_id': 5,
                'state':'done',
                'origin': self.number
            })
        for line in self.invoice_line_ids:
            obj={
                'product_id':line.product_id.id,
                'product_uom_qty':line.quantity,
                'reserved_availability':line.quantity,
                'quantity_done':line.quantity,
                'name':line.name,
                'product_uom':line.product_id.uom_id.id,
                'picking_id': res.id,
                'location_id':self.location_id.id,
                'location_dest_id': res.picking_type_id.default_location_dest_id.id,
                'state': 'done',
                'picking_type_id': res.picking_type_id.id,
            }
            self.env['stock.move'].sudo().create(obj)
        return values
