# -*- coding: utf-8 -*- 
from odoo import api, fields, models, _

class WarehouseInherit(models.Model):
    _inherit = "stock.location"

    invoice_ids = fields.One2many(comodel_name='account.invoice', inverse_name='location_id', string='Facturas')
    