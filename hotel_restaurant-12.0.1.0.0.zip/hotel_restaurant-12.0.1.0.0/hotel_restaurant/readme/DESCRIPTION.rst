This Module is providing table booking facilities and Managing customers orders

You can manage:

* Restaurant Configuration (Food Item, Table)

* **Table Reservation**

.. image:: https://raw.githubusercontent.com/OCA/vertical-hotel/11.0/hotel_restaurant/static/description/res2.png
   :width: 750px

* **Manage Food Orders**

.. image:: https://raw.githubusercontent.com/OCA/vertical-hotel/11.0/hotel_restaurant/static/description/res3.png
   :width: 750px

* **Manage Kitchen Order ticket**

.. image:: https://raw.githubusercontent.com/OCA/vertical-hotel/11.0/hotel_restaurant/static/description/res4.png
   :width: 750px

* **Quick Table Reservation Facility With Its Food Order**

.. image:: https://raw.githubusercontent.com/OCA/vertical-hotel/11.0/hotel_restaurant/static/description/res5.png
   :width: 750px

* **Order's History In Hotel Folio**

.. image:: https://raw.githubusercontent.com/OCA/vertical-hotel/11.0/hotel_restaurant/static/description/res6.png
   :width: 750px

* Payment

* Different Reports are also provided, mainly for Restaurant.
