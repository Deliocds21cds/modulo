Adds a new page in partner to manage its *Financial Risk*.

If any limit is exceeded, you won't be able to confirm any of its invoices
unless you are authorized (Account Billing Manager group).
