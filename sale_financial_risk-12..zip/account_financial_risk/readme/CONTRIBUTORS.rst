* `Tecnativa <https://www.tecnativa.com>`_:

  * Carlos Dauden
  * Pedro M. Baeza
  * Ernesto Tejeda

* Agathe Mollé <agathe.molle@savoirfairelinux.com>
