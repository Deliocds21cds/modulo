To configure this module, you need to:

#. Go to *Invoicing/Accounting > Configuration > Settings > Accounting*
#. In the *Customer Payments* section, fill *Maturity Margin* for setting the
   number of days to last after the due date to consider an invoice as unpaid.
