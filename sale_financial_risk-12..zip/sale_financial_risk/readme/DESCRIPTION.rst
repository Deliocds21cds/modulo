Extends Partner Financial Risk to manage sales orders.

If any limit is exceed the partner gets forbidden to confirm sale orders.
