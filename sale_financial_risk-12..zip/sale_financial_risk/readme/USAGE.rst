To use this module, you need to:

#. Go to *Customers > Financial Risk*
#. Set limits and choose options to compute in credit limit.
#. Go to *Sales -> Orders -> Orders* and create a new Sales Orders.
