from . import sale
from . import res_partner
