from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_compare



class loan_installment_payment(models.Model):
    _inherit = "account.payment"
    _description = "Loan Payment"
    _order = "payment_date desc, name desc"

    loan_id = fields.Many2one('dev.loan.loan', string='Préstamo')
    code = fields.Char('Código')
    saldo_actual = fields.Float('Saldo Actual', compute='_compute_is_done', store=True)
    capital = fields.Float('Capital Actual', compute='_compute_is_done', store=True)
    intereses_a_fecha = fields.Float('Intereses a la Fecha', compute='_compute_is_done', store=True)
    saldo_nuevo = fields.Float('Nuevo saldo después de este pago', compute='_compute_is_done', store=True)
    efectivo = fields.Boolean('Efectivo')
    consignacion = fields.Boolean('Consignación')
    banco = fields.Char(string='Banco')
    cheque = fields.Boolean('Cheque')
    número_cheque = fields.Char('Número de Cheque')
    notes = fields.Text('Observaciones')
    a_pagar = fields.Selection([('todo','Total'),('intereses','Solo Intereses'),('capital','Solo Capital')],string='Paga',
                                    required=True, default='todo')
    payment_type = fields.Selection([('desembolso', 'Desembolso'), ('cuota_abonos', 'Pago de Cuotas o Abonos'), ('interna', 'Transferencia Interna')], string='Tipo de Pago',
                                    required=True)

    solitud_prestamo = fields.Many2one('loan.solicitud.prestamo', string='Solicitud Préstamo')

    @api.onchange('code')
    def _on_change_code(self):
        loan = self.env['dev.loan.loan'].search([('client_id.code', '=', self.code)])
        for record in self:
            for l in loan:
                record.saldo_actual = loan.loan_amount
                record.saldo_nuevo = record.saldo_actual
                record.capital = 0
                record.intereses_a_fecha = 0
                record.loan_id = l.id

                for installment in l.installment_ids:
                    if installment.loan_state in ('paid'):
                        record.saldo_actual = record.saldo_actual - installment.amount
                        record.capital = record.capital + installment.amount
                        record.intereses_a_fecha = record.intereses_a_fecha + installment.interest
                        record.saldo_nuevo = record.saldo_actual - installment.amount


    #Cambie nombre de la funcion de _compute_installment a _compute_is_done porque 
    #_compute_installment no existia en otro lado
    @api.one
    def _compute_is_done(self):
        if self.code:
            loan = self.env['dev.loan.loan'].search([('client_id.code', '=', self.code)])
            for record in self:
                for l in loan:
                    record.saldo_actual = loan.loan_amount
                    record.saldo_nuevo = record.saldo_actual
                    record.capital = 0
                    record.intereses_a_fecha = 0
                    record.loan_id = l.id

                    for installment in l.installment_ids:
                        if installment.loan_state in ('paid'):
                            record.saldo_actual = record.saldo_actual - installment.amount
                            record.capital = record.capital + installment.amount
                            record.intereses_a_fecha = record.intereses_a_fecha + installment.interest
                            record.saldo_nuevo = record.saldo_actual - installment.amount

