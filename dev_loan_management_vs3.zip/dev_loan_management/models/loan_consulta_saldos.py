# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class loan_consulta_saldos(models.TransientModel):
    _name = "loan.consulta.saldos"

    prestatario_id = fields.Many2one('res.partner',string='Buscar Prestatario')
    modalidad = fields.Selection([
        ('diario', 'Diario'),
        ('semanal', 'Semanal'),
        ('quincenal', 'Quincenal'),
        ('mensual', 'Mensual'),
        ], string='Modalidad', track_visibility='onchange')

    estado = fields.Selection([
        ('todos', 'Todos'),
        ('abierto', 'Abierto'),
        ('cerrado', 'Cerrado'),
        ], string='Prestamos', default='todos')
    
    fecha_desde = fields.Date(string='Fecha Desde')
    fecha_hasta = fields.Date(string='Fecha Hasta')


    # tabla = fields.Html(string='Resultado:')
    prestamos_ids = fields.One2many('loan.solicitud.prestamo','tipo_prestamo',string='Prestamos')

    #modificar a que el pago este en estado pagado

    @api.multi
    @api.onchange('modalidad','estado','prestatario_id')
    def onchange_buscar(self):
        rec = None
        rec_list=[]

        if self.prestatario_id:
            rec = self.prestatario_id
            prestamos = self.env['loan.solicitud.prestamo'].search([('prestatario_id','=',rec.id)])
            if prestamos:
                for x in prestamos:
                    rec_list.append((4,x.id,False))
            
            self.prestamos_ids=rec_list    

        # reporte  = '<h2>Consulta de saldos por Cliente</h2>'
        # reporte += '<table style="width:100%;">'
        # reporte += '   <thead style="border: thin solid gray;">'
        # reporte += '        <tr style="border: thin solid gray;">'
        # reporte += '            <th colspan="4" style="border: thin solid gray; text-align: center">Producto</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Meses</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Capital</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Intereses</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Total a pagar</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Saldo</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">C. Fija Mensual</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Quincenal</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Semanal</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Diaria</th>'
        # reporte += '        </tr style="border: thin solid gray;">'
        # reporte += '    </thead>'
        # reporte += '    <tbody>'



        # if rec:

        #     reporte += '        <tr style="border-bottom: thin solid gray;">'
        #     reporte += '            <td colspan="4" style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
            

        #     reporte += '        </tr>'
        #     reporte += '    </tbody></table >'

        #     self.tabla =reporte

    