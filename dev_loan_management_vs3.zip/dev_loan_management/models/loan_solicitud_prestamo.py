# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class loan_solicitud_prestamo(models.Model):
    _name = "loan.solicitud.prestamo"

    prestatario_id = fields.Many2one('res.partner',string='Prestatario', required=True)
    tipo_prestamo = fields.Selection([('credito_directo', 'Credito Directo'),('amortizacion', 'Amortizacion')], string='Tipo de Prestamo Modalidad',  required=True)
    plazo = fields.Integer(string='Plazo en meses',  required=True)
    valor_solicitado = fields.Integer(string='Valor Solicitado', required=True)
    fecha_solicitud = fields.Date(string='Fecha de Solicitud', required=True)
    user_id = fields.Many2one('res.users',string='Usuario')
    company_id = fields.Many2one('res.company',string='Compañia', required=True)
    tabla = fields.Html(string=' ')
    documentos1 = fields.Binary(string='Documentacion', attachment=True)
    documentos2 = fields.Binary(string='Documentacion', attachment=True)
    
    modalidad = fields.Selection([
        ('diario', 'Diario'),
        ('semanal', 'Semanal'),
        ('quincenal', 'Quincenal'),
        ('mensual', 'Mensual'),
        ], string='Modalidad', required=True, track_visibility='onchange')

    pagos_ids = fields.One2many('account.payment','solitud_prestamo',string='Pagos')

    notas = fields.Text(string='Notas')

    state = fields.Selection([('draft', 'Borrador'), ('done', 'Confirmar'),
       ('aprobado', 'Aprobado'),('rechazado', 'Rechazado'), ], required=True, default='draft')

    valor_de_intereses = fields.Float(string='Valor de intereses', required=True)

   
    saldo_restante = fields.Integer(string='Saldo restante', readonly=True, compute='_compute_get_deuda',store=True)
    mensaje = fields.Char(string='',readonly=True)

    @api.one
    def _compute_get_deuda(self):
        saldo = 0
        
        if len(self.pagos_ids)>0:
            for i in self.pagos_ids:
                saldo +=i.amount
                
            self.saldo_restante = self.deuda - saldo
        else:
            self.saldo_restante = self.deuda
    
    deuda = fields.Integer(string='Deuda', readonly=True) #Este debe ser computado buscar el valor pendiente


    def button_done(self):
        cambio=True
        if self.state == 'rechazado' and cambio:
            self.state = 'draft'
            cambio=False
        if self.state == 'aprobado'and cambio:
            self.state = 'rechazado'
            cambio=False
        if self.state == 'done'and cambio:
            self.state = 'aprobado'
            cambio=False
        if self.state == 'draft'and cambio:
            self.state = 'done'
            cambio=False


    def button_print(self):
        print('test')

    def button_calculate(self):
        
        if self.modalidad and self.plazo and self.valor_solicitado and self.valor_de_intereses and self.tipo_prestamo == 'credito_directo':
            
            if self.modalidad == 'diario':
                capitan_prestado = self.valor_solicitado
                interes = (self.valor_de_intereses/100)*capitan_prestado
                #cuota_sin_interes =  self.valor_solicitado / self.plazo
                plazo_a_dias = int(self.plazo) * 30
                total_intereses = interes * self.plazo#calculo total de intereses para sumar al total solicitado
                total = capitan_prestado + total_intereses
                cuota = round(total/plazo_a_dias,1)
                self.deuda = total # corregir restar al saldo de pagos que hace referencia a esta solicitud de prestamo
                self.mensaje = u"Modalidad {mod}. Son {plazo} cuotas de ${cuotas}".format(mod='Diario',plazo = plazo_a_dias, cuotas = cuota)
                

            if self.modalidad == 'semanal':
                capitan_prestado = self.valor_solicitado
                interes = (self.valor_de_intereses/100)*capitan_prestado
                #cuota_sin_interes =  self.valor_solicitado / self.plazo
                plazo_a_dias = int(self.plazo) * 4
                total_intereses = interes * self.plazo#calculo total de intereses para sumar al total solicitado
                total = capitan_prestado + total_intereses
                cuota = round(total/plazo_a_dias,1)
                
                self.deuda = total # corregir restar al saldo de pagos que hace referencia a esta solicitud de prestamo
                self.mensaje = u"Modalidad {mod}. Son {plazo} cuotas de ${cuotas}".format(mod='Semanal' ,plazo = plazo_a_dias, cuotas = cuota)
                
        
            if self.modalidad == 'quincenal':
                capitan_prestado = self.valor_solicitado
                interes = (self.valor_de_intereses/100)*capitan_prestado
                #cuota_sin_interes =  self.valor_solicitado / self.plazo
                plazo_a_dias = int(self.plazo) * 15
                total_intereses = interes * self.plazo#calculo total de intereses para sumar al total solicitado
                total = capitan_prestado + total_intereses
                cuota = round(total/plazo_a_dias,1)
                
                self.deuda = total # corregir restar al saldo de pagos que hace referencia a esta solicitud de prestamo
                self.mensaje = u"Modalidad {mod}. Son {plazo} cuotas de ${cuotas}".format(mod='Quincenal',plazo = plazo_a_dias, cuotas = cuota)
             

            if self.modalidad == 'mensual':
                capitan_prestado = self.valor_solicitado
                interes = (self.valor_de_intereses/100)*capitan_prestado
                cuota_sin_interes =  self.valor_solicitado / self.plazo
                total_intereses = interes * self.plazo
                cuota = round(cuota_sin_interes +interes,1)
                total = capitan_prestado + total_intereses
                self.deuda = total
                self.mensaje = u"Modalidad {mod}. Son {plazo} cuotas de ${cuotas}".format(mod='Mensual' ,plazo = int(self.plazo), cuotas = cuota)
                

        if self.modalidad and self.plazo and self.valor_solicitado and self.valor_de_intereses and self.tipo_prestamo == 'amortizacion':

            saldo = self.valor_solicitado
            intereses = 0 
            cuotas = self.valor_solicitado / self.plazo

            for i in range(self.plazo):
                
                intereses_saldo = saldo * (self.valor_de_intereses/100)
                intereses = intereses + intereses_saldo
                if (saldo-cuotas)>0:
                    saldo = saldo - cuotas
                    #print('el if', saldo, intereses)
                else:
                    #print('el else es el fin', saldo)
                    continue

            reporte  = '<h2>Liquidacion de Prestamo con Intereses sobre Saldo</h2>'
            reporte += '<table style="width:100%;">'
            reporte += '   <thead style="border: thin solid gray;">'
            reporte += '        <tr style="border: thin solid gray;">'
            reporte += '            <th colspan="4" style="border: thin solid gray; text-align: center">Producto</th>'
            reporte += '            <th style="border: thin solid gray; text-align: center">Meses</th>'
            reporte += '            <th style="border: thin solid gray; text-align: center">Capital</th>'
            reporte += '            <th style="border: thin solid gray; text-align: center">Intereses</th>'
            reporte += '            <th style="border: thin solid gray; text-align: center">Total a pagar</th>'
            reporte += '            <th style="border: thin solid gray; text-align: center">Saldo</th>'
            reporte += '            <th style="border: thin solid gray; text-align: center">C. Fija Mensual</th>'
            reporte += '            <th style="border: thin solid gray; text-align: center">Quincenal</th>'
            reporte += '            <th style="border: thin solid gray; text-align: center">Semanal</th>'
            reporte += '            <th style="border: thin solid gray; text-align: center">Diaria</th>'
            reporte += '        </tr style="border: thin solid gray;">'
            reporte += '    </thead>'
            reporte += '    <tbody>'


            # reporte += '        <tr style="border-bottom: thin solid gray;">'
            # reporte += '            <td colspan="4" style="text-align: center; vertical-align: middle;">%s</td>' % (i.product_tmpl_id.name)
            # reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % (i.generico_id.name)
            # reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % (i.forma_farmaceutica_id.name)
            # reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % (i.concentracion_valor)
            # reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % (i.concentracion_unidad.name)
            # reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % (i.stock_critico)
            # reporte += '        </tr>'
            # reporte += '    </tbody></table >'


            if self.modalidad == 'diario':
                a_dias = self.plazo*30
                #print ('fin','cuotas',cuotas,'intereses',intereses,(intereses+cuotas)/a_dias)
                

            if self.modalidad == 'semanal':
                a_dias = self.plazo*4
                #print ('fin','cuotas',cuotas,'intereses',intereses,(intereses+cuotas)/a_dias)
                
        
            if self.modalidad == 'quincenal':
                a_dias = self.plazo*2
                #print ('fin','cuotas',cuotas,'intereses',intereses,(intereses+cuotas)/a_dias)
             

            if self.modalidad == 'mensual':
                a_dias = self.plazo
                # print ('fin','cuotas',cuotas,'intereses',intereses,(intereses+cuotas)/a_dias)
             
