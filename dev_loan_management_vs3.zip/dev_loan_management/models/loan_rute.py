# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2015 DevIntelle Consulting Service Pvt.Ltd (<http://www.devintellecs.com>).
#
#    For Module Support : devintelle@gmail.com  or Skype : devintelle
#
##############################################################################

from odoo import models, fields, api, _


class loan_rute(models.Model):
    _name = "loan.rute"

    name = fields.Char('Nombre de la Ruta', required="1", copy=False)
    code = fields.Char('Codigo')
    cobrador = fields.Many2one('res.partner',string='Cobrador', required=True)