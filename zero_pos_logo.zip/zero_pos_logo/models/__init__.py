from . import pos_config_image

