======================
Zero POS Logo
======================

Based on Point of Sale Logo v12 (by Zero Systems )
==============================================================
This module helps you to set a logo for each point of sale. 
You can also see this logo in pos screen and pos receipt  with 
-special logo  for each pos
-header+footer
-customer address+mobile+phone + Vat.

Installation
============
Just select it from available modules to install it,
there is no need to extra installations.


Configuration & Usage
=====================
* Go to configuration of POS.
* Add a logo to your POS.
* Ensure logo is near the resolution (width:76px;height:47px).

Credits
=======
Developed by ©Zero Systems

Point of Sale Logo v12:
-----------------------
Developer: Islam Mohamed +201024439422 sales@erpzero.com
