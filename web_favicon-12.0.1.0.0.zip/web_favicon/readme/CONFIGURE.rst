Upload your favicon (16x16, 32x32, 64x64 or "as big as possible") on the
company form. The file format would be ico, gif or png with 16x16, 32x32 or
64x64 pixels and 16 colors. Highers resolutions or colors support depends on
the used browser, but most modern browsers do.

Note that most browsers cache favicons basically forever, so if you want your
icon to show up, you'll most probably have to delete you browser cache.
Some browsers can refresh the favicon, accessing the URL
<base_url>/web_favicon/favicon.

You have a sample SVG that can be used as template for generating your icon
in /static/src/img/master_original_favicon.svg. You can also search for some
favicon generators across the web.

To allow a user to edit the favicon it has to be member of group "Administration / Settings".
