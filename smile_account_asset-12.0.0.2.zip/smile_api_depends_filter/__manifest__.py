# -*- coding: utf-8 -*-
# (C) 2018 Smile (<http://www.smile.fr>)
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

{
    "name": "@api.depends filtering",
    "version": "0.1",
    "depends": ["smile_filtered_from_domain"],
    "author": "Smile",
    "license": 'AGPL-3',
    "description": """""",
    "website": "",
    'category': 'Tools',
    "sequence": 0,
    "data": [
        "security/ir.model.access.csv",
    ],
    "auto_install": True,
    "installable": True,
    "application": False,
}
