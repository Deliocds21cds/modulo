# -*- coding: utf-8 -*-
import logging

from odoo import models, fields, api

_logger = logging.getLogger(__name__)


class ResponsabilidadFiscal(models.Model):
    _name = 'l10n_co_cei_settings.responsabilidad_fiscal'
    _rec_name = 'significado'

    significado = fields.Char(string='Significado')
    codigo_fe_dian = fields.Char(string='Código DIAN')

    fe_habilitada_compania = fields.Boolean(
        string='FE Compañía',
        compute='compute_fe_habilitada_compania',
        store=False,
        copy=False
    )

    @api.multi
    @api.depends('codigo_fe_dian')
    def compute_fe_habilitada_compania(self):
        for record in self:
            record.fe_habilitada_compania = self.env.user.company_id.fe_habilitar_facturacion

    @api.multi
    def name_get(self):
        result = []
        for record in self:
            result.append((record.id, record.significado))
        return result
