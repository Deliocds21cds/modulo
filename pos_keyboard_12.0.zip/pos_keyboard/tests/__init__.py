# License MIT (https://opensource.org/licenses/MIT).

from . import test_pos_keyboard
