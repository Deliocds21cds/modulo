* Mathieu Vatel <mathieu@julius.fr>
* Mykhailo Panarin <m.panarin@mobilunity.com>
* Sergio Teruel <sergio.teruel@tecnativa.com>
* Joan Sisquella <joan.sisquella@eficent.com>
* Jordi Ballester Alomar <jordi.ballester@eficent.com>
* Lois Rilo <lois.rilo@eficent.com>
