Registering a payment

#. Go to an open customer invoice or vendor bill and press 'Register Payment'.
#. Enter the payment details and press 'Validate & View Payment'.

After payment has been made

#. Go to an open customer invoice or vendor bill and press the link
   'View Payments' that appears next to the list of payments made for that
   invoice.
