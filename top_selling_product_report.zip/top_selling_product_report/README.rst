Top/Least Selling Product Report v12
====================================
Top Selling and Least Selling Product Reports

Installation
============
	- www.odoo.com/documentation/12.0/setup/install.html
	- Install our custom addon

Configuration
=============

    No additional configurations needed

Credits
=======
    Developer: Ajmal JK @ cybrosys, Contact: odoo@cybrosys.com
