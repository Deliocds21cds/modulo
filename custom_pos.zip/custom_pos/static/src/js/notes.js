odoo.define('custom_pos.notes', function (require) {
    "use strict";

    var models = require('point_of_sale.models');
    var screens = require('point_of_sale.screens');
    var core = require('web.core');

    var QWeb = core.qweb;
    var _t   = core._t;

    var _super_orderline = models.Orderline.prototype;
    var _super_order = models.Order.prototype;


    models.Orderline = models.Orderline.extend({
        initialize: function(attr, options) {
            _super_orderline.initialize.call(this,attr,options);
            this.note = this.note || "";
        },
        set_note: function(note){
            this.note = note;
            this.trigger('change',this);
        },
        get_note: function(note){
            return this.note;
        },
        can_be_merged_with: function(orderline) {
            if (orderline.get_note() !== this.get_note()) {
                return false;
            } else {
                return _super_orderline.can_be_merged_with.apply(this,arguments);
            }
        },
        clone: function(){
            var orderline = _super_orderline.clone.call(this);
            orderline.note = this.note;
            return orderline;
        },
        export_as_JSON: function(){
            var json = _super_orderline.export_as_JSON.call(this);
            json.note = this.note;
            return json;
        },
        init_from_JSON: function(json){
            _super_orderline.init_from_JSON.apply(this,arguments);
            this.note = json.note;
        },
    });

    var CPOrderlineNoteButton = screens.ActionButtonWidget.extend({
        template: 'CPOrderlineNoteButton',
        button_click: function(){
            var line = this.pos.get_order().get_selected_orderline();
            if (line) {
                this.gui.show_popup('textarea',{
                    title: _t('Add Order Line Note'),
                    value:   line.get_note(),
                    confirm: function(note) {
                        line.set_note(note);
                    },
                });
                this.gui.current_popup.$el.find("textarea").before('<small style="padding:0 22px 8px 22px;float:left;text-align:left;font-size:12px;color:red;">For new line (Ctrl + Enter)</small>');
            } else {
                this.gui.show_popup('alert', {
                    title: _t('Alert'),
                    body:  _t('There are no product available in cart'),
                });
            }
        },
    });

    screens.define_action_button({
        'name': 'cp_orderline_note',
        'widget': CPOrderlineNoteButton,
        'condition': function(){
            if(this.pos.config.iface_orderline_notes == undefined || this.pos.config.iface_orderline_notes == false){
                return true;
            }
            return false;
            // return this.pos.config.iface_orderline_notes;
        },
    });

    models.Order = models.Order.extend({
        initialize: function(attr, options) {
            _super_order.initialize.call(this,attr,options);
            this.note = this.note || "";
        },
        set_note: function(note){
            this.note = note;
            this.trigger('change',this);
        },
        get_note: function(note){
            return this.note;
        },
        export_as_JSON: function(){
            var json = _super_order.export_as_JSON.call(this);
            json.note = this.note;
            return json;
        },
        export_for_printing: function(){
            var receipt = _super_order.export_for_printing.call(this);
            receipt.note = this.note;
            return receipt;
        },
        init_from_JSON: function(json){
            _super_order.init_from_JSON.apply(this,arguments);
            this.note = json.note;
        },
    });

    var CPOrderNoteButton = screens.ActionButtonWidget.extend({
        template: 'CPOrderNoteButton',
        button_click: function(){
            var order = this.pos.get_order();
            var line = this.pos.get_order().get_selected_orderline();
            if (order && line) {
                this.gui.show_popup('textarea', {
                        title: _t('Add Order Note'),
                        value: order.get_note(),
                        confirm: function (note) {
                            order.set_note(note);
                    },
                });
                this.gui.current_popup.$el.find("textarea").before('<small style="padding:0 22px 8px 22px;float:left;text-align:left;font-size:12px;color:red;">For new line (Ctrl + Enter)</small>');
            } else {
                this.gui.show_popup('alert', {
                    title: _t('Alert'),
                    body:  _t('There are no product available in cart'),
                });
            }
        },
    });

    screens.define_action_button({
        'name': 'cp_order_note',
        'widget': CPOrderNoteButton,
        'condition': function(){
            if(this.pos.config.iface_orderline_notes == undefined || this.pos.config.iface_orderline_notes == false){
                return true;
            }
            return false;
            // return this.pos.config.iface_orderline_notes;
        },
    });

    screens.OrderWidget.include({
        update_summary: function(){
            this._super();

            var order = this.pos.get_order();
            var $ordernote = $(this.el).find('li.cp-order-note');

            if(order.get_note()){
                var note = order.get_note();
                $ordernote.replaceWith($(QWeb.render('CPOrderNote', {
                    widget: this,
                    note: note,
                })));
                $ordernote.removeClass("oe_hidden");
            }else{
                $ordernote.empty();
                $ordernote.addClass("oe_hidden");
            }
        },
    });

    return {
        OrderlineNoteButton: CPOrderlineNoteButton,
        CPOrderNoteButton: CPOrderNoteButton,
    }
});
