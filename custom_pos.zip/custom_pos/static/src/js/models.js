odoo.define('custom_pos.models', function (require) {
    "use strict";

    var models = require('point_of_sale.models');
    var rpc = require('web.rpc');
    var ajax = require('web.ajax');

    var _super_posmodel = models.PosModel.prototype;
    var _posmodel = models.PosModel;

    models.PosModel = models.PosModel.extend({
        load_server_data: function(){
            var self = this;

            var loaded = _super_posmodel.load_server_data.call(this);

            var prod_model = _.find(this.models, function(model){
                return model.model === 'product.product';
            });
            if (prod_model) {
                prod_model.fields.push('qty_available', 'type');
                var loaded_super = prod_model.loaded;
                prod_model.loaded = function(that, products){
                    loaded_super(that, products);
                    self.db.product_qtys = products;
                };
                return loaded;
            }

            return loaded.then(function(){
                return rpc.query({
                        model: 'product.product',
                        method: 'search_read',
                        args: [],
                        fields: ['qty_available', 'type'],
                        domain: [['sale_ok','=',true],['available_in_pos','=',true]],
                    }).then(function(products){
                        self.db.product_qtys = products;
                    });
            });
        },
        _flush_orders: function (orders, options) {
            var self = this;
            this.set('synch', {state: 'connecting', pending: orders.length});

            return this._save_to_server(orders, options).then(function (server_ids) {
                self.set_synch('connected');

                orders.forEach(function (order) {
                    order.data.lines.forEach(function (lineArr) {
                        lineArr.forEach(function (line) {
                            if(line.product_id){
                                var product = self.db.get_product_by_id(line.product_id);
                                // updating virtual available for product via ajax
                                ajax.jsonRpc('/pos/products', 'call', {product_id: product.id}).then(function (data) {
                                    data = JSON.parse(data);
                                    // product.qty_available -= line.get_quantity();
                                    product.qty_available = data.qty_available;
                                    self.refresh_qty_available(product);
                                });
                            }
                        });
                    });
                });

                return _.pluck(server_ids, 'id');
            }).catch(function(error){
                self.set_synch(self.get('failed') ? 'error' : 'disconnected');
                return Promise.reject(error);
            });
        },
        set_product_qty_available: function(product, qty) {
            product.qty_available = qty;
            this.refresh_qty_available(product);
        },
        after_load_server_data: function() {
            var self = this;
            var res = _super_posmodel.after_load_server_data.apply(this, arguments);
            _.each(this.db.product_qtys, function(v){
                _.extend(self.db.get_product_by_id(v.id), v);
            });
            return res;
        },
        refresh_qty_available:function(product){
            var $elem = $("[data-product-id='"+product.id+"'] .qty-tag");
            $elem.html(product.qty_available);
            if (product.qty_available <= 0 && !$elem.hasClass('qty-tag-negative')){
                $elem.removeClass('qty-tag-positive');
                $elem.addClass('qty-tag-negative');
            } else {
                $elem.removeClass('qty-tag-negative');
                $elem.addClass('qty-tag-positive');
            }
        },
    });

    var _super_orderline = models.Orderline.prototype;
    models.Orderline = models.Orderline.extend({
        export_as_JSON: function () {
            var data = _super_orderline.export_as_JSON.apply(this, arguments);
            data.qty_available = this.product.qty_available;
            return data;
        },
        // compatibility with pos_multi_session
        apply_ms_data: function (data) {
            if (_super_orderline.apply_ms_data) {
                _super_orderline.apply_ms_data.apply(this, arguments);
            }
            var product = this.pos.db.get_product_by_id(data.product_id);
            if (product.qty_available !== data.qty_available) {
                this.pos.set_product_qty_available(product, data.qty_available);
            }
        },

    });

});
