odoo.define('custom_pos.screens', function (require) {
    "use strict";

    var screens = require('point_of_sale.screens');
    var PopupWidget = require('point_of_sale.popups');
    var core = require('web.core');
    var gui = require('point_of_sale.gui');

    var _t = core._t;

    /* customizing product list widget search option */
    var ProductListWidget = screens.ProductListWidget.include({
        template: 'ProductListWidget',
        init: function(parent, options) {
            parent.t = this.template;
            var self = this;
            this._super(parent,options);

            this.keypress_product_handler = function(ev){
                // React only to SPACE to avoid interfering with warcode scanner which sends ENTER
                if (ev.which != 13) {
                    return;
                }
                ev.preventDefault();
                var product = self.pos.db.get_product_by_id(this.dataset.productId);
                options.click_product_action(product);
                // $(".selected-mode").focus();
                // $(".numpad").focus();
            };
        },
    });


    /* customizing product screen widget for shortcut */
    var ShortcutTipsWidget = PopupWidget.extend({
        template: 'ShortcutTipsWidget',
        show: function () {
            this._super();
        }
    });
    gui.define_popup({name: 'shortcuttips', widget: ShortcutTipsWidget});

    var PaymentScreenWidget = screens.PaymentScreenWidget.include({
        validate_order: function (force_validation) {
            var self = this;
            var order = this.pos.get_order();

            this.gui.show_popup('confirm',{
                title: _t('Please Confirm Payment'),
                body:  _t('Are you sure to complete payment process with') +
                       ' ' +
                       this.format_currency(order.get_total_paid()) +
                       ' ' +
                       _t('? Clicking "Confirm" will validate the payment.'),
                confirm: function() {
                    if (self.order_is_valid(force_validation)) {
                        self.finalize_validation();
                    }
                },
            });
            return false;
        }
    });

    var ProductScreenWidget = screens.ProductScreenWidget.include({
        init: function(parent, options){
            this._super(parent, options);

            var self = this;

            this.actionpad = new screens.ActionpadWidget(this,{});
            this.actionpad.replace(this.$('.placeholder-ActionpadWidget'));

            this.numpad = new screens.NumpadWidget(this,{});
            this.numpad.replace(this.$('.placeholder-NumpadWidget'));


            this.product_screen_keydown_event_handler = function(event){
                if($($(document).find("div.popups")[0]).find('div.modal-dialog').not(".oe_hidden").length < 1){
                    /* product screen key down events */
                    if(!$($(document).find(".product-screen")[0]).hasClass('oe_hidden')){
                        if(event.which == 113) {                                    // click on "F2" button
                            $(document).find("div.product-screen div.middlepane span#shortcut_tips_btn").trigger("click");
                            event.preventDefault();
                        }
                    }

                    if($(document).find(".search-input").is(":focus") && !$($(document).find(".product-screen")[0]).hasClass('oe_hidden')){
                        if(event.which == 27){
                            $($(document).find("div.product-screen")[0]).find("div.rightpane div.searchbox span.search-clear.right").trigger('click');
                            event.preventDefault();
                        }
                    }

                    if(!$(document).find(".search-input").is(":focus") && !$($(document).find(".product-screen")[0]).hasClass('oe_hidden')){
                        if(event.which == 81){                                      // click on "Q" button
                            self.numpad.state.changeMode('quantity');
                            event.preventDefault();
                        } else if(event.which == 68){                               // click on "D" button
                            self.numpad.state.changeMode('discount');
                            event.preventDefault();
                        } else if(event.which == 80){                               // click on "P" button
                            self.numpad.state.changeMode('price');
                            event.preventDefault();
                        } else if(event.which == 82) {                              // click on "R" button
                            $(document).find("div.product-screen div.middlepane div#loyalty_button").trigger("click");
                            event.preventDefault();
                        } else if(event.which == 78) {                              // click on "N" button
                            $(document).find("div.product-screen div.middlepane div#order_note").trigger("click");
                            event.preventDefault();
                        } else if(event.which == 76) {                              // click on "L" button
                            $(document).find("div.product-screen div.middlepane div#order_line_note").trigger("click");
                            event.preventDefault();
                        // } else if(event.which == 79) {                              // click on "O" button
                        } else if(event.which == 56) {                              // click on "O" button
                            $(document).find("div.product-screen div.middlepane span#all_orders").trigger("click");
                            // self.actionpad.gui.show_screen('cp_pos_order');
                            event.preventDefault();
                            return;
                        } else if(event.which == 67) {                              // click on "C" button
                            self.actionpad.gui.show_screen('clientlist');
                            event.preventDefault();
                        } else if(event.which == 32) {                              // click on "spacebar" button
                            self.actionpad.gui.show_screen('payment');
                            event.preventDefault();
                        } else if(event.which == 38) {                              // click on "up arrow" button
                            $(document).find("div.product-screen ul.orderlines li.selected").prev('li.orderline').trigger('click');
                            if($(document).find("div.product-screen ul.orderlines li.selected").length > 0){
                                $(document).find("div.product-screen div.order-scroller").animate({
                                    scrollTop: $(document).find("div.product-screen div.order-scroller").scrollTop() + $(document).find("div.product-screen ul.orderlines li.selected").offset().top - ($(document).find("div.pos-topheader").height() + 10)
                                },100);
                            }
                            event.preventDefault();
                        } else if(event.which == 40) {                              // click on "down arrow" button
                            $(document).find("div.product-screen ul.orderlines li.selected").next('li.orderline').trigger('click');
                            if($(document).find("div.product-screen ul.orderlines li.selected").length > 0) {
                                $(document).find("div.product-screen div.order-scroller").animate({
                                    scrollTop: $(document).find("div.product-screen div.order-scroller").scrollTop() + $(document).find("div.product-screen ul.orderlines li.selected").offset().top - ($(document).find("div.pos-topheader").height() + 10)
                                }, 100);
                            }
                            event.preventDefault();
                        // } else if(event.which == 83) {                              // click on "S" button
                        } else if(event.which == 191) {                              // click on "S" button
                            $(document).find("div.product-screen div.rightpane div.searchbox input").focus();
                            event.preventDefault();
                        }
                    }

                    /* payment screen key down events */
                    if(!$($(document).find("div.payment-screen")[0]).hasClass('oe_hidden')){
                        if (event.which == 27) {                                    // click on "Esc" button
                            $($(document).find("div.payment-screen")[0]).find("div.top-content span.back").trigger('click');
                            event.preventDefault();
                        } else if(event.which == 67) {                              // click on "C" button
                            $($(document).find("div.payment-screen")[0]).find("div.js_set_customer").trigger('click');
                            event.preventDefault();
                        } else if (event.which == 73) {                             // click on "I" button
                            $($(document).find("div.payment-screen")[0]).find("div.payment-buttons div.js_invoice").trigger('click');
                            event.preventDefault();
                        } else if(event.which == 33) {                              // click on "Page Up" button
                            if($($(document).find("div.payment-screen")[0]).find("div.paymentmethods div.highlight").length > 0){
                                var elem = $($(document).find("div.payment-screen")[0]).find("div.paymentmethods div.highlight");
                                elem.removeClass("highlight");
                                elem.prev("div.paymentmethod").addClass("highlight");
                            }else{
                                var payMethodLength = $($(document).find("div.payment-screen")[0]).find("div.paymentmethods div.paymentmethod").length;
                                if(payMethodLength > 0){
                                    $($($(document).find("div.payment-screen")[0]).find("div.paymentmethods div.paymentmethod")[payMethodLength-1]).addClass('highlight');
                                }
                            }
                        } else if(event.which == 34) {                              // click on "Page Down" button
                            if($($(document).find("div.payment-screen")[0]).find("div.paymentmethods div.highlight").length > 0){
                                var elem = $($(document).find("div.payment-screen")[0]).find("div.paymentmethods div.highlight");
                                elem.removeClass("highlight");
                                elem.next("div.paymentmethod").addClass("highlight");
                            }else{
                                var payMethodLength = $($(document).find("div.payment-screen")[0]).find("div.paymentmethods div.paymentmethod").length;
                                if(payMethodLength > 0){
                                    $($($(document).find("div.payment-screen")[0]).find("div.paymentmethods div.paymentmethod")[0]).addClass('highlight');
                                }
                            }
                        } else if(event.which == 13) {                              // click on "Enter" button
                            if($($(document).find("div.payment-screen")[0]).find("div.paymentmethods div.highlight").length > 0){
                                $($(document).find("div.payment-screen")[0]).find("div.paymentmethods div.highlight").trigger("click");
                                $($(document).find("div.payment-screen")[0]).find("div.paymentmethods div.paymentmethod").removeClass("highlight");
                            } else if($($(document).find("div.payment-screen")[0]).find("div.top-content span.next").hasClass('highlight')){
                                $($(document).find("div.payment-screen")[0]).find("div.top-content span.next").trigger("click");
                            }
                            event.preventDefault();
                        } else if(event.which == 38) {                              // click on "Arrow Up" button
                            if($($(document).find("div.payment-screen")[0]).find("table.paymentlines tbody tr.selected").length > 0){
                                $($(document).find("div.payment-screen")[0]).find("table.paymentlines tbody tr.selected").prev("tr.paymentline").trigger("click");
                            }else{
                                var payLineLength = $($(document).find("div.payment-screen")[0]).find("table.paymentlines tbody tr.paymentline").length;
                                if(payLineLength > 0){
                                    $($($(document).find("div.payment-screen")[0]).find("table.paymentlines tbody tr.paymentline")[payLineLength-1]).trigger('click');
                                }
                            }
                            event.preventDefault();
                        } else if(event.which == 40) {                              // click on "Arrow Down" button
                            if($($(document).find("div.payment-screen")[0]).find("table.paymentlines tbody tr.selected").length > 0){
                                var elem = $($(document).find("div.payment-screen")[0]).find("table.paymentlines tbody tr.selected").next("tr.paymentline").trigger("click");
                                elem.removeClass("highlight");
                                elem.next("div.paymentmethod").addClass("highlight");
                            }else{
                                var payLineLength = $($(document).find("div.payment-screen")[0]).find("table.paymentlines tbody tr.paymentline").length;
                                if(payLineLength > 0){
                                    $($($(document).find("div.payment-screen")[0]).find("table.paymentlines tbody tr.paymentline")[0]).trigger('click');
                                }
                            }
                            event.preventDefault();
                        } else if(event.which == 46) {                              // click on "Delete" button
                            $($(document).find("div.payment-screen")[0]).find("table.paymentlines tbody tr.selected td.delete-button").trigger("click");
                            event.preventDefault();
                        }
                    }

                    /* clientlist screen key down events */
                    if(!$($(document).find("div.clientlist-screen")[0]).hasClass('oe_hidden')){
                        if (event.which == 27) {                                    // click on "Esc" button
                            if($($(document).find("div.clientlist-screen")[0]).find("section.client-details").length > 0 && $($(document).find("div.clientlist-screen")[0]).find("section.client-details div.undo").length > 0){
                                $($(document).find("div.clientlist-screen")[0]).find("section.client-details div.undo").trigger("click");
                            }else{
                                $($(document).find("div.clientlist-screen")[0]).find("span.back").trigger('click');
                            }
                            event.preventDefault();
                        // } else if(event.which == 83) {                              // click on "S" button
                        } else if(event.which == 191) {                              // click on "S" button
                            $($(document).find("div.clientlist-screen")[0]).find("span.searchbox input").focus();
                            event.preventDefault();
                        // } else if(event.which == 79) {                              // click on "O" button
                        } else if(event.which == 56) {                              // click on "O" button
                            if($($(document).find("div.clientlist-screen")[0]).find("table.client-list tr.highlight").length > 0){
                                $($(document).find("div.clientlist-screen")[0]).find("table.client-list tr.highlight button.view_all_order").trigger("click");
                            }
                            event.preventDefault();
                            return;
                        // } else if(event.which == 69) {                              // click on "E" button
                        } else if(event.which == 189) {                              // click on "E" button
                            if($($(document).find("div.clientlist-screen")[0]).find("section.client-details").length > 0 && $($(document).find("div.clientlist-screen")[0]).find("section.client-details div.edit").length > 0){
                                $($(document).find("div.clientlist-screen")[0]).find("section.client-details div.edit").trigger("click");
                                $($(document).find("div.clientlist-screen")[0]).find("section.client-details input.client-name").focus();
                            }
                            event.preventDefault();
                        } else if(event.which == 107) {                             // click on "+" button
                            $($(document).find("div.clientlist-screen")[0]).find("section.top-content span.new-customer").click();
                            $($(document).find("div.clientlist-screen")[0]).find("section.client-details input.client-name").focus();
                            event.preventDefault();
                        } else if(event.which == 38) {                              // click on "Arrow Up" button
                            if($(document).find("div.clientlist-screen table.client-list tbody.client-list-contents tr.highlight").length > 0){
                                $(document).find("div.clientlist-screen table.client-list tbody.client-list-contents tr.highlight").prev("tr.client-line").click();
                                event.preventDefault();
                            }else{
                                var clientLineLength = $(document).find("div.clientlist-screen table.client-list tbody.client-list-contents tr.client-line").length;
                                if(clientLineLength > 0){
                                    $($(document).find("div.clientlist-screen table.client-list tbody.client-list-contents tr.client-line")[clientLineLength-1]).click();
                                    event.preventDefault();
                                }
                            }

                            var scrollContainer = $(document).find("div.clientlist-screen table.client-list").parent("div.touch-scrollable");
                            var highlightedTr = $(document).find("div.clientlist-screen table.client-list tbody.client-list-contents tr.highlight");
                            var customerDetailSection = $(document).find("div.clientlist-screen section.client-details").height();
                            scrollContainer.animate({
                                scrollTop: scrollContainer.scrollTop() + highlightedTr.offset().top - (customerDetailSection * 2)
                            }, 100);
                        } else if(event.which == 40) {                              // click on "Arrow Down" button
                            if($(document).find("div.clientlist-screen table.client-list tbody.client-list-contents tr.highlight").length > 0){
                                $(document).find("div.clientlist-screen table.client-list tbody.client-list-contents tr.highlight").next("tr.client-line").click();
                                event.preventDefault();
                            }else{
                                var clientLineLength = $(document).find("div.clientlist-screen table.client-list tbody.client-list-contents tr.client-line").length;
                                if(clientLineLength > 0){
                                    $($(document).find("div.clientlist-screen table.client-list tbody.client-list-contents tr.client-line")[0]).click();
                                    event.preventDefault();
                                }
                            }

                            var scrollContainer = $(document).find("div.clientlist-screen table.client-list").parent("div.touch-scrollable");
                            var highlightedTr = $(document).find("div.clientlist-screen table.client-list tbody.client-list-contents tr.highlight");
                            var customerDetailSection = $(document).find("div.clientlist-screen section.client-details").height();
                            scrollContainer.animate({
                                scrollTop: scrollContainer.scrollTop() + highlightedTr.offset().top - (customerDetailSection * 2)
                            }, 100);
                        } else if(event.which == 13) {                              // click on "Enter" button
                            if($($(document).find("div.clientlist-screen")[0]).find("section.client-details").length > 0 && $($(document).find("div.clientlist-screen")[0]).find("section.client-details div.save").length > 0){
                                $($(document).find("div.clientlist-screen")[0]).find("section.client-details div.save").trigger("click");
                            }
                            else if(!$(document).find("div.clientlist-screen section.top-content span.next").hasClass('oe_hidden')){
                                $(document).find("div.clientlist-screen section.top-content span.next").click();
                            }
                            event.preventDefault();
                        }
                    }

                    /* receipt screen key down events */
                    if(!$($(document).find("div.receipt-screen")[0]).hasClass('oe_hidden')){
                        if(event.which == 73){                                      // click on "I" button
                            $($(document).find("div.receipt-screen")[0]).find("div.print_invoice").trigger("click");
                            event.preventDefault();
                        } else if(event.which == 80){                               // click on "P" button
                            $($(document).find("div.receipt-screen")[0]).find("div.print").trigger("click");
                            event.preventDefault();
                        } else if(event.which == 13){                               // click on "Enter" button
                            $($(document).find("div.receipt-screen")[0]).find("div.top-content span.next").trigger("click");
                            event.preventDefault();
                        }
                    }

                    /* pos order screen key down events */
                    if(!$($(document).find("div.posorders-screen")[0]).hasClass('oe_hidden')){
                        if (event.which == 27) {                                    // click on "Esc" button
                            $($(document).find("div.posorders-screen")[0]).find("section.top-content span.back").trigger('click');
                            event.preventDefault();
                        // } else if(event.which == 83) {                              // click on "S" button
                        } else if(event.which == 191) {                              // click on "S" button
                            $(document).find("div.posorders-screen span.searchbox input").focus();
                            event.preventDefault();
                        } else if(event.which == 38) {                              // click on "Arrow Up" button
                            // unfocus search input if focused
                            if($(document).find("div.posorders-screen span.searchbox input").is(':focus')){
                                $(document).find("div.posorders-screen span.searchbox input").blur();
                            }
                            // select order row one after one up on arrow up button press
                            if($(document).find("div.posorders-screen table.cp_pos_order_list tbody.cp-order-list-contents tr.highlight").length > 0){
                                $(document).find("div.posorders-screen table.cp_pos_order_list tbody.cp-order-list-contents tr.highlight").removeClass('highlight').prev("tr.cp-order-line").addClass('highlight');
                                event.preventDefault();
                            }else{
                                var orderLineLength = $(document).find("div.posorders-screen table.cp_pos_order_list tbody.cp-order-list-contents tr.cp-order-line").length;
                                if(orderLineLength > 0){
                                    $($(document).find("div.posorders-screen table.cp_pos_order_list tbody.cp-order-list-contents tr.cp-order-line")[orderLineLength-1]).addClass('highlight');
                                    event.preventDefault();
                                }
                            }

                            var scrollContainer = $(document).find("div.posorders-screen table.cp_pos_order_list").parent("div.touch-scrollable");
                            var highlightedTr = $(document).find("div.posorders-screen table.cp_pos_order_list tbody.cp-order-list-contents tr.highlight");
                            var posorderTopSection = $(document).find("div.posorders-screen section.top-content").height();
                            if (highlightedTr.length > 0){
                                scrollContainer.animate({
                                    scrollTop: scrollContainer.scrollTop() + highlightedTr.offset().top - (posorderTopSection + 52)
                                }, 100);
                            }
                        } else if(event.which == 40) {                              // click on "Arrow Down" button
                            // unfocus search input if focused
                            if($(document).find("div.posorders-screen span.searchbox input").is(':focus')){
                                $(document).find("div.posorders-screen span.searchbox input").blur();
                            }
                            // select order row one after one down on arrow down button press
                            if($(document).find("div.posorders-screen table.cp_pos_order_list tbody.cp-order-list-contents tr.highlight").length > 0){
                                $(document).find("div.posorders-screen table.cp_pos_order_list tbody.cp-order-list-contents tr.highlight").removeClass('highlight').next("tr.cp-order-line").addClass('highlight');
                                event.preventDefault();
                            }else{
                                var orderLineLength = $(document).find("div.posorders-screen table.cp_pos_order_list tbody.cp-order-list-contents tr.cp-order-line").length;
                                if(orderLineLength > 0){
                                    $($(document).find("div.posorders-screen table.cp_pos_order_list tbody.cp-order-list-contents tr.cp-order-line")[0]).addClass('highlight');
                                    event.preventDefault();
                                }
                            }

                            var scrollContainer = $(document).find("div.posorders-screen table.cp_pos_order_list").parent("div.touch-scrollable");
                            var highlightedTr = $(document).find("div.posorders-screen table.cp_pos_order_list tbody.cp-order-list-contents tr.highlight");
                            var posorderTopSection = $(document).find("div.posorders-screen section.top-content").height();
                            if (highlightedTr.length > 0) {
                                scrollContainer.animate({
                                    scrollTop: scrollContainer.scrollTop() + highlightedTr.offset().top - (posorderTopSection + 52)
                                }, 100);
                            }
                        } else if(event.which == 13){                               // click on "Enter" button
                            if($($(document).find("div.posorders-screen")[0]).find("table.cp_pos_order_list tbody.cp-order-list-contents tr.highlight").length > 0) {
                                $($(document).find("div.posorders-screen")[0]).find("table.cp_pos_order_list tbody.cp-order-list-contents tr.highlight button.cp_print_content").trigger("click");
                            }
                        }
                    }

                    /* receipt reprint screen key down events */
                    if(!$($(document).find("div.receipt-reprint-screen")[0]).hasClass('oe_hidden')){
                        if (event.which == 27) {                    // click on "Esc" button
                            $($(document).find("div.receipt-reprint-screen")[0]).find("div.top-content span.cp_reprint_back").trigger('click');
                            event.preventDefault();
                        } else if(event.which == 80){               // click on "P" button
                            $($(document).find("div.receipt-reprint-screen")[0]).find("div.print").trigger("click");
                            event.preventDefault();
                        }
                    }
                }
                else {
                    if(event.which == 13){
                        if(event.ctrlKey){
                            var textarea_elem = $($($(document).find("div.modal-dialog").not('.oe_hidden')[0]).find("textarea:focus"));
                            textarea_elem.val(textarea_elem.val() + "\n");
                        }else{
                            if ($($(document).find("div.modal-dialog").not('.oe_hidden')[0]).find(".footer .confirm").length > 0){
                                $($(document).find("div.modal-dialog").not('.oe_hidden')[0]).find(".footer .confirm").trigger("click");
                                event.preventDefault();
                            } else if ($($(document).find("div.modal-dialog").not('.oe_hidden')[0]).find(".footer .cancel").length > 0){
                                $($(document).find("div.modal-dialog").not('.oe_hidden')[0]).find(".footer .cancel").trigger("click");
                                event.preventDefault();
                            }
                        }
                    } else if (event.which == 27) {
                        $($(document).find("div.modal-dialog").not('.oe_hidden')[0]).find(".footer .cancel").trigger("click");
                        event.preventDefault();
                    }
                }

            };
            $(document).find("body").on('keydown', this.product_screen_keydown_event_handler);
        },
        show: function () {
            this._super();
            var self = this;
            $("#shortcut_tips_btn").on("click", function (event) {
                self.gui.show_popup("shortcuttips");
            });
        }
    });


    // return {
    //     'ShortcutTipsWidget': ShortcutTipsWidget
    // };
});