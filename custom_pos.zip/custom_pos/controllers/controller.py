import json

from odoo import http
from odoo.http import request


class PosController(http.Controller):
    @http.route('/pos/products', type='json', auth='user')
    def pos_products(self, product_id):
        product = request.env['product.product'].browse(int(product_id))
        return json.dumps({"qty_available": int(product.qty_available)})
