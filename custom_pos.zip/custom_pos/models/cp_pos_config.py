# -*- coding: utf-8 -*-
from odoo import api, models, fields, _
from odoo.exceptions import ValidationError


class PosConfig(models.Model):
    _inherit = 'pos.config'

    order_loading_options = fields.Selection([("current_session","Load Orders Of Current Session"), ("all_orders","Load All Past Orders"), ("n_days","Load Orders Of Last 'n' Days")], default='current_session', string="Loading Options")
    number_of_days = fields.Integer(string='Number Of Past Days',default=10)
    cp_reprint_type = fields.Selection([('posbox', 'POSBOX(Xml Report)'),
                                        ('ticket', 'Pos Ticket (Order Receipt)'),
                                        ('pdf','Browser Based (Pdf Report)')
                                        ], default='ticket', required=True, string='Order Reprint Type')
    loyalty_id = fields.Many2one('loyalty.program', string='Pos Loyalty Program', help='The loyalty program used by this point of sale.')

    @api.constrains('number_of_days')
    def number_of_days_validation(self):
        if self.order_loading_options == 'n_days':
            if not self.number_of_days or self.number_of_days < 0:
                raise ValidationError("Please provide a valid value for the field 'Number Of Past Days'!!!")

    @api.one
    @api.constrains('cp_reprint_type','iface_print_via_proxy')
    def check_cp_reprint_type(self):
        if (self.cp_reprint_type == 'posbox'):
            if(self.iface_print_via_proxy == False):
                raise ValidationError("You can not print Xml Report unless you configure the Receipt Printer settings under Hardware Proxy/PosBox!!!")

    # @api.onchange('module_pos_loyalty')
    # def _onchange_module_pos_loyalty(self):
    #     if self.module_pos_loyalty:
    #         self.loyalty_id = self.env['loyalty.program'].search([], limit=1)
    #     else:
    #         self.loyalty_id = False
