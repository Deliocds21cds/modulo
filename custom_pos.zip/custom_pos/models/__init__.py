# -*- coding: utf-8 -*-
from . import cp_res_partner
from . import cp_pos_config
from . import cp_pos_loyalty
from . import cp_pos_order
from . import cp_pos_order_line
