# -*- coding: utf-8 -*-
from odoo import api, fields, models
from odoo.exceptions import Warning,ValidationError
import logging
_logger = logging.getLogger(__name__)


class PosOrder(models.Model):
    _inherit = 'pos.order'

    loyalty_points = fields.Float(default=0, help='The amount of Loyalty points the customer won or lost with this order')

    @api.model
    def _order_fields(self, ui_order):
        fields = super(PosOrder, self)._order_fields(ui_order)
        fields['note'] = ui_order.get('note')
        fields['loyalty_points'] = ui_order.get('loyalty_points', 0)
        return fields

    @api.model
    def create_from_ui(self,orders):
        order_ids = return_data = super(PosOrder, self).create_from_ui(orders)

        if type(order_ids) == dict:
            order_objs = self.env['pos.order'].sudo().browse(order_ids.get('order_ids'))
            result = return_data or {}
        else:
            order_objs = self.env['pos.order'].sudo().browse(order_ids)
            result = {}
        order_list = []
        order_line_list = []
        statement_list = []

        for order_obj in order_objs:
            vals = {}
            vals['lines'] = []
            if hasattr(order_objs[0], 'return_status'):
                if not order_obj.is_return_order:
                    vals['return_status'] = order_obj.return_status
                    vals['existing'] = False
                    vals['id'] = order_obj.id
                else:
                    order_obj.return_order_id.return_status = order_obj.return_status
                    vals['existing'] = True
                    vals['id'] = order_obj.id
                    vals['original_order_id'] = order_obj.return_order_id.id
                    vals['return_status'] = order_obj.return_order_id.return_status
                    for line in order_obj.lines:
                        line_vals = {}
                        if line.original_line_id:
                            line_vals['id'] = line.original_line_id.id
                            line_vals['line_qty_returned'] = line.original_line_id.line_qty_returned
                            line_vals['existing'] = True
                        order_line_list.append(line_vals)
            vals['statement_ids'] = order_obj.statement_ids.ids
            vals['name'] = order_obj.name
            vals['amount_total'] = order_obj.amount_total
            vals['pos_reference'] = order_obj.pos_reference
            vals['date_order'] = order_obj.date_order

            if order_obj.invoice_id:
                vals['invoice_id'] = order_obj.invoice_id.id
            else:
                vals['invoice_id'] = False
            if order_obj.partner_id:
                vals['partner_id'] = [order_obj.partner_id.id, order_obj.partner_id.name]
                if order_obj.loyalty_points != 0:
                    order_obj.partner_id.loyalty_points += order_obj.loyalty_points
                    vals['loyalty_points'] = order_obj.loyalty_points
            else:
                vals['partner_id'] = False

            if (not hasattr(order_objs[0], 'return_status') or (hasattr(order_objs[0], 'return_status') and not order_obj.is_return_order)):
                vals['id'] = order_obj.id
                for line in order_obj.lines:
                    vals['lines'].append(line.id)
                    line_vals = {}
                    # LINE DATAA
                    line_vals['create_date'] = line.create_date
                    line_vals['discount'] = line.discount
                    line_vals['display_name'] = line.display_name
                    line_vals['id'] = line.id
                    line_vals['order_id'] = [line.order_id.id, line.order_id.name]
                    line_vals['price_subtotal'] = line.price_subtotal
                    line_vals['price_subtotal_incl'] = line.price_subtotal_incl
                    line_vals['price_unit'] = line.price_unit
                    line_vals['product_id'] = [line.product_id.id, line.product_id.name]
                    line_vals['qty'] = line.qty
                    line_vals['write_date'] = line.write_date
                    if hasattr(line, 'line_qty_returned'):
                        line_vals['line_qty_returned'] = line.line_qty_returned
                    # LINE DATAA
                    order_line_list.append(line_vals)
                for statement_id in order_obj.statement_ids:
                    statement_vals = {}
                    # STATEMENT DATAA
                    statement_vals['amount'] = statement_id.amount
                    statement_vals['id'] = statement_id.id
                    if statement_id.journal_id:
                        currency = statement_id.journal_id.currency_id or statement_id.journal_id.company_id.currency_id
                        statement_vals['journal_id'] = [statement_id.journal_id.id, statement_id.journal_id.name + " (" +currency.name+")"]
                    else:
                        statement_vals['journal_id'] = False
                    statement_list.append(statement_vals)
            order_list.append(vals)

        result['orders'] = order_list
        result['orderlines'] = order_line_list
        result['statements'] = statement_list
        if type(order_ids) == dict:
            result['order_ids'] = order_ids.get('order_ids')
        else:
            result['order_ids'] = order_ids

        return result

    @api.model
    def get_report_data(self, kwargs):
        order = self.browse(kwargs['order_id'])
        account_tax_obj = self.env['account.tax']
        orderlines, paymentlines, tax_details = [], [], []
        change = amount_untaxed = total_discount = 0.0
        if order.lines:
            val2 = 0.0
            selected_tax = []
            cur = order.pricelist_id.currency_id
            for line in order.lines:
                line
                val2 += line.price_subtotal
                order_line = {
                    'discount': line.discount,
                    'price': line.price_unit,
                    'price_display': line.price_subtotal,
                    'price_with_tax': line.price_subtotal_incl,
                    'price_without_tax': line.price_subtotal,
                    'product_name': line.product_id.name,
                    'quantity': line.qty,
                    'tax': self._amount_line_tax(line, order.fiscal_position_id),
                    'unit_name': line.product_id.uom_id.name,
                    'note': line.note,
                }
                if line.tax_ids:
                    for tax in line.tax_ids:
                        if tax.id not in selected_tax:
                            amount = 0.0
                            selected_tax.append(tax.id)
                            for l in order.lines:
                                if l.tax_ids:
                                    temp_ids = [x.id for x in l.tax_ids]
                                    if tax.id in temp_ids:
                                        price = l.price_unit * (1 - (l.discount or 0.0) / 100.0)

                                        temp = account_tax_obj.browse([tax.id]).compute_all(price, cur, l.qty,
                                                                                            product=l.product_id,
                                                                                            partner=l.order_id.partner_id or False)

                                        amount += float(temp['total_included'] - temp['total_excluded'])
                            tax_details.append({'name': tax.name, 'amount': amount})
                if line.discount > 0.0:
                    total_discount += float(line.discount * line.price_unit) / 100.0
                orderlines.append(order_line)
            amount_untaxed = val2
        if order.statement_ids:
            for stmt in order.statement_ids:
                if stmt.amount >= 0.0:
                    currency = stmt.journal_id.currency_id or stmt.journal_id.company_id.currency_id
                    name = "%s (%s)" % (stmt.journal_id.name, currency.name)
                    payment_line = {
                        'amount': stmt.amount,
                        'name': name
                    }
                    paymentlines.append(payment_line)
                else:
                    change = stmt.amount
        return {
            'paymentlines': paymentlines,
            'receipt': {
                'cashier': order.user_id.name,
                'change': change,
                'client': order.partner_id and order.partner_id.name or False,
                'client_phone': order.partner_id and order.partner_id.phone or False,
                'client_loyalty_points': order.partner_id and order.partner_id.loyalty_points or False,
                'date': order.date_order,
                'orderlines': orderlines,
                'paymentlines': paymentlines,
                'subtotal': amount_untaxed,
                'tax_details': tax_details,
                'total_discount': total_discount,
                'total_tax': order.amount_tax,
                'total_with_tax': order.amount_total,
                'pos_ref': order.pos_reference,
                'note': order.note,
            },
            'taxincluded': False,
        }

    @api.model
    def order_formatLang(self, value, currency_obj=False):
        res = value
        if currency_obj and currency_obj.symbol:
            if currency_obj.position == 'after':
                res = u'%s\N{NO-BREAK SPACE}%s' % (res, currency_obj.symbol)
            elif currency_obj and currency_obj.position == 'before':
                res = u'%s\N{NO-BREAK SPACE}%s' % (currency_obj.symbol, res)
        return res
