from odoo import models, fields
from odoo.models import Model


class PosOrderLine(models.Model):
    _inherit = 'pos.order.line'

    note = fields.Text(string='Order line note')