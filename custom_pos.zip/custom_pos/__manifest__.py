# -*- coding: utf-8 -*-
{
    'name': "Custom POS",
    'summary': """
        Customized layout, keyboard shortcuts, product/product variant quantity, order/order line note and many more features for desktop point of sale users
    """,
    'description': """
        Customized layout, keyboard shortcuts, product/product variant quantity, order/order line note and many more features for desktop point of sale users
    """,
    'author': "Abdullah Al Arafat Bipul",
    'website': "http://www.scorpion9.com",
    'license': "LGPL-3",
    'support': "imbipul9@gmail.com",
    'category': 'Point of Sale',
    'version': '0.1',
    'depends': ['point_of_sale'],
    'data': [
        'views/pos_config.xml',
        'views/assets.xml',
        'reports/order_report.xml',
        'reports/order_reprint_paperrformat.xml',
        'reports/report_file.xml',
        'security/ir.model.access.csv',
        'views/cp_pl_pos_loyalty_views.xml',
        'views/cp_pl_pos_config_views.xml',
    ],
    'qweb': [
        'static/src/xml/pos.xml',
        'static/src/xml/pos_orders.xml',
        'static/src/xml/pos_order_reprint.xml',
        'static/src/xml/loyalty.xml',
    ],
    'images': ['static/description/thumbnail.png'],
    "application": True,
    'installable': True,
    'auto_install': False,
    "price": 18,
    "currency": "EUR",
}
