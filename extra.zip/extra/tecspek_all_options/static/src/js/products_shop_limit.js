odoo.define('tecspek_all_options.products_shop_limit', function (require) {
    "use strict";

    var website = require('website.website');
    var ajax = require('web.ajax');

    $(function(){
        var previous_limit = localStorage['active_product_limit'];
        if (previous_limit) {
            for (var i = 0; i < $('.limit_link').length; i++) {
                if (previous_limit == $('.limit_link')[i].getAttribute('value')) {
                     $('.limit_link')[i].classList.add('active');
                }
            }
            $('.limit_link.active').parent().addClass('active')
        }
        $('.limit_link').click(function(type){
            if(type['type'] !== "click") return;
            ajax.jsonRpc('/shop/product_limit', 'call', {'value': $(this)[0].getAttribute('value')});
            location.reload();
            $(this).parent().siblings().removeClass('active');
            $(this).parent().addClass('active');
            localStorage['active_product_limit'] = $(this)[0].getAttribute('value');
        });
    });

});
