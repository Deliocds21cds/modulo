$(document).ready(function() {
    var view_mode = ''

    $('div.oe_website_sale').each(function() {
        if ($('.scrolling').length) {
            $('div.oe_website_sale').append('<p class="page d-none">1</p>');
            $('#products_grid').after("<div id='loading' class='mt32 text-center col-md-12 d-none'><img src='/tecspek_all_options/static/src/img/loading.gif' alt='Loading...' style='width:100px;'/><p>Loading more Products...</p></div>");
        }else{
            $('.without-scrolling').removeClass('d-none');
            $('.without-scrolling').show();
        }

        if ($('.scrolling').length) {
            var checkNextPage = 0;
            var tmp_array = new Array();
            if($('.products_pager ul.pagination').length){
                var total_pages = parseInt($('.products_pager ul.pagination').find('li').eq(-2)[0].innerText, 10);
                if (isNaN(total_pages)) total_pages = 0;
            }
            var url = window.location.href; // Returns full URL
            url = url.replace(new RegExp('#'), '');
            var a = url.indexOf("?");
            var b =  url.substring(a);
            var c = url.replace(b,"");
            if(a !== -1){
                url = c;
            }
            if ($('.grid-view-items').length) {
                view_mode = 'grid'
            } else {
                view_mode = 'list'
            }
            if($('.products_pager ul.pagination').length){
                $(window).scroll(function() {
                    if ($('.scrolling').length && $(window).scrollTop() > $('.product-list').children().children().last().offset().top - 120) {
                        if ($(window).scrollTop() >= $('.product-list').offset().top + $('.product-list').outerHeight() - window.innerHeight) {
                            var page = parseInt($('.page')[0].innerText, 10) + 1
                            if (page <= total_pages && tmp_array.indexOf(page) == -1) {
                                $('#loading').removeClass('d-none');
                                getProductList(page, url, total_pages);
                                tmp_array.push(page);
                            }

                        }
                    }
                });
            }
        }
    });
    function getProductList(page, url, total_pages) {
        $.ajax({
            url: url + '/page/' + page + '?' + window.location.search.substring(1),
            type: "GET",
            data: {},
            beforeSend: function() {
                $('#loading').show();
            },
            complete: function() {
                $('#loading').addClass('d-none');
            },
            success: function(data) {
                $('.page')[0].innerText = page;

                var div = document.createElement('div');
                div.innerHTML = data;
                if (view_mode == 'list') {
                    $('.oe_product').last().after($(div).find('.oe_product'));
                } else if (view_mode == 'grid') {
                    var rows = $(div).find('.product-list').children().children()
                    $('.product-list').children().children().last().after(rows);
                }
                if (page == total_pages) {
                    $('div.oe_website_sale').find('.showmore').addClass('d-none');
                }
            },
            error: function() {}
        });
    }
    $(function() {
        $('nav#menu').mmenu({
        navbar: {
            title: "Category",
        },
        });
    });
});
