from odoo import api, fields, models


class WebsiteProductLimit(models.Model):
    _name = 'product.view.limit'
    _order = 'sequence'
    _description = 'Product Limits'

    sequence = fields.Integer(help="Gives the sequence order when "
                                   "displaying a list of rules.")
    name = fields.Integer(string='Limit', required=True)

    _sql_constraints = [('name', 'unique(name)', 'This must be unique!')]
