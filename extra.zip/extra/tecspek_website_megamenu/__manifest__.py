{
    'name': 'Fully Configurable Website Mega Menu',
    'category': 'Website',
    'description': 'Fully Advance Mega Menu for Website',
    'version': '12.0.1.0.2',
    'summary': '''Fully Advance Mega Menu for Website'''
               ''' with Modern style, Extremely customizable,'''
               ''' Clean and Fully Responsive.''',

    'author': 'Tecspek',
    'depends': [
        'website_sale'
    ],
    'data': [
        'views/assets.xml',
        'views/website_view.xml',
        'views/mega_menu_template.xml',
    ],
    'images': [
        'static/description/image823.png'
    ],
    'support': 'help.tecspek@gmail.com',
    'installable': True,
    'application': True,
    'auto_install': False,
    'price': 49,
    'currency': 'EUR',
    'license': 'OPL-1',
}
