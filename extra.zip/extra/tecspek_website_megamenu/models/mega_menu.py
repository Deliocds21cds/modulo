from odoo import api, fields, models
from odoo.tools.translate import html_translate


class WebsiteMegaMenu(models.Model):

    _inherit = "website.menu"

    is_website_mega_menu = fields.Boolean(string='Is Mega Menu ?', translate=True)
    number_of_columns = fields.Selection([('6', '2 Columns'),
                                          ('4', '3 Columns'),
                                          ('3', '4 Columns')],
                                         default='6',
                                         string=" Number of Columns", translate=True)

    mega_menu_size = fields.Selection([('small', 'Small'), ('medium', 'Medium'),
                                  ('full', 'Large')], string="Menu Size",
                                 default='medium', translate=True)
    menu_inside_content_type = fields.Selection([('product_grid', 'Product Grid'),
                                                 ('product_list', 'Product List'),
                                                 ('category_grid', 'Category Grid'),
                                                 ('category_list', 'Category List'),
                                                 ('content', 'Content')], translate=True)

    product_ids = fields.Many2many("product.template", string="Products", domain=[('website_published', '=', True)])
    category_ids = fields.Many2many("product.public.category", string="Category",
                                    domain=['|', ('parent_id', '=', False), ('parent_id.parent_id', '=', False)])
    category_slider = fields.Boolean(string='Want to Display Slider', default=False, translate=True)
    category_slider_name = fields.Char(string="Slider Label",
                                       default="Popular categories",
                                       help="Show Name inside mega menu", translate=True)

    category_slider_position = fields.Selection([('left', 'Left'), ('right', 'Right')],
                                                default='right', string="Slider Position", translate=True)

    child_view_menu = fields.Html(string='SubMenu View', translate=html_translate, sanitize_attributes=False)

    @api.multi
    def btn_sub_menu_template(self):
        self.ensure_one()
        url = '/tecspek_mega_menu/snippet_drop/%d' % self.id
        return {
            'type': 'ir.actions.act_url',
            'target': 'self',
            'url': url,
        }