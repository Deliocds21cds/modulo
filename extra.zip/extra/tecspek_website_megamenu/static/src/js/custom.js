$(document).on('click', '.mega-dropdown-menu', function(e) {
    e.stopPropagation()
})
