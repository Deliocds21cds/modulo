from odoo import http
from odoo.http import request


class TecspekWebsiteMegaMenu(http.Controller):

    @http.route(["/tecspek_mega_menu/snippet_drop/<model('website.menu'):dropdown_menu>"],
                type='http', auth="user", website=True)
    def mega_menu_template_view(self, dropdown_menu, **post):
        mega_menu_values = {'template': dropdown_menu}
        return request.render('tecspek_website_megamenu.sub_menu_template', mega_menu_values)