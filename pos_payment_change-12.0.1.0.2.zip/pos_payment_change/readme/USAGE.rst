* Go to a PoS Order

* Click on the button 'Change Payments'

.. figure:: ../static/description/pos_order_form.png

* In the pop up wizard, select the real payment(s) that have been
  used to pay the order

.. figure:: ../static/description/pos_payment_change_wizard_form.png

* Then click on the button 'Change Payments'

**Note**

If the option 'Refund and Resale' is selected, changing the payments will
display the three PoS orders. the oringal one, the refund one, and the new one.

.. figure:: ../static/description/pos_order_tree.png
