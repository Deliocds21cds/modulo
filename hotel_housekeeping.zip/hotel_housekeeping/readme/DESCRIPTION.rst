Module for Housekeeping is the department that deals essentially with cleanliness and all ancillary service attached to that.
Housekeepers are maintaining and servicing the guest rooms and replenishing stock as and when needed.

You can manage:

**Housekeeping Activities**

**Complete Housekeeping Process**

    In Dirty Stage Housekeeping Process
    .. image:: https://raw.githubusercontent.com/OCA/vertical-hotel/11.0/hotel_housekeeping/static/description/HHK1.png
    :width: 750px

    In Clean Stage Housekeeping Process
    .. image:: https://raw.githubusercontent.com/OCA/vertical-hotel/11.0/hotel_housekeeping/static/description/HHK2.png
    :width: 750px

    In Inspect Stage Housekeeping Process
    .. image:: https://raw.githubusercontent.com/OCA/vertical-hotel/11.0/hotel_housekeeping/static/description/HHK3.png
    :width: 750px

    In Done Stage Housekeeping Process
    .. image:: https://raw.githubusercontent.com/OCA/vertical-hotel/11.0/hotel_housekeeping/static/description/HHK4.png
    :width: 750px

**Historised Housekeeping with Inventory and Service Data**
