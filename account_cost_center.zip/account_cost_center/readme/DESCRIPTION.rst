This module allows the user to link every invoice line to a cost center
providing an extra dimension for the analysis.
