Expiry Date Warning 
=========================

Generates warning for expired products, while selling the product.


Installation
============
- www.odoo.com/documentation/12.0/setup/install.html
- Install our custom addons

License
=======

GNU LESSER GENERAL PUBLIC LICENSE, Version 3  (LGPL v3) 

Bug Tracker
===========
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Credits
=======
* Cybrosys Techno Solutions <https://www.cybrosys.com>

Author
------

Developer: 10.0  Avinash Nk (odoo@cybrosys.com)
           12.0  Kavya Raveendran (odoo@cybrosys.com)

Maintainer
----------

This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com.

