You just need to create date ranges associated to 'Fiscal Year' type.
