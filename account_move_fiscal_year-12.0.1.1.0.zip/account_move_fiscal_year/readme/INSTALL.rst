You need to install account_fiscal_year.
