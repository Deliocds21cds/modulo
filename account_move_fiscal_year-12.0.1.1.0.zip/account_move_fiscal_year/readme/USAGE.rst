Go to Invoicing -> Configuration -> Date Ranges -> Fiscal Years to create a new
Fiscal Year.
