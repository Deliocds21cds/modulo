* Damien Crier <damien.crier@camptocamp.com>
* Laurent Mignon <laurent.mignon@acsone.eu>
* Lorenzo Battistini <https://github.com/eLBati>
