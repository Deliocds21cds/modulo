This module just adds the menu

Invoicing > Configuration > Accounting > Fiscal Years

This is totally refactored compared to 11 version, because odoo 12 introduced `account.fiscal.year` object.
See https://github.com/OCA/account-financial-tools/pull/706
