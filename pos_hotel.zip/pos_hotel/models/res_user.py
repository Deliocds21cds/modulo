# -*- coding: utf-8 -*-

from odoo import api, fields, models


class POSInherit(models.Model):
    _inherit = 'res.users'

    code = fields.Char(string='Codigo de Vendedor')
    