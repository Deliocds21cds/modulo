# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
class TransferModel(models.Model):
    _name = 'transfer.model'

    date = fields.Date(string='Fecha')
    count = fields.Integer(string='Numero de transferencias')
    
    



    
    