from odoo import models, fields, api
import logging
_logger = logging.getLogger(__name__)
class PosOrderLineInherit(models.Model):
    _inherit = 'pos.order.line'

    date_start = fields.Char("Date start")
    date_stop = fields.Char("Date end")


    @api.model
    def save_times(self, obj):
        _logger.info('====>%s',obj )
        p_order_line=self.env['pos.order.line'].search([('id','=',obj['obj']['id'])])
        _logger.info('====>%s',p_order_line )
        p_order_line.sudo().write({
            "date_start":obj['obj']['start'],
            "date_stop":obj['obj']['stop'],
        })
        return obj