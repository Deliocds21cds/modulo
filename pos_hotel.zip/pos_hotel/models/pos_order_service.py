from odoo import models, fields, api
class PosOrderLineInherit(models.Model):
    _inherit = 'pos.order.line'

    date_start = fields.Char("Date start")
    date_stop = fields.Char("Date end")