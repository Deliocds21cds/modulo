# -*- coding: utf-8 -*-
from odoo import models, fields, api

class CustomSession(models.Model):
    _name = 'custom.sessions'

    cajero             = fields.Char(string='Cajero')
    fecha              = fields.Char(string='Fecha')
    time_inicio        = fields.Char(string='Hora de inicio')
    time_cierre        = fields.Char(string='Hora de cierre')
    total_vendido      = fields.Integer(string='Total vendido')
    estado             = fields.Char(string='Estado')
    c_session_line_ids = fields.One2many('custom.sessions.line','c_session_id',string='Custom Session Line')
    
    
class CustomSessionLine(models.Model):
    _name = 'custom.sessions.line'

    c_session_id = fields.Many2one('custom.sessions',string='Custom Session')
    product      = fields.Char(string='Cajero')
    price_unit   = fields.Char(string='Fecha')
    qty          = fields.Char(string='Hora de inicio')
    dcto         = fields.Char(string='Hora de cierre')
    dcto_reason  = fields.Integer(string='Total vendido')

    
