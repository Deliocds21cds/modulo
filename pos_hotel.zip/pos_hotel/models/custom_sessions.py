# -*- coding: utf-8 -*-
from odoo import models, fields, api
from datetime import datetime
import logging
_logger = logging.getLogger(__name__)


class CustomSession(models.Model):
    _name = 'custom.sessions'

    name = fields.Char(string='Sesión')
    cajero = fields.Many2one(comodel_name='res.users', string='Cajero')
    fecha = fields.Date(string='Fecha')
    time_inicio = fields.Date(string='Hora de inicio')
    time_cierre = fields.Date(string='Hora de cierre')
    total_vendido = fields.Float(string='Total vendido')
    estado = fields.Char(string='Estado')
    c_session_order = fields.One2many(
        'custom.sessions.order', 'c_session_id', string='Custom Session Order')
    session_real = fields.Char(string='Referencia Real')
    @api.model
    def get_company(self):
        return self.env['res.company']._company_default_get('custom.sessions')

    @api.model
    def get_cashier(self):
        return self.cajero

    @api.model
    def get_invoices(self):
        return self.c_session_order
    @api.model
    def get_products(self):
        return self.env['product.product'].search([])        
    @api.model
    def get_stock(self):
        return self.env['stock.move'].search([])

    @api.model
    def get_total_servicios(self):
        lineas = self.env['custom.sessions.order.line'].search([])
        total = 0
        for item in lineas:
            if item.product.product_tmpl_id.type == 'service':
                total+= item*price_unit * item.qty
        return total
    @api.model
    def get_productos_vendidos(self):
        lineas = self.env['custom.sessions.order.line'].search([])
        total = 0
        productos = []
        arreglo=[]

        for item in lineas:
            if item.product.product_tmpl_id.name not in productos:
                productos.append(item.product.product_tmpl_id.name)
        for producto in productos:
            acumulado=0
            for item in lineas:
                if item.product.product_tmpl_id.name == producto:
                    acumulado= acumulado + item.qty
            arreglo.append({
                'producto': producto,
                'cantidad': acumulado
            })
        _logger.info('====%s',productos)

        return arreglo        

class CustomSessionOrder(models.Model):
    _name = 'custom.sessions.order'

    c_session_id = fields.Many2one('custom.sessions', string='Custom Session')
    referencia = fields.Char(string='Referencia')
    fecha = fields.Date(string='Fecha')
    habitacion = fields.Char(string='Habitación')
    cliente = fields.Many2one(comodel_name='res.partner', string='Cliente')
    total = fields.Float(string='Total')
    hora_inicio = fields.Date('Hora Inicio')
    hora_final = fields.Date('Hora Final')
    tiempo_total = fields.Char(string='Tiempo Total')
    c_order_line_ids = fields.One2many(
        'custom.sessions.order.line', 'c_order_id', string='Custom Session Line')


class CustomSessionOrderLine(models.Model):
    _name = 'custom.sessions.order.line'

    c_order_id = fields.Many2one(
        'custom.sessions.order', string='Custom Session')
    product = fields.Many2one(comodel_name='product.product', string='Cajero')
    price_unit = fields.Float(string='Precio Unitario')
    qty = fields.Integer(string='tiempo acumulado ')
    dcto = fields.Float(string='Descuento')
    dcto_reason = fields.Char(string='Razon del descuento')


# open_session_cb

class PosConfigInherit(models.Model):
    _inherit = 'pos.config'
    current_user = fields.Many2one(
        'res.users', 'Current User', default=lambda self: self.env.user)

    def open_session_cb(self):
        self.ensure_one()
        if not self.current_session_id:
            session_id=self.current_session_id = self.env['pos.session'].create({
                'user_id': self.env.uid,
                'config_id': self.id
            })
            if self.current_session_id.state == 'opened':
              
                self.env['custom.sessions'].sudo().create({
                    "cajero": self.current_user.id,
                    "fecha": datetime.today(),
                    "time_inicio": datetime.today(),
                    "time_cierre": False,
                    "total_vendido": 0,
                    "estado": "online",
                    "c_session_line_ids": [],
                    "session_real": session_id.name,
                })
                return self.open_ui()
        return self._open_session(self.current_session_id.id)

    @api.multi
    def print_report(self):
        return self.env['pos.session'].get_action(self, 'pos_hotel.products_report_pdf_template')

    @api.model
    def crear_custom_session(self, session):
        _logger.info('SESSION %s', session['session'])
        self.env['custom.sessions'].sudo().create(session['session'])
        return 'NUEVA SESSION'

    @api.model
    def cierra_custom_session(self, session):
        _logger.info('CIERRA SESION %s', session['session'])
        sesion_activa = self.env['custom.sessions'].search(
            [('id', '=', session['session']['id'])])
        sesion_activa.write({'estado': 'offline'})
      #  self.env.ref('pos_hotel.report_invoicebySession').render_qweb_pdf(self)
     #   self.env.ref('pos_hotel.products_report_pdf_template').report_action(self)
    #    self.env.ref('pos_hotel.products_report_pdf_template').report_action(self, data=data, config=False)
  #      self.env.ref('pos_hotel.pos_z_report_pdf_custom').report_action(self, data={'name:POS'})
        return sesion_activa

    @api.model
    def crea_custom_orden(self, orden):
        _logger.info('Orden %s', orden)
        ret = self.env['custom.sessions.order'].sudo().create({
            "c_session_id": orden["c_session_id"],
            "referencia": orden["referencia"],
            "fecha": orden["fecha"],
            "habitacion": orden["habitacion"],
            "cliente": orden["cliente"],
            "total": orden["total"],
            "c_order_line_ids": [],
            "hora_inicio":orden["hora_inicio"],
            "hora_final":orden["hora_final"], 
            "tiempo_total": orden["tiempo_total"]
        })
        
        orderx = self.env['pos.order'].search([('session_id', '=', orden["session_id"]), ('table_id', '=', orden["table_id"])], order="id desc" , limit=1)
        _logger.info('================================================================ %s', ret)
        ordenID = ret.id
        orderlines = self.env['pos.order.line'].search([('order_id','=', orderx.id)])
        for item in orderlines:
            obj4={
                'c_order_id ': ordenID,
                'product': item.product_id.id,
                'price_unit':item.price_unit,
                'qty': item.qty,
                'dcto':item.discount,
                'dcto_reason':'',
            }
            _logger.info('================================================================ %s', obj4)
            
            self.env['custom.sessions.order.line'].sudo().create(obj4)
        return orderlines

    @api.model
    def crea_custom_orden_lines(self, lines):
        _logger.info('99999999999999999999999999 %s',lines)
        return lines