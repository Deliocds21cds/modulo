# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class RestaurantTableInherit(models.Model):
    _inherit = 'restaurant.table'

    
    color = fields.Char("Color")
    status = fields.Char("Status")



class RestaurantFloorInherit(models.Model):
    _inherit = 'restaurant.floor'

    @api.multi
    def action_show_transferencias(self):
        self.ensure_one()
        return {
            'name':_("Transferencias"),
            'view_mode':'tree,form',
            #'view_id': False,
            'view_type': 'form',
            'res_model': 'transfer.model',
            #'res_id': req_id,
            'type': 'ir.actions.act_window',
            #'nodestroy': True,
            'target': 'main',
            'clear_bredcrumb':False,
             'domain': '[]',
            'flags': {'mode': 'edit'}
        }