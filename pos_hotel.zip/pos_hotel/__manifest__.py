# -*- coding: utf-8 -*-

{
    'name': 'POS Hotel',
    'summary': 'Control service hotel',
    'version': '1.0.0.4',
    'category': 'Point of Sale',
    'author': '',
    'website': '',
    'depends': [
        'point_of_sale',
        'pos_restaurant',
        'pos_service_time',
        'edocs_print_format'
    ],
    'data': [
        'report/paperformat.xml',
        'report/reporteFacturas.xml',
        'report/reporteProductos.xml',
        'report/reporteInventario.xml',
        'report/reporteMovimiento.xml',
        'security/ir.model.access.csv',
        'views/pos_js_connector.xml',
        'views/pos_restaurant_views.xml',
        'views/transfer_model_views.xml',
        'views/custom_session_views.xml',
        'views/res_user.xml',
       # 'static/src/xml/pos.xml'
    ],
    'qweb': [
       #     'static/src/xml/zreport.xml',

    ],
    'images': ['static/'],
    'application': False,
    'installable': True,
}
