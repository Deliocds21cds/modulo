# -*- coding: utf-8 -*-

{
    'name': 'POS Hotel',
    'summary': 'Control service hotel',
    'version': '1.0.0.1',
    'category': 'Point of Sale',
    'author': '',
    'website': '',
    'depends': [
        'point_of_sale',
        'pos_restaurant'
    ],
    'data': [
        'views/pos_js_connector.xml',
        'views/pos_restaurant_views.xml',
        'views/transfer_model_views.xml'
    ],
    'qweb': [
    ],
    'images': ['static/'],
    'application': False,
    'installable': True,
}
