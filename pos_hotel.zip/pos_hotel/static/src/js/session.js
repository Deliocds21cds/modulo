odoo.define('pos_hotel.session', function (require) {    
    "use strict";
        var models = require('point_of_sale.models');
        models.load_models({    
            model: 'custom.sessions', // your model
            fields: ['cajero','fecha','time_inicio','time_cierre','total_vendido','estado','c_session_line_ids'], // fields that will be used from your model 
            domain: [], // domain filter
            loaded: function(self,session){     
            // a function that will be executed on loading
                console.log(session)
                /* 
                self.batches = batches; */
            },
    
        })
})