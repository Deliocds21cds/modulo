odoo.define('pos_hotel.session_line', function (require) {    
    "use strict";
        var models = require('point_of_sale.models');
        models.load_models({    
            model: 'custom.sessions.order', // your model
            fields: ['c_session_id','referencia','fecha','habitacion','cliente','total'], // fields that will be used from your model 
            domain: [], // domain filter
            loaded: function(self,session_line_ids){     
            // a function that will be executed on loading
                console.log(session_line_ids)
                
                self.session_line_ids = session_line_ids;
            },
    
        })
})