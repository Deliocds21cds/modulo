odoo.define('pos_hotel.main', function (require) {
    "use strict";
    var floors = require('pos_restaurant.floors');
    var printbill = require('pos_restaurant.printbill');
    var chrome = require('point_of_sale.chrome');
    var screens = require('point_of_sale.screens');
    var core = require('web.core');
    var ajax = require('web.ajax');
    var module = require('point_of_sale.models');
    var models = module.PosModel.prototype.models;
    var qweb = core.qweb;
    ajax.loadXML('/pos_hotel/static/src/xml/pos.xml', qweb);
    for (var i = 0; i < models.length; i++) {
        var model = models[i];
        if (model.model === 'restaurant.table') {
            model.fields.push('status');
        };
        if (model.model === 'pos.order.line') {
            model.fields.push('date_start', 'date_stop');
        }
    };
    floors.TableWidget.include({
        click_handler: function () {
            var self = this;
            var floorplan = this.getParent();
            if (floorplan.editing) {
                setTimeout(function () {  // in a setTimeout to debounce with drag&drop start
                    if (!self.dragging) {
                        if (self.moved) {
                            self.moved = false;
                        } else if (!self.selected) {
                            self.getParent().select_table(self);
                        } else {
                            self.getParent().deselect_tables();
                        }
                    }
                }, 50);
            } else {
                if (this.table.status == "L") {
                    this.gui.show_popup('confirm', {
                        'title': _t('Limpieza / Mantenimiento'),
                        'body': _t('¿Ya se encuentra disponible la habitación?'),
                        confirm: function () {
                            console.log("TABLE",self.gui)
                            self.table.status = "D";
                            self.table.color = 'rgb(53,211,116)';
                            self.renderElement()
                        },
                    });
                } else {
                    floorplan.pos.set_table(this.table);
                    this.table.status = "O";
                    this.table.color = 'rgb(255,148,138)';
                    this.pos.get_order().save_to_db();
                }
            }
        }
    });
    floors.TransferOrderButton.include({
        button_click: function () {
            this.pos.transfer_order_to_different_table();
            this.pos.table.status = "L";
            this.pos.table.color = 'rgb(235,236,109)';
            //this.pos.get_order().save_to_db();
        },
    });


    printbill.PrintBillButton.include({
        button_click: function () {
            var self = this;
            var order = self.pos.get_order();
            var client = order.pos.get_client();
            if (!client) {
                this.gui.show_popup('confirm', {
                    'title': _t('Please select the Customer'),
                    'body': _t('You need to select the customer before you can invoice an order.'),
                    confirm: function () {
                        self.gui.show_screen('clientlist', null);
                    },
                });
            } else {
                if (!this.pos.config.iface_print_via_proxy) {
                    this.gui.show_screen('bill');
                } else {
                    this.print_xml();
                }
            }
        }
    })


    screens.ProductScreenWidget.include({

        start: function () {
            this._super();
            var self = this;
            var flag = true;
            this.$('.control-button').click(function () {
                this.btn_handle = function (event) {
                    console.log(event);
                    if (event.target.className == 'control-button return') {
                        console.log("Aqui Return");
                    }
                    else if (event.target.className == 'control-button order-printbill') {
                        console.log("Aqui Printeas");
                    }
                    else if (event.target.className == 'control-button swap') {
                        $(".username").click()
                        console.log("Aqui Cambias");
                    }
                    else if (event.target.className == 'control-button stop') {
                        console.log("Aqui Detienes");
                        $(".fa-stop-circle-o").click()
                    }
                }
                if (flag) {
                    document.body.addEventListener('click', this.btn_handle);
                    flag = false;
                }
            });
        }
    })


    chrome.OrderSelectorWidget.include({
        deleteorder_click_handler: function () {
            var self = this;
            var order = this.pos.get_order();
            if (!order) {
                return;
            } else if (!order.is_empty()) {
                this.gui.show_popup('confirm', {
                    'title': _t('Destroy Current Order ?'),
                    'body': _t('You will lose any data associated with the current order'),
                    confirm: function () {
                        self.pos.table.status = "D";
                        self.pos.table.color = 'rgb(53,211,116)';
                        self.pos.get_order().save_to_db();
                        self.pos.delete_current_order();
                    },
                });
            } else {
                self.pos.table.status = "D";
                self.pos.table.color = 'rgb(53,211,116)';
                this.pos.get_order().save_to_db();
                this.pos.delete_current_order();
            }
        }
    });
    screens.ReceiptScreenWidget.include({
        click_next: function () {
            this.pos.table.status = "L";
            this.pos.table.color = 'rgb(235,236,109)';
            this.pos.get_order().save_to_db();
            this.pos.get_order().finalize();
        }
    });
    screens.OrderWidget.include({
        action_play: function (orderline) {
            var self = this;
            orderline.time_init = true;
            orderline.time_end = false;
            this.rerender_orderline(orderline);
            this.update_summary();

            if (!orderline.start) {
                orderline.start = new Date;
                console.log("POS start", this.pos.get_order());
            }
            else if (orderline.stop) {
                orderline.start = new Date(new Date - (new Date(orderline.stop) - new Date(orderline.start)));
                orderline.stop = null;
                console.log("POS renude", this.pos.get_order());
            } else
                orderline.start = new Date(orderline.start);
            orderline.timer_interval = setInterval(function () {
                self.time_update(orderline)
            }, 1000);
            console.log("start", orderline);
        },
        action_stop: function (orderline) {
            clearInterval(orderline.timer_interval);
            orderline.time_end = true;
            orderline.time_init = false;
            orderline.stop = new Date;
            console.log("POS stop", this.pos.get_order());
            console.log("stop", orderline);


            this.pos.get_order().save_to_db();
            var duration = orderline.usage_time;
            var hours = parseInt(duration.split(":")[0]);
            var minutes = parseInt(duration.split(":")[1]);
            var seconds = parseInt(duration.split(":")[2]);
            if (minutes >= 8 && minutes < 19) {
                minutes = 15
            }
            if (minutes >= 19 && minutes < 35) {
                minutes = 30
            }
            if (minutes >= 35 && minutes <= 45) {
                minutes = 45
            }
            if (minutes >= 46) {
                hours += 1
            }
            var minute_timer = (hours * 60) + minutes;
            console.log(minute_timer);
            var regex = /[+-]?\d+(?:\.\d+)?/g;
            var variant_name = orderline.product.variant_name;
            var number_variant = variant_name ? variant_name.match(regex) : false;
            var quantity_service;

            if (minute_timer > 0 && seconds >= 0) {
                if (orderline.product.service_time_type == 'hour') {
                    let hours_end = (hours == 0 ? hours + 1 : hours)
                    orderline.set_quantity(hours_end);
                } else {
                    if (variant_name) {
                        let quantity_service_round_up = Math.round((minute_timer / number_variant[0]) + 0.369);
                        quantity_service = quantity_service_round_up == 0 ? 1 : quantity_service_round_up;
                        orderline.set_quantity(quantity_service);
                    } else {
                        orderline.set_quantity(minute_timer);
                    }
                }
            }
            this.pos.get_order().save_to_db();
            this.rerender_orderline(orderline);
            this.update_summary();
        }
    })
})