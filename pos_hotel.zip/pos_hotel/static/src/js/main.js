odoo.define('pos_hotel.main', function (require) {
    "use strict";
    var floors = require('pos_restaurant.floors');
    var printbill = require('pos_restaurant.printbill');
    var chrome = require('point_of_sale.chrome');
    var screens = require('point_of_sale.screens');
    var module = require('point_of_sale.models');
    var core = require('web.core');
    var ajax = require('web.ajax');
    var models = module.PosModel.prototype.models;
    var qweb = core.qweb;
    var rpc = require('web.rpc');
    var gui = require('point_of_sale.gui');
    ajax.loadXML('/pos_hotel/static/src/xml/pos.xml', qweb);
    ajax.loadXML('/pos_hotel/static/src/xml/popups.xml', qweb);
    console.log('========================= ENTRO =======================');
    var popups = require('point_of_sale.popups');
    var CambiaTurnoPopUp = popups.extend({
        template: 'CambiaTurno',
        click_confirm: function () {
            var order = this.pos.get_order();
            var ret = new $.Deferred();
            let entered_pass = $('.red_jhons').val()
            console.log(entered_pass)
            var users = this.pos.users
            console.log(users)
            var user_pin = users.filter(i => i.pos_security_pin == entered_pass)
            if (user_pin.length == 0) {
                this.gui.show_popup('error', {
                    'title': _t('PIN incorrecto'),
                    'body': _t('Por favor ingrese un PIN asociado.')
                });
                $('.red_jhons').val("");
                ret.reject();
            }
            else {
                order.pos.set_cashier(user_pin[0]);
                order.pos.chrome.widget.username.renderElement();
                $('.red_jhons').val("");
                this.gui.close_popup();
                ret.resolve();
                /* Cerrar Sessión del actual usuario */
                /* Crear Sessión del siguiente usuario */
                console.log(user_pin[0])
                var obj = {
                    "cajero": user_pin[0].id,
                    "fecha": new Date(),
                    "time_inicio": new Date(),
                    "time_cierre": false,
                    "total_vendido": 0,
                    "estado": "online",
                    "c_session_line_ids": [],
                }
                rpc.query({
                    model: 'pos.config',
                    method: 'crear_custom_session',
                    args: [{
                        'session': obj,
                    }]
                }).then(function (result) {

                    console.log(result)

                });
            }


        }
    });
    gui.define_popup({ name: 'cambio-turno', widget: CambiaTurnoPopUp });

    for (var i = 0; i < models.length; i++) {
        var model = models[i];
        if (model.model === 'restaurant.table') {
            model.fields.push('status');
        };
        if (model.model === 'pos.order.line') {
            model.fields.push('date_start', 'date_stop');
        }
    };
    floors.TableWidget.include({
        click_handler: function () {
            var self = this;
            var floorplan = this.getParent();
            if (floorplan.editing) {
                setTimeout(function () {  // in a setTimeout to debounce with drag&drop start
                    if (!self.dragging) {
                        if (self.moved) {
                            self.moved = false;
                        } else if (!self.selected) {
                            self.getParent().select_table(self);
                        } else {
                            self.getParent().deselect_tables();
                        }
                    }
                }, 50);
            } else {
                if (this.table.status == "L") {
                    this.gui.show_popup('confirm', {
                        'title': _t('Limpieza / Mantenimiento'),
                        'body': _t('¿Ya se encuentra disponible la habitación?'),
                        confirm: function () {
                            self.table.status = "D";
                            self.table.color = 'rgb(53,211,116)';
                            self.renderElement()
                            self.save_changes();
                        },
                    });
                } else {
                    this.table.status = "O";
                    this.table.color = 'rgb(255,148,138)';
                    this.save_changes();
                    floorplan.pos.set_table(this.table);
                }
            }
        }
    });


    floors.TransferOrderButton.include({
        button_click: function () {
            this.pos.transfer_order_to_different_table();
            this.pos.table.status = "L";
            this.pos.table.color = 'rgb(235,236,109)';
            this.save_changes();
            this.activate_room();

        },

        activate_room: function () {
            setTimeout(() => {
                this.pos.table.status = "D";
                this.pos.table.color = 'rgb(53,211,116)';
                this.save_changes();
            }, 10000)
        },

        save_changes: function () {
            var self = this;
            var fields = _.find(this.pos.models, function (model) { return model.model === 'restaurant.table'; }).fields;

            // we need a serializable copy of the table, containing only the fields defined on the server
            var serializable_table = {};
            for (var i = 0; i < fields.length; i++) {
                if (typeof this.pos.table[fields[i]] !== 'undefined') {
                    serializable_table[fields[i]] = this.pos.table[fields[i]];
                }
            }
            // and the id ...
            serializable_table.id = this.pos.table.id;

            rpc.query({
                model: 'restaurant.table',
                method: 'create_from_ui',
                args: [serializable_table],
            })
                .then(function (table_id) {
                    rpc.query({
                        model: 'restaurant.table',
                        method: 'search_read',
                        args: [[['id', '=', table_id]], fields],
                        limit: 1,
                    })
                        .then(function (result) {
                            var table = result[0];
                            for (var field in table) {
                                self.pos.table[field] = table[field];
                            }
                        });
                }, function (type, err) {
                    self.gui.show_popup('error', {
                        'title': _t('Changes could not be saved'),
                        'body': _t('You must be connected to the internet to save your changes.'),
                    });
                });
        }

    });


    printbill.PrintBillButton.include({
        button_click: function () {
            var self = this;
            var order = self.pos.get_order();
            var client = order.pos.get_client();
            if (!client) {
                this.gui.show_popup('confirm', {
                    'title': _t('Please select the Customer'),
                    'body': _t('You need to select the customer before you can invoice an order.'),
                    confirm: function () {
                        self.gui.show_screen('clientlist', null);
                    },
                });
            } else {
                if (!this.pos.config.iface_print_via_proxy) {
                    this.gui.show_screen('bill');
                } else {
                    this.print_xml();
                }
            }
        }
    })


    screens.ProductScreenWidget.include({

        start: function () {
            this._super();
            var self = this;
            var flag2 = true;
            var flag = true;
            this.$('.control-button').click(function () {
                console.log('===========>', self.pos)
                this.btn_handle = function (event) {
                    if (event.target.className == 'control-button close') {
                        console.log("Aqui Cerrar turno");
                        self.pos.gui.show_popup('confirm', {
                            'title': _t('Cerrar Sesión'),
                            'body': _t('Cerrar Turno'),
                            confirm: function () {
                                console.log('Cierra session')
                                rpc.query({
                                    model: 'pos.config',
                                    method: 'cierra_custom_session',
                                    args: [{
                                        'session': this.pos.session[0],
                                    }]
                                }).then(function (result) {

                                    console.log(result)

                                });
                            },
                        });
                    }
                    else if (event.target.className == 'control-button order-printbill') {
                        console.log("Aqui Printeas");
                    }
                    else if (event.target.className == 'control-button swap') {
                        $('.red_jhons').focus()
                        self.pos.gui.show_popup('cambio-turno', {
                            'title': _t('Cambia Turno'),
                            'body': _t('Cerrar Turno'),
                            confirm: function () {
                                console.log('Cambia usuario')
                            },
                        });
                        /* $(".username").click() */
                    }
                    else if (event.target.className == 'control-button stop') {
                        $(".fa-stop-circle-o").click()
                    }

                }
                if (flag) {
                    document.body.addEventListener('click', this.btn_handle);
                    flag = false;
                }
            });
            this.$('.product-img').click(function () {
                this.product_handle = function (event) {
                    if (event.target.alt == 'Imagen del producto') {
                        $(".fa-play-circle-o").click()
                    }
                }
                if (flag2) {
                    document.body.addEventListener('click', this.product_handle);
                    flag2 = false;
                }
            })
        },

    })

    screens.ActionpadWidget.include({
        renderElement: function () {
            var self = this;
            this._super();
            this.$('.pay').click(function () {
                var order = self.pos.get_order();
                console.log('pos', order)
                /* lucho */
                let times = order.orderlines.models.filter(i => i.start != null && i.stop != null)
                console.log('times', times)
                if (times[0]) {
                    var obj = {
                        'id': times[0].id,
                        'start': times[0].start,
                        'stop': times[0].stop
                    }
                }
                else{
                    var obj = {
                        'id': null,
                        'start':null,
                        'stop': null
                    }
                }

                rpc.query({
                    model: 'pos.order.line',
                    method: 'save_times',
                    args: [
                        {
                            'obj': obj
                        }
                    ]
                }).then(function (result) {

                    console.log(result)

                });
                var has_valid_product_lot = _.every(order.orderlines.models, function (line) {
                    return line.has_valid_product_lot();
                });
                if (!has_valid_product_lot) {
                    self.gui.show_popup('confirm', {
                        'title': _t('Empty Serial/Lot Number'),
                        'body': _t('One or more product(s) required serial/lot number.'),
                        confirm: function () {
                            self.gui.show_screen('payment');
                        },
                    });
                } else {
                    self.gui.show_screen('payment');
                }
            });
            this.$('.set-customer').click(function () {
                self.gui.show_screen('clientlist');
            });
        }


    })
    chrome.OrderSelectorWidget.include({
        deleteorder_click_handler: function () {
            var self = this;
            var order = this.pos.get_order();
            if (!order) {
                return;
            } else if (!order.is_empty()) {
                this.gui.show_popup('confirm', {
                    'title': _t('Destroy Current Order ?'),
                    'body': _t('You will lose any data associated with the current order'),
                    confirm: function () {
                        self.pos.table.status = "D";
                        self.pos.table.color = 'rgb(53,211,116)';
                        self.save_changes();
                        self.pos.delete_current_order();
                    },
                });
            } else {
                self.pos.table.status = "D";
                self.pos.table.color = 'rgb(53,211,116)';
                this.save_changes();
                this.pos.delete_current_order();
            }
        },

        save_changes: function () {
            var self = this;
            var fields = _.find(this.pos.models, function (model) { return model.model === 'restaurant.table'; }).fields;

            // we need a serializable copy of the table, containing only the fields defined on the server
            var serializable_table = {};
            for (var i = 0; i < fields.length; i++) {
                if (typeof this.pos.table[fields[i]] !== 'undefined') {
                    serializable_table[fields[i]] = this.pos.table[fields[i]];
                }
            }
            // and the id ...
            serializable_table.id = this.pos.table.id;

            rpc.query({
                model: 'restaurant.table',
                method: 'create_from_ui',
                args: [serializable_table],
            })
                .then(function (table_id) {
                    rpc.query({
                        model: 'restaurant.table',
                        method: 'search_read',
                        args: [[['id', '=', table_id]], fields],
                        limit: 1,
                    })
                        .then(function (result) {
                            var table = result[0];
                            for (var field in table) {
                                self.pos.table[field] = table[field];
                            }
                            self.renderElement();
                        });
                }, function (type, err) {
                    self.gui.show_popup('error', {
                        'title': _t('Changes could not be saved'),
                        'body': _t('You must be connected to the internet to save your changes.'),
                    });
                });
        }

    });
    screens.PaymentScreenWidget.include({
        validate_order: async function (force_validation) {
            if (this.order_is_valid(force_validation)) {
                var order = await this.pos.get_order();
                console.log('order', order);

                var pos_session_id = this.pos.session.filter(i => i.session_real == this.pos.pos_session.name && i.estado == 'online')
                let obj = {
                    'c_session_id': pos_session_id[0].id,
                    'referencia': order.name,
                    'fecha': new Date,
                    'habitacion': order.table.name,
                    'cliente': order.changed.client.id,
                    'total': order.get_total_with_tax(),
                    'table_id': order.table.id,
                    "session_id": this.pos.pos_session.id,
                    'hora_inicio': order.orderlines.models[0].start,
                    'hora_final': order.orderlines.models[0].stop,
                    'tiempo_total': order.orderlines.models[0].usage_time,
                }
                console.log('obj=====', obj)

                rpc.query({
                    model: 'pos.config',
                    method: 'crea_custom_orden',
                    args: [obj]
                }).then(function (result) {

                    console.log(result)

                });

                setTimeout(() => {
                    this.finalize_validation();

                }, 500);
            }
        },
    })
    screens.ReceiptScreenWidget.include({
        click_next: function () {
            this.pos.table.status = "L";
            this.pos.table.color = 'rgb(235,236,109)';
            this.save_changes();
            this.pos.get_order().finalize();
            setTimeout(() => {
                this.pos.table.status = "D";
                this.pos.table.color = 'rgb(53,211,116)';
                this.save_changes();
                this.renderElement();
            }, 10000)
        },

        save_changes: function () {
            var self = this;
            var fields = _.find(this.pos.models, function (model) { return model.model === 'restaurant.table'; }).fields;

            // we need a serializable copy of the table, containing only the fields defined on the server
            var serializable_table = {};
            for (var i = 0; i < fields.length; i++) {
                if (typeof this.pos.table[fields[i]] !== 'undefined') {
                    serializable_table[fields[i]] = this.pos.table[fields[i]];
                }
            }
            // and the id ...
            serializable_table.id = this.pos.table.id;

            rpc.query({
                model: 'restaurant.table',
                method: 'create_from_ui',
                args: [serializable_table],
            })
                .then(function (table_id) {
                    rpc.query({
                        model: 'restaurant.table',
                        method: 'search_read',
                        args: [[['id', '=', table_id]], fields],
                        limit: 1,
                    })
                        .then(function (result) {
                            var table = result[0];
                            for (var field in table) {
                                self.pos.table[field] = table[field];
                            }
                            self.renderElement();
                        });
                }, function (type, err) {
                    self.gui.show_popup('error', {
                        'title': _t('Changes could not be saved'),
                        'body': _t('You must be connected to the internet to save your changes.'),
                    });
                });
        },

        print: function () {
            for (let index = 0; index < 3; index++) {
                var self = this;

                if (!this.pos.proxy.printer) {

                    this.lock_screen(true);

                    setTimeout(function () {
                        self.lock_screen(false);
                    }, 1000);

                    this.print_web();
                } else {
                    this.print_html();
                    this.lock_screen(false);
                }
            }
        }

    });
    screens.OrderWidget.include({

        action_play: function (orderline) {
            var self = this;
            orderline.time_init = true;
            orderline.time_end = false;
            this.rerender_orderline(orderline);
            this.update_summary();

            if (!orderline.start) {
                orderline.start = new Date;
            }
            else if (orderline.stop) {
                orderline.start = new Date(new Date - (new Date(orderline.stop) - new Date(orderline.start)));
                orderline.stop = null;
            } else
                orderline.start = new Date(orderline.start);
            orderline.timer_interval = setInterval(function () {
                self.time_update(orderline)
            }, 1000);
        },
        action_stop: function (orderline) {
            clearInterval(orderline.timer_interval);
            orderline.time_end = true;
            orderline.time_init = false;
            orderline.stop = new Date;


            this.pos.get_order().save_to_db();
            var duration = orderline.usage_time;
            var hours = parseInt(duration.split(":")[0]);
            var minutes = parseInt(duration.split(":")[1]);
            var seconds = parseInt(duration.split(":")[2]);
            if (minutes >= 8 && minutes < 19) {
                minutes = 15
            }
            if (minutes >= 19 && minutes < 35) {
                minutes = 30
            }
            if (minutes >= 35 && minutes <= 45) {
                minutes = 45
            }
            if (minutes >= 46) {
                hours += 1
            }
            var minute_timer = (hours * 60) + minutes;
            var regex = /[+-]?\d+(?:\.\d+)?/g;
            var variant_name = orderline.product.variant_name;
            var number_variant = variant_name ? variant_name.match(regex) : false;
            var quantity_service;

            if (minute_timer > 0 && seconds >= 0) {
                if (orderline.product.service_time_type == 'hour') {
                    let hours_end = (hours == 0 ? hours + 1 : hours)
                    orderline.set_quantity(hours_end);
                } else {
                    if (variant_name) {
                        let quantity_service_round_up = Math.round((minute_timer / number_variant[0]) + 0.369);
                        quantity_service = quantity_service_round_up == 0 ? 1 : quantity_service_round_up;
                        orderline.set_quantity(quantity_service);
                    } else {
                        orderline.set_quantity(minute_timer);
                    }
                }
            }
            this.pos.get_order().save_to_db();
            this.rerender_orderline(orderline);
            this.update_summary();
        }
    })
})