odoo.define('pos_hotel.s_order_lines', function (require) {    
    "use strict";
        var models = require('point_of_sale.models');
        models.load_models({    
            model: 'custom.sessions.order.line', // your model
            fields: ['product','price_unit','qty','dcto','dcto_reason'], // fields that will be used from your model 
            domain: [], // domain filter
            loaded: function(self,c_order_lines){     
            // a function that will be executed on loading
                console.log(c_order_lines)
                
                self.c_order_lines = c_order_lines;
            },
    
        })
})