# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': "Direct Login to POS",
    'version' : '12.1.1',
    'summary': 'Redirect User to POS While Login With Odoo.',
    'author': "WeR Informative",
    'category': 'Point of Sale',
    'description': """
    Restrict User to Access Backend Odoo.User Will Directly Login in Assigned POS. 
""",
	'website': 'https://werinformative.com/',
    'price': 12.00, 
    'currency': 'EUR',
    'depends' : ['base','point_of_sale'],
    'data': [
        'views/user.xml',
        'views/templates.xml',
    ],
    'images': ['static/description/screenshots/banner.png'],
    'installable': True,
    'application': True,
    'auto_install': False,
    
}

