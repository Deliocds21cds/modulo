# -*- coding: utf-8 -*-

from odoo import fields, models, api, _

class res_users(models.Model):
	_inherit = 'res.users'

	assigned_pos_config = fields.Many2one('pos.config',string="Assigned POS")
