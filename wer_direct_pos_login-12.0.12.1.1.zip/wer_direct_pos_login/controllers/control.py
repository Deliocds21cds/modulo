# -*- coding: utf-8 -*-
import odoo
from odoo import fields, models, api, _
from odoo.addons.web.controllers.main import Home, ensure_db
from odoo import http
from odoo.http import request

class Home(Home):
	@http.route('/', type='http', auth="none")
	def index(self, s_action=None, db=None, **kw):
		res = super(Home, self).index(s_action=None, db=None, **kw)
		user = request.env['res.users'].browse([request.session.uid])
		if user.assigned_pos_config:
		    pos_session = request.env['pos.session'].sudo().search(
		        [('config_id', '=', user.assigned_pos_config.id), ('state', '=', 'opened')])
		    if pos_session and pos_session.user_id.id == user.id:
		        return http.redirect_with_hash('/pos/web')
		    elif pos_session and pos_session.user_id.id != user.id:
		        return http.redirect_with_hash('/web/session/logout/?redirect=/web/login?pos_error=True')
		    else:
		        session_id = user.assigned_pos_config.open_session_cb()
		        pos_session = request.env['pos.session'].sudo().search(
		            [('config_id', '=', user.assigned_pos_config.id), ('state', '=', 'opening_control')])
		        if user.assigned_pos_config.cash_control:
		            pos_session.write({'opening_balance': True})
		        session_open = pos_session.action_pos_session_open()
		        return http.redirect_with_hash('/pos/web')
		return res

	@http.route('/web', type='http', auth="none")
	def web_client(self, s_action=None, **kw):
		res = super(Home, self).web_client(s_action, **kw)
		user = request.env['res.users'].browse([request.session.uid])
		if user.assigned_pos_config:
		    pos_session = request.env['pos.session'].sudo().search(
		        [('config_id', '=', user.assigned_pos_config.id), ('state', '=', 'opened')])
		    if pos_session and pos_session.user_id.id == user.id:
		        return http.redirect_with_hash('/pos/web')
		    elif pos_session and pos_session.user_id.id != user.id:
		        return http.redirect_with_hash('/web/session/logout/?redirect=/web/login?pos_error=True')
		    else:
		        session_id = user.assigned_pos_config.open_session_cb()
		        pos_session = request.env['pos.session'].sudo().search(
		            [('config_id', '=', user.assigned_pos_config.id), ('state', '=', 'opening_control')])
		        if users.assigned_pos_config.cash_control:
		            pos_session.write({'opening_balance': True})
		        session_open = pos_session.action_pos_session_open()
		        return http.redirect_with_hash('/pos/web')
		return res

	@http.route()
	def web_login(self, redirect=None, **kw):
		ensure_db()
		request.params['login_success'] = False
		if request.httprequest.method == 'GET' and redirect and request.session.uid:
		    return http.redirect_with_hash(redirect)
		
		if not request.uid:
		    request.uid = odoo.SUPERUSER_ID
		
		values = request.params.copy()
		try:
		    values['databases'] = http.db_list()
		except odoo.exceptions.AccessDenied:
		    values['databases'] = None
		if kw.get('pos_error'):
		    values['error']= _("Another user is already using the POS")
		    return request.render('web.login', values)
		if request.httprequest.method == 'POST':
		    old_uid = request.uid
		    uid = request.session.authenticate(request.session.db, request.params['login'], request.params['password'])
		    if uid is not False:
		        users = request.env['res.users'].browse([uid])
		        if users.assigned_pos_config:
		            pos_session = request.env['pos.session'].sudo().search(
		                [('config_id', '=', users.assigned_pos_config.id), ('state', '=', 'opened')])
		            if pos_session and pos_session.user_id.id == users.id:
		                return http.redirect_with_hash('/pos/web')
		            elif pos_session and pos_session.user_id.id != users.id:
		                return http.redirect_with_hash('/web/session/logout/?redirect=/web/login?pos_error=True')
		            else:
		                session_id = users.assigned_pos_config.open_session_cb()
		                pos_session = request.env['pos.session'].sudo().search(
		                    [('config_id', '=', users.assigned_pos_config.id), ('state', '=', 'opening_control')])
		                if users.assigned_pos_config.cash_control:
		                    pos_session.write({'opening_balance': True})
		                session_open = pos_session.action_pos_session_open()
		                return http.redirect_with_hash('/pos/web')
		        request.params['login_success'] = True
		        if not redirect:
		            redirect = '/web'
		            return http.redirect_with_hash(redirect)
		    request.uid = old_uid
		    values['error'] = _("Wrong login/password")
		return request.render('web.login', values)
