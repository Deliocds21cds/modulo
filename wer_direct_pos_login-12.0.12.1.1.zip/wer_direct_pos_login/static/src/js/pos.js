odoo.define('wer_direct_pos_login.pos', function (require) {
    "use strict";

    var chrome = require('point_of_sale.chrome');
    var framework = require('web.framework');
    var models = require('point_of_sale.models');
    var gui = require('point_of_sale.gui');
    var PopupWidget = require('point_of_sale.popups');
    var core = require('web.core');

    var _t = core._t;

    models.load_fields("res.users", ['assigned_pos_config']);

    chrome.HeaderButtonWidget.include({
        renderElement: function(){
            var self = this;
            this._super();
            if(this.action){
                this.$el.click(function(){
                    self.gui.show_popup('confirm',{
                        'title': _t('Confirm?'),
                        'body':  _t('Do you want to close the POS?'),
                        confirm: function(){
                            var cashier = self.pos.user || false;
                            if(cashier && cashier.assigned_pos_config && cashier.assigned_pos_config[0]){
                                framework.redirect('/web/session/logout');
                            } else{
                                self.pos.gui.close();
                            }
                        },
                    });
                });
            }
        },
    });
});