# -*- coding: utf-8 -*-
# Copyright 2019 GTICA C.A. - Ing Henry Vivas

{
    'name': 'POS Service per Time',
    'summary': 'Time Chek-in and check-out, Service payment per hour, minutes',
    'version': '12.0.1.0.0',
    'category': 'Point of Sale',
    'author': 'GTICA C.A',
    'support': 'controlmanager@gtica.online',
    'license': 'OPL-1',
    'website': 'https://gtica.online/',
    'sequence': 150,
    'price': 21.99,
    'currency': 'EUR',
    'depends': [
        'point_of_sale',
    ],
    'data': [
        'templates/assets.xml',
        'views/pos_service_time_view.xml',
    ],
    'qweb': [
        'static/src/xml/pos.xml'
    ],
    'images': ['static/description/main_screenshot.png'],
    'application': False,
    'installable': True,
}
