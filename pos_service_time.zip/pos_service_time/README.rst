POS Service Time
---------------

MOdule for Time Chek-in and check-out, Service payment per hour, minutes
<a href="https://gtica.online/">Technical support</a>

