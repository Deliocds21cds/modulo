* This module contains a *basic return* feature that makes possible returning
  the same order over and over. If you need a full return feature, you can
  install ``pos_order_return`` (only back office implementation), or
  ``pos_order_return_traceability``, which also covers front office support.
