This module extends the functionality of the PoS frontend allowing to load
already done PoS Orders in order to be able to operate over them, being able to
reprint past tickets or return them.
