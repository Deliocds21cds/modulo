
v1.0.0
======
* remove decimal zero trailing from float and monetary fields in odoo views and reports.
