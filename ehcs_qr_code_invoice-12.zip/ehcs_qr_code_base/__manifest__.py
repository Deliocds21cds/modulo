# -*- coding: utf-8 -*-
{
    'name': 'QR Code Base',
    'version': '12.0.1.0.0',
    'category': 'Base',
    'author': 'ERP Harbor Consulting Services',
    'summary': 'QR Code Base',
    'website': 'http://www.erpharbor.com',
    'description': """
This module helps to generate the QR Code based on the URL of the document.
     """,
    'images': [
        'static/description/banner.png',
    ],
    'installable': True,
}
