# -*- coding: utf-8 -*-
from . import qr_code_base
