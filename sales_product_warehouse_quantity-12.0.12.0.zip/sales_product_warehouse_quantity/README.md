Quick access of quantity available in each warehouse on the Sales Order
-----------------------------------------------------------------------

To empower the user by providing the decision making knowledge is one of the key areas to focus while implementing ERP.
An effort towards providing analysed information mining through the already existed data.
This module gives the available quantity of product on multiple warehouses while placing the sales order in Odoo.
The total cumulative quantity will be calculated considering not only the stock location of the warehouse but also all the sub-locations of each of the stock location of all warehouses.




