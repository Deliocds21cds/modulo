This module was written to make it simple to add custom operators for view
inheritance.
