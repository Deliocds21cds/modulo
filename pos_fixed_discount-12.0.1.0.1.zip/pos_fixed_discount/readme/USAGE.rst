Just click on "Discount (Amount)" and set the amount.
