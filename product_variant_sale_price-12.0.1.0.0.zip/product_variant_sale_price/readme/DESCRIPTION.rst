This module allows to handle sale price at product variant level
(product.product) instead of product level (product.template), which is the
default.

This module also hides sale price at product template level when has more than
one variant.
