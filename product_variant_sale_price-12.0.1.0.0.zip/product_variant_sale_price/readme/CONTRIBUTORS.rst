* Carlos Dauden <carlos.dauden@tecnativa.com>
* Sergio Teruel <sergio.teruel@tecnativa.com>
* Alex Comba <alex.comba@agilebg.com>
* Fabien Bourgeois <fabien@yaltik.com>
* Vicent Cubells <info@obertix.net>
