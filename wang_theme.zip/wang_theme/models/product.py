from odoo import models, api, fields, _


class Website(models.Model):
    _inherit = 'website'

    @api.multi
    def get_blogs(self):
        blog_ids = self.env['blog.post'].search(
            [('website_published', '=', True)])
        return blog_ids

    @api.multi
    def get_categories(self):
        category_ids = self.env['product.public.category'].search(
            [('parent_id', '=', False)])
        res = {
            'categories': category_ids,
        }
        return res
