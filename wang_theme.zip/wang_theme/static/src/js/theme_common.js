$(document).ready(function () {
    $(".as_our_blog").owlCarousel({
        items: 2,
        margin: 10,
        nav: true,
        pagination: false,
        responsive: {
            0: {
                items: 1,
            },
            481: {
                items: 1,
            },
            768: {
                items: 2,
            },
            1024: {
                items: 2,
            }
        }

    });
    $('form.js_attributes input, form.js_attributes select').on('click', function (ev) {
        if (!ev.isDefaultPrevented()) {
            ev.preventDefault();
            $(ev.currentTarget).closest("form").submit();
        }
    })
});
$(document).ready(function () {
// When the user scrolls the page, execute myFunction
    window.onscroll = function () {
        myFunction()
    };

// Get the navbar
    var navbar = document.getElementById("fix_top");

// Get the offset position of the navbar
    var sticky = navbar.offsetTop;

// Add the sticky class to the navbar when you reach its scroll position. Remove "fixed-top" when you leave the scroll position
    function myFunction() {
        if (window.pageYOffset >= sticky) {
            navbar.classList.add("fixed-top")
        } else {
            navbar.classList.remove("fixed-top");
        }
    }
});
