
Installing theme is easy. All you need to do is follow the below mentioned points.
=================================================================================
                                Step 1
=================================================================================
    Once you download this Theme from Odoo Store, you will get one folder - “wang_theme”.
    First, you need to copy all the modules into addons.
    Inside that folder you will get another compressed file “extra_addons.zip“.

=========================================`========================================
                                Step 2
=================================================================================
    Extracting “extra_addons.zip” file, you will get set of other modules inside it.
    You need to copy all the modules into addons
    In Theme folder, open the __manifest__.py file and uncomment modules under Tecspek Extra Addons Depend Modules

=================================================================================
                                Step 3
=================================================================================
    Keep theme and dependent module in addons path.

=================================================================================
                                Step 4
=================================================================================
    Go to your Odoo instance and start Odoo in Developer Mode.
    In order to do that, go to menu "Settings" and click on "Activate the developer mode" link.
    and Update modules list before installing theme.

And, you are done with theme installation. Congratulations!

If you have not received it,please contact us at help.tecspek@gmail.com with proof of your purchase.