
`1.1.5`
-------

**Fix:** Function 'disconnect' not working in expected way

`1.1.4`
-------

**Fix:** Incompatibility with some modules led to the action duplicating

`1.1.3`
-------

**Fix:** Enter did not work for some pop-ups

`1.1.2`
-------

**Fix:** Error on clicking numbers and enter in selection popups


`1.1.1`
-------

**Fix:** Incorrect input data on password pop-up if the first clicked button was `backspace`

`1.1.0`
-------

**New:** Added popup handling

`1.0.2`
-------

- Fix bug: Repeat last keystroke when press non-number key or non-shortcut key after keypress on the number or shortcut key (i.e. q15jj ended up as quantity 1555)

`1.0.1`
-------

- Fix barcode scanner bug
