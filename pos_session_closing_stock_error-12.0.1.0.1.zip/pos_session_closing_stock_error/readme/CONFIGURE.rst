In any Point of Sale configuration (pos.config), disable "Allow closing sessions with stock errors"
to prevent closing sessions with stock errors.
