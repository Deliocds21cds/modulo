Prevent closing PoS Sessions that have stock.picking errors.

These errors usually happen when selecting a wrong serial/lot number in the POS.

.. image:: ../static/description/session_with_errors.png

.. image:: ../static/description/error_msg.png
