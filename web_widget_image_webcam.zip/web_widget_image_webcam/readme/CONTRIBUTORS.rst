* Siddharth Bhalgami <siddharth.bhalgami@gmail.com>
* Kaushal Prajapati <kbprajapati@live.com>
* `Druidoo <https://www.druidoo.io>`_:

  * Iván Todorovich
