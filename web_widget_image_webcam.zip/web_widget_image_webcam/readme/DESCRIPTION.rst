This module extends the functionality of the image widget and allows to take snapshots with WebCam.
