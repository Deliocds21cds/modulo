# -*- coding: utf-8 -*-
from odoo import api, fields, models, tools


class RawMaterialConsumed(models.Model):
    _name = "raw.material.consumed"
    _auto = False
    _order = 'rm_product_id, date'

    production_id = fields.Many2one('mrp.production', 'Manufacturing Order', readonly=True)
    fg_product_id = fields.Many2one('product.product', 'Finish Goods', readonly=True)
    rm_product_id = fields.Many2one('product.product', 'Raw Material', readonly=True)
    product_uom_qty = fields.Float('Quantity', group_operator="sum")
    date = fields.Date('Date', readonly=True)

    @api.model_cr
    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self.env.cr.execute("""CREATE or REPLACE VIEW %s as (

            SELECT MIN(sm.id) AS id,
                   sm.raw_material_production_id production_id,
                   pp.id fg_product_id,
                   sm.product_id rm_product_id,
                   sm.product_uom_qty,
                   sm.date
            FROM stock_move sm
                INNER JOIN mrp_production mp on sm.raw_material_production_id = mp.id
                INNER JOIN product_product pp on mp.product_id = pp.id
            WHERE sm.raw_material_production_id IS NOT NULL
              AND sm.state = 'done'
            GROUP BY sm.id, pp.id

        )""" % (self._table,))
