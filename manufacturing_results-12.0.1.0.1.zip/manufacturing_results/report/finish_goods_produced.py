# -*- coding: utf-8 -*-
from odoo import api, fields, models, tools


class FinishGoodsProduced(models.Model):
    _name = "finish.goods.produced"
    _auto = False
    _order = 'product_id, date'

    production_id = fields.Many2one('mrp.production', 'Manufacturing Order', readonly=True)
    product_id = fields.Many2one('product.product', 'Product', readonly=True)
    product_uom_qty = fields.Float('Quantity', group_operator="sum")
    date = fields.Date('Date', readonly=True)

    @api.model_cr
    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self.env.cr.execute("""CREATE or REPLACE VIEW %s as (

            SELECT MIN(sm.id) AS id, sm.production_id, sm.product_id, sm.product_uom_qty, sm.date
            FROM stock_move sm
                LEFT JOIN product_product pp on sm.product_id = pp.id
                LEFT JOIN product_template pt on pp.product_tmpl_id = pt.id
            WHERE sm.production_id IS NOT NULL
              AND sm.state = 'done'
            GROUP BY sm.id

        )""" % (self._table,))
