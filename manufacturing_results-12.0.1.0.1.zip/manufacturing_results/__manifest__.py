# -*- coding: utf-8 -*-
##############################################################################
# Odoo Additional Function by CTWW
##############################################################################
{
    'name': "Manufacturing Results",

    'summary': """This module will provide you with some reports to easily control manufacturing results""",

    'description': """
        Long description of module's purpose
    """,

    'author': "CTWW",
    'license': 'OPL-1',
    'website': "https://www.linkedin.com/in/ngo-manh-70a68b183/",
    'category': 'Manufacturing',
    'version': '12.0.1.0.1',
    'depends': ['base','mrp'],
    'data': [
        'security/ir.model.access.csv',
        'report/finish_goods_produced.xml',
        'report/raw_material_consumed.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
    ],
    'currency': 'USD',
    'price': '5.0',
    'images': ['static/description/main_screenshot.png'],
    'post_init_hook': None,
    'installable': True,

}
