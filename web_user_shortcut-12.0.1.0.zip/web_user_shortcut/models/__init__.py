# -*- coding: utf-8 -*-
from . import res_users_shortcut
from . import ir_ui_menu
