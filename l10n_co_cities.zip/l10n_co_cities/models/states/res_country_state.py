# -*- coding: utf-8 -*-

from odoo import models, fields
import logging
import json
import os

_logger = logging.getLogger(__name__)


class ResCountryState(models.Model):
    _inherit = 'res.country.state'

    state_code = fields.Char()

    def init(self):
        try:
            path = 'data/states.json'
            root_directory = os.getcwd()
            dir = os.path.dirname(__file__)
            file_dir = dir.replace(root_directory, '').replace('models/states', '')
            route = file_dir + path

            with open(route[1:]) as file:
                data = json.load(file)

            for state in data['state']:

                data = self.env['res.country.state'].search(
                    [('code', '=', state['codigo_iso']), ('country_id', '=', 49)])

                if data.name:
                    data.write({'state_code': state['state_code']})

            file.close()

        except Exception as e:
            _logger.error('Error actualizando los datos de res_country_state - {}'.format(e))
