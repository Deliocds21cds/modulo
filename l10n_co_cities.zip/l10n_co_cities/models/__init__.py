# -*- coding: utf-8 -*-

from . import states
from . import countries
from . import cities
from . import contacts
