* Go to your current session

* Click on the button "Put Money In" or "Take Money Out"

.. figure:: ../static/description/pos_session_form.png

* Select the reason, the journal, the amount, and optionaly an extra
  description

.. figure:: ../static/description/wizard_pos_move_reason_form.png

* When closing the session, an account move will be created, with two lines,
  one with the default journal account, and one with the expense / income
  reason account.

.. figure:: ../static/description/account_move_form.png
