# -*- coding: utf-8 -*-
{
   'name': "Desfacturación",

    'description': """
        Este modulo sirve para hacer facturas sin que sean contabilizadas
    """,
    'category': 'stock',

    'version': '1.0',

    # any module necessary for this one to work correctly
    'depends': ['base','account','stock'],

    # always loaded
    'data': [
        'security/ir.model.access.xml',
        'views/views.xml',
        'views/wizard.xml',
        'data/sequence.xml'
    ],
    # only loaded in demonstration mode
    'demo': [
    ],
}