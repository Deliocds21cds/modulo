from odoo import api, fields, models, _

class UnfacturingPayments(models.Model):
    _name = "unfacturing.payments"

    name = fields.Char("Nombre")
    #currency = fields.Monetary()
    amount = fields.Float('Cantidad a Pagar', required=True)
    unfacturing_id = fields.Many2one(comodel_name='un.unfacturing', string='Factura', required=True)
    journal_id = fields.Many2one(comodel_name='account.journal', string='Diario de Pago')
    communication = fields.Char(string="Circular")
    payment_date = fields.Datetime(string="Fecha de Pago",required=True)
