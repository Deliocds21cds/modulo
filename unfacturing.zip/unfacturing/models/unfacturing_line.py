from odoo import api, fields, models

class UnfacturingLine(models.Model):
    _name = "unfacturing.line"
    
    unfacturing_id = fields.Many2one(comodel_name="un.unfacturing", string="Factura")
    product_id = fields.Many2one(comodel_name="product.product", string="Producto", required=True)
    cantidad = fields.Float(string="Cantidad", default= 1)
    price_unit = fields.Float(string="Precio")
    name = fields.Text(string="Descripción", required=True)
    discount = fields.Float(string="Descuento", default= 0)
    price_subtotal = fields.Float(string="Subtotal")
    
    
    @api.onchange('product_id')
    def set_price(self):
        self.price_unit = self.product_id.lst_price
        self.name = self.product_id.name

    @api.onchange('product_id','cantidad','price_unit','discount')
    def set_subtotal(self):
        self.price_subtotal = self.price_unit*self.cantidad

        if int(self.discount) > 0:
            self.price_subtotal = self.price_unit*self.cantidad*(self.discount/100)
        else:
            self.price_subtotal = self.price_unit*self.cantidad
