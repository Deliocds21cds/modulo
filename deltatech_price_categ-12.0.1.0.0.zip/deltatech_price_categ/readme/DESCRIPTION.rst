Thid module adds 4 new fields in product for 4 categories of price:
    1. Bronze Price
    2. Silver Price
    3. Gold Price
    4. Platinum price
