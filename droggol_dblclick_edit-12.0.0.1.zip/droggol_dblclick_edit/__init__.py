# -*- coding: utf-8 -*-
# Part of Droggol. See LICENSE file for full copyright and licensing details.
