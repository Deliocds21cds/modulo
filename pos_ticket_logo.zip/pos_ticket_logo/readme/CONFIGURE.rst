To add a logo to any given company:

#. Go to *Settings > Users & Companies > Companies*
#. Edit one and add the logo editing the top left corner image.

To configure receipt web print in the PoS (is the default setting):

#. Go to *Point of Sale > Configuration > Point of Sale*.
#. Edit the one you want to configure.
#. If the *PosBox* setting is enabled the *Receipt Printer* setting should be
   disabled.
