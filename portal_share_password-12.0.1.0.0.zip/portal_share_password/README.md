# Grant Portal Access With Password

Add a password field in grant portal access wizard/dialog, so the portal user can login without changing the password for the first time.

![Screenshot](static/description/icon.png "Screenshot")
