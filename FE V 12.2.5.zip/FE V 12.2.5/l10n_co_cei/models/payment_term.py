from odoo import models, api, fields
from odoo.exceptions import ValidationError
import logging


class Tax(models.Model):
    _inherit = 'account.payment.term'

    codigo_fe_dian = fields.Char(string='Código DIAN')
