from odoo import models, api, fields


class IrSequence(models.Model):
    _inherit = 'ir.sequence'

    fe_tipo_secuencia = fields.Selection(
        (
            ('facturas-venta', 'Facturas de venta'),
            ('notas-credito', 'Notas crédito'),
            ('notas-debito', 'Notas débito'),
        ),
        string='Tipo de secuencia'
    )
