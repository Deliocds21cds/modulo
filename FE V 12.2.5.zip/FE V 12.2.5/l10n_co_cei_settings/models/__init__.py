# -*- coding: utf-8 -*-

from . import res_partner
from . import account_fiscal_position
from . import responsabilidad_fiscal
