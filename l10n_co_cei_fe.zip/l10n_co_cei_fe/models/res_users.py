#-*- coding:utf-8 -*-
from odoo import models, api, tools, fields
from odoo.exceptions import ValidationError
import logging


class Users(models.Model):
    _inherit = "res.users"

    @api.multi
    def write(self,values):
        valor = super(Users, self).write(values)
        if 'company_id' in values:
            valor = super(Users, self).sudo().write({
                'in_group_' + str(self.env.ref(
                    'l10n_co_cei_fe.group_electronic_billing_manager').id): self.env['res.company'].search([('id','=',values['company_id'])]).fe_habilitar_facturacion
            })
        return valor