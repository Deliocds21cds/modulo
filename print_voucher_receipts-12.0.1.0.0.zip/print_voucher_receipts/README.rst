Payment/Receipt voucher print
=============================
* Used to print payment/receipt voucher.

Installation
============
- www.odoo.com/documentation/12.0/setup/install.html
- Install our custom addon

License
-------
GNU AFFERO GENERAL PUBLIC LICENSE, Version 3 (AGPLv3)
(http://www.gnu.org/licenses/agpl.html)

Company
-------
* 'Cybrosys Techno Solutions <https://cybrosys.com/>`__

Credits
-------
* Developer:
   odoo v12 - Varsha Vivek

Contacts
--------
* Mail Contact : odoo@cybrosys.com

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com

Further information
===================
HTML Description: `<static/description/index.html>`__
