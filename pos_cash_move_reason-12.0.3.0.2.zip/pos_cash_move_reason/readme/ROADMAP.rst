As it is not possible to disable actions on Odoo, a new technical group is
added by this module, named 'Use Old PoS 'Put or Take Money' Actions', to
hide native obsolete actions available on the model ``pos.session``
(the two buttons "Take Money Out" and "Put Money In") 
