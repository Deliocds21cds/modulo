* Go to 'Point of Sale' / 'Configuration' / 'Move Reason'

.. figure:: ../static/description/pos_cash_move_tree.png
   :alt: PoS Move Reasons List

* Create or update your PoS move Reasons.
* for each reason, you can mention the concerned journal(s), (Generally the
  Cash Journal), and if it is a reason to 'put in' and / or to 'take out'
  Money.

.. figure:: ../static/description/pos_cash_move_form.png
   :alt: PoS Move Reason

**Note**

You should have checked first 'Used in Point of Sale' for the Journals you want
to enable the feature.
