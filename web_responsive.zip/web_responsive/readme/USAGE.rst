The following keyboard shortcuts are implemented:

* Toggle app drawer - ``Alt + Shift + H``
* Navigate app search results - Arrow keys
* Choose app result - ``Enter``
* ``Esc`` to close app drawer
