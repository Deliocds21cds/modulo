# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from datetime import datetime
import time


class consulta_compraventa(models.TransientModel):
    _name = "consulta.compraventa"
    _rec_name = 'prestatario_id'

    prestatario_id = fields.Many2one('res.partner',string='Socio')
    plazo = fields.Many2one('account.payment.term',string='Plazo')
    # estado = fields.Many2one('loan.article.state',string='Estado del Articulo')
    tipo_articulo = fields.Selection(string='Tipo del Artículo',default='articulo',
                                    selection=[('prenda', 'Prenda'), ('articulo', 'Artículo'),
                                               ('carro', 'Carro'),('moto', 'Moto'),('bicicleta', 'Bicicleta')])
    # estado = fields.Selection([
    #     ('todos', 'Todos'),
    #     ('abierto', 'Abierto'),
    #     ('cerrado', 'Cerrado'),
    #     ('vencida', 'Cuotas Vencidas'),
    #     ], string='Prestamos', default='todos')

    # plazo_dias = fields.Selection([
    #     ('todos', 'Todos'),
    #     ('30', '30 días'),
    #     ('60', '60 días'),
    #     ('90', '90 días'),
    #     ], string='Plazo vencimiento')
    contrato = fields.Char(string='No. Contrato')
    fecha_desde = fields.Date(string='Fecha Desde')
    fecha_hasta = fields.Date(string='Fecha Hasta')


    #tabla = fields.Html(string='Resultado:')
    #contract_ids = fields.One2many('dev.loan.loan','id',string='Prestamos')
    contract_ids = fields.Many2many('contract.contract',string='Contratos')


    #modificar a que el pago este en estado pagado

    @api.multi
    #@api.onchange('modalidad','estado','prestatario_id','fecha_desde','fecha_hasta')
    def buscar_compra(self):
        rec = None
        rec_list=[]
        dominio=[]
        con_datos = True
            
        if self.contrato:
            dominio.append(('name','=ilike',self.contrato))
        if self.prestatario_id:
            dominio.append(('partner_id','=',self.prestatario_id.id))

        if self.plazo:
            dominio.append(('payment_term_id','=',self.plazo.id))
            

        # if self.estado:
        #     dominio.append(('article_state','=',self.estado.id))

        if self.tipo_articulo:
            dominio.append(('tipo_articulo','=',self.tipo_articulo))

        # if self.plazo_dias == 'todos':
            
        #     sql=''' SELECT loan_id from dev_loan_installment where vencida = True and state = 'unpaid' '''
        #     self.env.cr.execute(sql)
        #     result = self.env.cr.fetchall()
        #     loan_ids=[]
        #     if result:
        #         loan_ids=[i[0] for i in result]
        #         dominio.append(('id','in',loan_ids))
        #     else:
        #         con_datos = False


        # if self.plazo_dias == '30':
            
        #     sql=''' SELECT loan_id from dev_loan_installment di where vencida = True and state = 'unpaid' and (select current_date - di.date)>=30 and (select current_date - di.date)<60 '''
        #     self.env.cr.execute(sql)
        #     result = self.env.cr.fetchall()
        #     loan_ids=[]
        #     if result:
        #         loan_ids=[i[0] for i in result]
        #         dominio.append(('id','in',loan_ids))
        #     else:
        #         con_datos = False

        if self.fecha_desde:
            dominio.append(('facture_date','>=',self.fecha_desde))

        if self.fecha_hasta:
            dominio.append(('facture_date','<=',self.fecha_hasta))

        
        compra = self.env['contract.contract'].sudo().search(dominio)
            
        if compra:
            self.contract_ids=[(6, 0, compra.ids)]

        else:
            self.contract_ids=[(5,0,0)]
        
            


    @api.multi
    def get_report(self):
        f_desde = f_hasta = None
        
        if self.fecha_desde:
            f_desde=datetime.strftime(self.fecha_desde,"%Y-%m-%d")
        if self.fecha_hasta:
            f_hasta=datetime.strftime(self.fecha_hasta,"%Y-%m-%d")

        hoy = datetime.now()
        hoy = hoy.strftime("%d/%m/%Y - %H:%M:%S")
        lista=[]
        for i in self.contract_ids:
            # fd=datetime.strftime(self.fecha_desde,"%d-%m-%Y")
            # fh=datetime.strftime(self.fecha_desde,"%d-%m-%Y")
            aux = (i.partner_id.name,i.partner_id.vat,i.name, i.payment_term_id.name,i.tipo_articulo,i.facture_date,i.venc_date)
            lista.append(aux)
             
        data = {
            'model': self._name,
            'ids': self.ids,
            'f_desde':f_desde,
            'f_hasta':f_hasta,
            'hoy':hoy,
            'tupla_datos':lista
            
            }

     
        
        return self.env.ref('contract.report_consulta_compraventa').report_action(self, data=data)














        # reporte  = '<h2>Consulta de saldos por Cliente</h2>'
        # reporte += '<table style="width:100%;">'
        # reporte += '   <thead style="border: thin solid gray;">'
        # reporte += '        <tr style="border: thin solid gray;">'
        # reporte += '            <th colspan="4" style="border: thin solid gray; text-align: center">Producto</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Meses</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Capital</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Intereses</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Total a pagar</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Saldo</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">C. Fija Mensual</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Quincenal</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Semanal</th>'
        # reporte += '            <th style="border: thin solid gray; text-align: center">Diaria</th>'
        # reporte += '        </tr style="border: thin solid gray;">'
        # reporte += '    </thead>'
        # reporte += '    <tbody>'



        # if rec:

        #     reporte += '        <tr style="border-bottom: thin solid gray;">'
        #     reporte += '            <td colspan="4" style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
        #     reporte += '            <td style="text-align: center; vertical-align: middle;">%s</td>' % ('222')
            

        #     reporte += '        </tr>'
        #     reporte += '    </tbody></table >'

        #     self.tabla =reporte

    