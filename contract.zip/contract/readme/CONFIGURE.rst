To view discount field in contract line, you need to set *Discount on lines* in
user access rights.
