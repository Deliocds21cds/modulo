* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Carlos Dauden <carlos.dauden@tecnativa.com>
* Angel Moya <angel.moya@domatix.com>
* Dave Lasley <dave@laslabs.com>
* Vicent Cubells <vicent.cubells@tecnativa.com>
* Miquel Raïch <miquel.raich@eficent.com>
* Souheil Bejaoui <souheil.bejaoui@acsone.eu>
* Thomas Binsfeld <thomas.binsfeld@acsone.eu>
* Rafael Blasco <rafael.blasco@tecnativa.com>
* Guillaume Vandamme <guillaume.vandamme@acsone.eu>
* Raphaël Reverdy <raphael.reverdy@akretion.com>
