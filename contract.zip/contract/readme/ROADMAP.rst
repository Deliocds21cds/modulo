* Recover states and others functional fields in Contracts.
* Remove ``models/ir_ui_view.py`` in v13, where the workaround it contains is supported upstream.
