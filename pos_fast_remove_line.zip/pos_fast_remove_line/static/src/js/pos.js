odoo.define('pos_fast_remove_line', function (require) {
"use strict";

var core = require('web.core');
var screens = require('point_of_sale.screens');
var QWeb = core.qweb;
var _t = core._t;

    var RemoveOrderLineButton = screens.ActionButtonWidget.extend({
        template: 'RemoveOrderLineButton',
        button_click: function(){
            var self = this;
            var lines = this.pos.get_order().get_orderlines();
            while(this.pos.get_order().get_orderlines().length > 0){
                var line = this.pos.get_order().get_selected_orderline();
                this.pos.get_order().remove_orderline(line);
            }
        },
    });

    screens.define_action_button({
        'name': 'RemoveOrderLineButton',
        'widget': RemoveOrderLineButton,
        'condition': function(){
            return this.pos.config.allow_fast_remove_line;
        },
    });
    screens.OrderWidget.include({
      render_orderline: function(orderline){
         var order = this.pos.get_order();
          var self = this;
          var el_str  = QWeb.render('Orderline',{widget:this, line:orderline}); 
          var el_node = document.createElement('div');
              el_node.innerHTML = _.str.trim(el_str);
              el_node = el_node.childNodes[0];
              el_node.orderline = orderline;
              el_node.addEventListener('click',this.line_click_handler);
              $(el_node).find(".remove_order_line").click(function(event){
                  // var selectedOrderLine = order.get_selected_orderline();
                  order.remove_orderline(orderline);
                  event.stopPropagation();
              });
          var el_lot_icon = el_node.querySelector('.line-lot-icon');
          if(el_lot_icon){
              el_lot_icon.addEventListener('click', (function() {
                  this.show_product_lot(orderline);
              }.bind(this)));
          }

          orderline.node = el_node;
          return el_node;
      },
    });

});

