# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class MrpBom(models.Model):
	_inherit = 'mrp.bom'
	_rec_name = 'code'

	bom_total_cost = fields.Float("Total BOM Cost Price")

	@api.onchange('bom_line_ids')
	def change_total_bom_cost(self):
		if self.bom_line_ids:
			self.bom_total_cost = 0.0
			for line in self.bom_line_ids:
				self.bom_total_cost += line.bom_cost
		if not self.bom_line_ids:
			self.bom_total_cost = 0.0

	@api.model
	def create(self,vals):
		res = super(MrpBom,self).create(vals)
		if res.product_id:
			bom_products = self.search([('product_id','=',res.product_id.id)])
			res.product_id.write({'mrp_bom_ids':[(6,0,bom_products.ids)]})
		if res.product_tmpl_id:
			bom_products_tmpl = self.search([('product_tmpl_id','=',res.product_tmpl_id.id)])
			res.product_tmpl_id.write({'mrp_bom_ids':[(6,0,bom_products_tmpl.ids)]})
		return res

class MrpBomLine(models.Model):
	_inherit='mrp.bom.line'

	bom_unit_cost = fields.Float("Unit Cost")
	bom_cost = fields.Float("Total Cost")

	@api.onchange('product_id')
	def change_bom_cost(self):
		if self.product_id.standard_price:
			self.bom_unit_cost = self.product_id.standard_price
		self.bom_cost = (self.product_qty * self.bom_unit_cost)

	@api.onchange('bom_unit_cost','product_qty')
	def change_bom_unit_cost(self):
		self.bom_cost = (self.product_qty * self.bom_unit_cost)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4::