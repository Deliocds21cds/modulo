# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class ProductTemplate(models.Model):
	_inherit = 'product.template'

	bom_cost_price = fields.Float("BOM Cost Price", compute='compute_total_bom_cost')
	is_bom_cost = fields.Boolean('Show BOM Cost',compute='compute_total_bom_cost')
	mrp_bom_ids = fields.Many2many('mrp.bom', string="BOM Reference")

	def compute_total_bom_cost(self):
		for rec in self:
			mrp_obj = self.env['mrp.bom'].search([('product_tmpl_id','=',rec.id)])
			if mrp_obj:
				for each in mrp_obj:
					rec.bom_cost_price += each.bom_total_cost
					if rec.bom_cost_price:
						rec.is_bom_cost = True

class ProductProduct(models.Model):
	_inherit = 'product.product'

	bom_cost_price = fields.Float("BOM Cost Price", compute='compute_total_bom_cost')
	is_bom_cost = fields.Boolean('Show BOM Cost',compute='compute_total_bom_cost')
	bom_count = fields.Integer('# Bill of Material', compute='_compute_bom_count')
	mrp_bom_ids = fields.Many2many('mrp.bom', string="BOM Reference")

	def _compute_bom_count(self):
		for product in self:
			product.bom_count = self.env['mrp.bom'].search_count([('product_id', '=', product.id)])

	@api.multi
	def compute_total_bom_cost(self):
		for rec in self:
			mrp_obj = self.env['mrp.bom'].search([('product_id','=',rec.id)])
			if mrp_obj:
				for each in mrp_obj:
					if each.product_id:
						rec.bom_cost_price += each.bom_total_cost
			if rec.bom_cost_price:
				rec.is_bom_cost = True

	@api.multi
	def action_view_bom(self):
		action = self.env.ref('mrp.product_open_bom').read()[0]
		product_ids = self.ids
		action['context'] = {
			'default_product_tmpl_id': product_ids[0],
			'default_id': self.ids[0],
		}
		action['domain'] = [('product_id', 'in', product_ids)]
		return action

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4::