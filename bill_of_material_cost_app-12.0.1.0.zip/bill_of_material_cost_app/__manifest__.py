# -*- coding: utf-8 -*-

{
    'name' : "BOM Product cost price Odoo",
    "author": "Edge Technologies",
    'version': '12.0.1.0',
    'live_test_url': "https://youtu.be/szcrgNmKVFU",
    "images":['static/description/main_screenshot.png'],
    'summary': 'Products Bill of Materials Total Cost',
    'description' : '''This module helps User to find Products Bill of Materials Total Cost According to Product and Product Variants. also, Total Cost view in List and Kanban

cost price BOM cost price
BOM Product cost price
Products Bill of Materials Total Cost
Cost Price for BOM Products BOM total cost price
 Manufacturing BOM total cost price
 Product Variant BOM
 BoM cost of a product
 total BoM cost
 BoM cost of a product
 BOM costs
 Cost Computation of Finished Goods
 Finished Product Cost
 Calculate BOM cost
 BOM calculations
 calculation BOM cost price
 BOM Cost price calculation
 bom costing
 Costing BOM Inventory Costing Update
 Manufacturing Bill of Material (BOM) Costing
 product costing
 costing product
Manage BOM Costs

 update BOM cost update
 Cost Finished Goods Cost

 Cost Bill of Material Cost
 Manufacturing BOM cost Price on Product
MRP costing mrp product costing mrp bom cost price

    ''',
    "license" : "OPL-1",
    'depends' : ['product','mrp'],
    'data': [
            'security/group_bom.xml',
            'views/product_view.xml',
            'views/mrp_bom_view.xml',
             ],
    'installable': True,
    'auto_install': False,
    'price': 8,
    'currency': "EUR",
    'category': 'Manufacturing',
}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
