# -*- coding: utf-8 -*-
{
    'name': 'Invoice Barcode Scanning',
    'version': '1.0',
    'description': """
           Invoice Barcode Scanning
            """,
    'author': 'CodeFire Technologies',
    'website': 'https://www.codefire.org/',
    'images': ['static/description/odoo-invoice.png'],
    'category': 'Invoicing Management',
    'license': 'AGPL-3',
    'depends': [
        'account'
    ],
    'data': [
        'security/security.xml',
        'views/account_view.xml',
        'security/ir.model.access.csv',
    ],
}
