* Pexego.
* Davide Corio <davide.corio@domsense.com>
* Joao Alfredo Gama Batista <joao.gama@savoirfairelinux.com>
* Sandy Carter <sandy.carter@savoirfairelinux.com>
* Giorgio Borelli <giorgio.borelli@abstract.it>
* Daniel Campos <danielcampos@avanzosc.es>
* Pedro M. Baeza
* Oihane Crucelaegui <oihanecruce@gmail.com>
* Nicola Malcontenti <nicola.malcontenti@agilebg.com>
* Aitor Bouzas <aitor.bouzas@adaptivecity.com>
