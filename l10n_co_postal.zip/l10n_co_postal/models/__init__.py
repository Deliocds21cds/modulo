# -*- coding: utf-8 -*-

from . import config_fe
from . import config_fe_details
from . import postal_config
from . import postal
from . import res_partner
