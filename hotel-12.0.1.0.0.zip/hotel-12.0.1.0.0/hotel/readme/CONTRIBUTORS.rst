* Odoo Community Association (OCA)
* Serpent Consulting Services Pvt. Ltd.
* Odoo S.A.
