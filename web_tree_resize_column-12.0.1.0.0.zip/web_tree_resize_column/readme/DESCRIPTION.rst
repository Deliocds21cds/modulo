This module adds the ability to resize columns in tree views.
