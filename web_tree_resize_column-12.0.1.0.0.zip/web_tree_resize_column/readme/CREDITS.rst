This module uses a jQuery plugin by Jones Vinoth Joseph <https://github.com/Jo-Geek/jQuery-ResizableColumns>.
