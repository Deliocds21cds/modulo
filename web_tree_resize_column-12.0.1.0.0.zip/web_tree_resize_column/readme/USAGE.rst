To use this module, you need to:

#. Go to any tree view;
#. hover over the border of the column you want to resize;
#. hold click and drag the column to the desired width.

This also works for tree views that are nested in form views.
