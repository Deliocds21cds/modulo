$(document).ready(function(){ 
	if($('.clear-brand-filter')){
		$(".clear-brand-filter").click(function(e){
			var self=$(this)
            var curent_div = $(self).parents('.product_brand_shop').find('ul');
            e.preventDefault()
			$(curent_div).find("input:checked").each(function(){
				$(this).removeAttr("checked");
			});
			$("form.js_attributes input").closest("form").submit();
		});
	}
	if($('.clear-attrib-filter')){
		$(".clear-attrib-filter").click(function(e){
			var target = $(e.target)
            if(target.parent().next('.nav-pills').length){
                target.parent().next('.nav-pills').find("input:checked").each(function(){
                    $(this).removeAttr("checked");
                });
                $("form.js_attributes input").closest("form").submit();
            }else{
                target.parents().find('label').find("input:checked").each(function(){
                    $(this).removeAttr("checked");
                });
                $("form.js_attributes input").closest("form").submit();
            }
		});
	}
	$(".as_our_brand").owlCarousel({
        items: 7,
        margin: 10,
        nav: true,
        pagination: false,
        responsive: {
            0: {
                items: 2,
            },
            481: {
                items: 2,
            },
            768: {
                items: 4,
            },
            1024: {
                items: 7,
            }
        }

    });
});

