# -*- coding: utf-8 -*-

from odoo import http
from odoo.addons.website_sale.controllers.main import WebsiteSale


class WebsiteSaleExtend(WebsiteSale):
    @http.route()
    def shop(self, page=0, category=None, search='', ppg=False, **post):
        response = super(WebsiteSaleExtend, self).shop(page=page, category=category, search=search, ppg=ppg, **post)
        response.qcontext.update({
            'get_attribute_exclusions': self._get_attribute_exclusions,
            'rating_status': response.qcontext.get('rating_product'),
        })
        return response
