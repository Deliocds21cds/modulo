# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import ir_mail_server
from . import mail_bounced_mixin
from . import mail_mail
from . import mail_message
from . import mail_tracking_email
from . import mail_tracking_event
from . import res_partner
from . import mail_thread
from . import mail_resend_message
from . import mail_alias
from . import ir_config_parameter
