======================
Point of Sale Logo v11
======================
This module helps you to set a logo for every point of sale. This will help you to
identify the point of sale easily. You can also see this logo in pos screen and pos receipt.

Installation
============
Just select it from available modules to install it,
there is no need to extra installations.


Configuration & Usage
=====================
* Go to configuration of POS.
* Add a logo to your POS.
* Ensure logo is near the resolution (width:76px;height:47px).

Credits
=======
Developer: Nilmar Shereef @ cybrosys, odoo@cybrosys.com
Developer: Jesni Banu @ cybrosys, odoo@cybrosys.com
Developer: Niyas Raphy (Migrated to v11)


