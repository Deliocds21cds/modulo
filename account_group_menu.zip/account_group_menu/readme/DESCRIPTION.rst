This module adds menu entries **Account Groups** and **Account Tax Groups** under *Invoicing > Configuration > Accounting*,
because this menu entry doesn't exists in the official *account* module of Odoo 12.
