On the POS payment screen, you'll find a *Send Invoice by Email* button.

.. image:: ../static/description/invoice-mail-screen.png

If checked, an email will be send to the customer when the invoice
is validated.
