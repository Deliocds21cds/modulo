Go to *Point of Sale > Configuration > Point of Sale* and
enable **Send Invoice by Mail** 

.. image:: ../static/description/invoice-mail-config.png
