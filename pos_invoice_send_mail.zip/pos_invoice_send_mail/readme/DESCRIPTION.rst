Allows to send the invoice by email, from the POS.
