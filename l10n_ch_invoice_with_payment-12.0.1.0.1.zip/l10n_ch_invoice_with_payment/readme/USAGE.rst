
To use this module, you need to:

#. Go to an invoice and print the report named 'Invoice with payment slip'
