This module allows the user to print an invoice and a payment slip in the same PDF

