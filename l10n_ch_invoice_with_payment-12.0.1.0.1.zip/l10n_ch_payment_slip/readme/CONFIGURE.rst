You can adjust the print out of ISR, which depend on each printer,
In the General Settings - Invoicing. The settings are specific for every
company.

This is especialy useful when using pre-printed paper.
Options also allow you to print the ISR in background when using
white paper and printing customer address in the page header.

Default address format on ISR can be change by setting System parameter:
`isr.address.format`
