The development of this module has been financially supported by:

* Hasa SA
* Open Net SA
* Prisme Solutions Informatique SA
* Quod SA
