This addons will add different bank types required by specific Swiss electronic
payment like DTA and ISR. It allows to manage both Post and Bank systems.

It'll perform some validation when entering or filling bank account number or ESR number
in invoice and add some Swiss specific fields on bank.

This module is required if you want to use electronic payment in Switzerland.
