Account type will be discovered automatically.

* For IBAN accounts fill account number with IBAN.
* For Postal account fill account number with postal account number in IBAN, 9 digits format (e.g. 01-23456-1).

Entering a postal number of 9 digits will auto-complete the bank with PostFinance. (You might create it if you haven't installed `l10n_ch_bank`)

* For bank account for ISR, select the bank and fill the CCP field in bank, optionally fill the account number with bank number.
