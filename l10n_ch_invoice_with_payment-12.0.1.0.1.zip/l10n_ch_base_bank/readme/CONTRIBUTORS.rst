* Nicolas Bessi (Camptocamp)
* Vincent Renaville <vincent.renaville@camptocamp.com>
* Joël Grand-Guillaume <joel.grandguillaume@camptocamp.com>
* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Paul Catinean <paulcatinean@gmail.com>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Akim Juillerat <akim.juillerat@camptocamp.com>
* Iryna Vyshnevska <i.vyshnevska@mobilunity.com>
