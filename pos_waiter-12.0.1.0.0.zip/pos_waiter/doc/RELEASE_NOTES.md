## Module <pos_waiter>

#### 20.11.2019
#### Version 12.0.1.0.0
##### ADD
- Initial commit
