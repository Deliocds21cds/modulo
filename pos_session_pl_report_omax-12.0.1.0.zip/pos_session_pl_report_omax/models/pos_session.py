# -*- coding: utf-8 -*-
from datetime import datetime
from dateutil import tz
import pytz
from odoo import fields, models, api
from odoo.tools.misc import DEFAULT_SERVER_DATETIME_FORMAT
from collections import Counter
import json, ast
from itertools import groupby
from operator import itemgetter

class PosConfig(models.Model):
    _inherit = 'pos.config'

    omax_session_pl_report = fields.Boolean(string='Session P&L Report ', help='This will allow to print Session P&L Report directly from POS screen')

class PosSession(models.Model):
    _inherit = 'pos.session'
    
    def action_session_pl_report(self):
        return self.env.ref('pos_session_pl_report_omax.action_report_session_pl').report_action(self)
        
    def get_current_datetime(self):
        now = datetime.now()
        today = str(now).split('.')[0]
        tz = self.env.user.partner_id.tz and pytz.timezone(self.env.user.partner_id.tz) or pytz.utc
        dt = pytz.utc.localize(datetime.strptime(str(today), "%Y-%m-%d %H:%M:%S")).astimezone(tz)
        dt_split = str(str(dt).split('+')[0])
        return dt_split
    
    def get_opened_date(self):
        tz = self.env.user.partner_id.tz and pytz.timezone(self.env.user.partner_id.tz) or pytz.utc
        dt = pytz.utc.localize(datetime.strptime(str(self.start_at), "%Y-%m-%d %H:%M:%S")).astimezone(tz)
        dt_split = str(str(dt).split('+')[0])
        return dt_split
        
    def get_closed_date(self):
        if self.stop_at:
            tz = self.env.user.partner_id.tz and pytz.timezone(self.env.user.partner_id.tz) or pytz.utc
            dt = pytz.utc.localize(datetime.strptime(str(self.stop_at), "%Y-%m-%d %H:%M:%S")).astimezone(tz)
            dt_split = str(str(dt).split('+')[0])
            return dt_split
            
    def get_session_amount_data(self):
        pos_order_ids = self.env['pos.order'].search([('session_id', '=', self.id)])
        discount_amount = 0.0
        taxes_amount = 0.0
        total_sale_amount = 0.0
        total_gross_amount = 0.0
        sold_product = {}
        for pos_order in pos_order_ids:
            currency = pos_order.session_id.currency_id
            total_gross_amount += pos_order.amount_total
            for line in pos_order.lines:
                if line.product_id.pos_categ_id and line.product_id.pos_categ_id.name:
                    if line.product_id.pos_categ_id.name in sold_product:
                        sold_product[line.product_id.pos_categ_id.name] += line.qty
                    else:
                        sold_product.update({line.product_id.pos_categ_id.name: line.qty})
                else:
                    if 'undefine' in sold_product:
                        sold_product['undefine'] += line.qty
                    else:
                        sold_product.update({'undefine': line.qty})
                if line.tax_ids_after_fiscal_position:
                    line_taxes = line.tax_ids_after_fiscal_position.compute_all(line.price_unit * (1 - (line.discount or 0.0) / 100.0), currency, line.qty, product=line.product_id, partner=line.order_id.partner_id or False)
                    for tax in line_taxes['taxes']:
                        taxes_amount += tax.get('amount', 0)
                if line.discount > 0:
                    discount_amount += (((line.price_unit * line.qty) * line.discount) / 100)
                if line.qty > 0:
                    total_sale_amount += line.price_unit * line.qty

        return {
            'total_sale': total_sale_amount,
            'discount': discount_amount,
            'tax': taxes_amount,
            'products_sold': sold_product,
            'total_gross': total_gross_amount - taxes_amount - discount_amount,
            'final_total': total_gross_amount
        }
        
    def get_pos_orders(self):
        order_ids = self.env['pos.order'].search([('session_id', '=', self.id)])
        return order_ids
    
